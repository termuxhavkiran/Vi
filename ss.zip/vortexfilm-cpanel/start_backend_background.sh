#!/bin/bash
# راه‌اندازی Backend در Background برای cPanel

echo "🚀 Starting VortexFilm Backend in background..."

# رفتن به پوشه backend
cd /home/YOUR_CPANEL_USERNAME/vortexfilm/backend

# کپی کردن فایل .env.production به .env
cp .env.production .env

# Kill کردن process قبلی (اگر وجود داشته باشد)
pkill -f "uvicorn server:app"

# راه‌اندازی سرور در background
nohup uvicorn server:app --host 0.0.0.0 --port 8000 > /home/YOUR_CPANEL_USERNAME/vortexfilm/backend/server.log 2>&1 &

echo "✅ Backend started! Check logs at: /home/YOUR_CPANEL_USERNAME/vortexfilm/backend/server.log"
echo "🔗 Backend URL: https://http://89.42.199.185:8000"
