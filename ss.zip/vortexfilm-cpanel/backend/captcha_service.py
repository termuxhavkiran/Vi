"""Custom math captcha service"""
import random
import string
import hashlib
from datetime import datetime, timezone, timedelta
from typing import Dict, Tuple
import logging

logger = logging.getLogger(__name__)

class CaptchaService:
    def __init__(self):
        # In-memory storage for captchas (for production, use Redis)
        self.captchas: Dict[str, Dict] = {}
        self.cleanup_interval = 300  # Clean up every 5 minutes
    
    def generate_captcha(self) -> Tuple[str, str, str]:
        """Generate a math captcha
        Returns: (captcha_id, question, answer_hash)
        """
        # Generate random math operation
        operations = [
            lambda: (random.randint(1, 20), random.randint(1, 20), '+'),
            lambda: (random.randint(10, 50), random.randint(1, 9), '-'),
            lambda: (random.randint(1, 12), random.randint(1, 12), '*'),
        ]
        
        num1, num2, op = random.choice(operations)()
        
        # Calculate answer
        if op == '+':
            answer = num1 + num2
            question = f"{num1} + {num2}"
        elif op == '-':
            answer = num1 - num2
            question = f"{num1} - {num2}"
        elif op == '*':
            answer = num1 * num2
            question = f"{num1} × {num2}"
        else:
            answer = 0
            question = "0"
        
        # Generate unique captcha ID
        captcha_id = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
        
        # Hash the answer for security
        answer_hash = hashlib.sha256(str(answer).encode()).hexdigest()
        
        # Store captcha (expires in 5 minutes)
        self.captchas[captcha_id] = {
            'answer_hash': answer_hash,
            'created_at': datetime.now(timezone.utc),
            'expires_at': datetime.now(timezone.utc) + timedelta(minutes=5)
        }
        
        # Clean up expired captchas
        self._cleanup_expired()
        
        logger.info(f"Generated captcha: {captcha_id} - {question} = {answer}")
        
        return captcha_id, question, answer_hash
    
    def verify_captcha(self, captcha_id: str, user_answer: str) -> bool:
        """Verify captcha answer"""
        if captcha_id not in self.captchas:
            logger.warning(f"Captcha not found: {captcha_id}")
            return False
        
        captcha_data = self.captchas[captcha_id]
        
        # Check if expired
        if datetime.now(timezone.utc) > captcha_data['expires_at']:
            logger.warning(f"Captcha expired: {captcha_id}")
            del self.captchas[captcha_id]
            return False
        
        # Verify answer
        try:
            answer_hash = hashlib.sha256(str(user_answer).encode()).hexdigest()
            is_valid = answer_hash == captcha_data['answer_hash']
            
            # Delete captcha after verification (one-time use)
            del self.captchas[captcha_id]
            
            if is_valid:
                logger.info(f"Captcha verified successfully: {captcha_id}")
            else:
                logger.warning(f"Captcha verification failed: {captcha_id}")
            
            return is_valid
        except Exception as e:
            logger.error(f"Captcha verification error: {e}")
            return False
    
    def _cleanup_expired(self):
        """Remove expired captchas"""
        now = datetime.now(timezone.utc)
        expired = [cid for cid, data in self.captchas.items() if now > data['expires_at']]
        for cid in expired:
            del self.captchas[cid]
        if expired:
            logger.info(f"Cleaned up {len(expired)} expired captchas")

# Global captcha service instance
captcha_service = CaptchaService()
