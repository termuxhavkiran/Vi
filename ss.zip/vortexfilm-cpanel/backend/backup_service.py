"""Backup and restore service for MongoDB and uploaded files"""
import os
import subprocess
import shutil
import tarfile
from datetime import datetime, timezone
from pathlib import Path
import logging
import json

logger = logging.getLogger(__name__)

BACKUP_DIR = Path("/app/backups")
BACKUP_DIR.mkdir(exist_ok=True)

class BackupService:
    def __init__(self, mongo_url: str, db_name: str, uploads_dir: Path):
        self.mongo_url = mongo_url
        self.db_name = db_name
        self.uploads_dir = uploads_dir
    
    def create_backup(self) -> dict:
        """Create a complete backup of database and files"""
        try:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            backup_name = f"backup_{timestamp}"
            backup_path = BACKUP_DIR / backup_name
            backup_path.mkdir(exist_ok=True)
            
            logger.info(f"Starting backup: {backup_name}")
            
            # Backup MongoDB
            db_backup_path = backup_path / "database"
            db_backup_path.mkdir(exist_ok=True)
            
            logger.info("Backing up MongoDB...")
            result = subprocess.run([
                "mongodump",
                "--uri", self.mongo_url,
                "--db", self.db_name,
                "--out", str(db_backup_path)
            ], capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"MongoDB backup failed: {result.stderr}")
                raise Exception(f"MongoDB backup failed: {result.stderr}")
            
            logger.info("MongoDB backup completed")
            
            # Backup uploaded files
            if self.uploads_dir.exists():
                logger.info("Backing up uploaded files...")
                files_backup_path = backup_path / "uploads"
                shutil.copytree(self.uploads_dir, files_backup_path)
                logger.info("Files backup completed")
            
            # Create metadata
            metadata = {
                "backup_name": backup_name,
                "timestamp": timestamp,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "db_name": self.db_name,
                "files_included": self.uploads_dir.exists()
            }
            
            with open(backup_path / "metadata.json", "w") as f:
                json.dump(metadata, f, indent=2)
            
            # Compress backup
            logger.info("Compressing backup...")
            archive_path = BACKUP_DIR / f"{backup_name}.tar.gz"
            with tarfile.open(archive_path, "w:gz") as tar:
                tar.add(backup_path, arcname=backup_name)
            
            # Remove uncompressed backup
            shutil.rmtree(backup_path)
            
            # Get archive size
            archive_size = os.path.getsize(archive_path) / (1024 * 1024)  # MB
            
            logger.info(f"Backup completed: {archive_path} ({archive_size:.2f} MB)")
            
            return {
                "success": True,
                "backup_name": backup_name,
                "archive_path": str(archive_path),
                "size_mb": round(archive_size, 2),
                "created_at": metadata["created_at"]
            }
        
        except Exception as e:
            logger.error(f"Backup failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def restore_backup(self, backup_name: str) -> dict:
        """Restore database and files from backup"""
        try:
            archive_path = BACKUP_DIR / f"{backup_name}.tar.gz"
            if not archive_path.exists():
                raise FileNotFoundError(f"Backup not found: {backup_name}")
            
            logger.info(f"Starting restore from: {backup_name}")
            
            # Extract backup
            extract_path = BACKUP_DIR / "temp_restore"
            extract_path.mkdir(exist_ok=True)
            
            with tarfile.open(archive_path, "r:gz") as tar:
                tar.extractall(extract_path)
            
            backup_path = extract_path / backup_name
            
            # Read metadata
            with open(backup_path / "metadata.json", "r") as f:
                metadata = json.load(f)
            
            # Restore MongoDB
            logger.info("Restoring MongoDB...")
            db_backup_path = backup_path / "database" / self.db_name
            
            result = subprocess.run([
                "mongorestore",
                "--uri", self.mongo_url,
                "--db", self.db_name,
                "--drop",  # Drop existing collections
                str(db_backup_path)
            ], capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"MongoDB restore failed: {result.stderr}")
                raise Exception(f"MongoDB restore failed: {result.stderr}")
            
            logger.info("MongoDB restore completed")
            
            # Restore files
            files_backup_path = backup_path / "uploads"
            if files_backup_path.exists():
                logger.info("Restoring uploaded files...")
                if self.uploads_dir.exists():
                    shutil.rmtree(self.uploads_dir)
                shutil.copytree(files_backup_path, self.uploads_dir)
                logger.info("Files restore completed")
            
            # Clean up
            shutil.rmtree(extract_path)
            
            logger.info(f"Restore completed: {backup_name}")
            
            return {
                "success": True,
                "backup_name": backup_name,
                "restored_at": datetime.now(timezone.utc).isoformat(),
                "metadata": metadata
            }
        
        except Exception as e:
            logger.error(f"Restore failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def list_backups(self) -> list:
        """List all available backups"""
        backups = []
        for backup_file in BACKUP_DIR.glob("backup_*.tar.gz"):
            size_mb = os.path.getsize(backup_file) / (1024 * 1024)
            backups.append({
                "name": backup_file.stem,
                "filename": backup_file.name,
                "size_mb": round(size_mb, 2),
                "created_at": datetime.fromtimestamp(backup_file.stat().st_mtime).isoformat()
            })
        return sorted(backups, key=lambda x: x["created_at"], reverse=True)
    
    def delete_backup(self, backup_name: str) -> dict:
        """Delete a backup"""
        try:
            archive_path = BACKUP_DIR / f"{backup_name}.tar.gz"
            if not archive_path.exists():
                raise FileNotFoundError(f"Backup not found: {backup_name}")
            
            os.remove(archive_path)
            logger.info(f"Backup deleted: {backup_name}")
            
            return {
                "success": True,
                "message": "Backup deleted successfully"
            }
        
        except Exception as e:
            logger.error(f"Delete backup failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def cleanup_old_backups(self, keep_count: int = 10):
        """Keep only the latest N backups"""
        backups = self.list_backups()
        if len(backups) > keep_count:
            for backup in backups[keep_count:]:
                self.delete_backup(backup["name"])
            logger.info(f"Cleaned up {len(backups) - keep_count} old backups")
