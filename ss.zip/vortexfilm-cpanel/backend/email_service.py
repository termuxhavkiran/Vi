import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
import os
import logging
from typing import List, Dict

logger = logging.getLogger(__name__)


class EmailService:
    def __init__(self):
        self.smtp_host = os.getenv("SMTP_HOST", "smtp.gmail.com")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.smtp_username = os.getenv("SMTP_USERNAME", "")
        self.smtp_password = os.getenv("SMTP_PASSWORD", "")
        self.from_email = os.getenv("SMTP_FROM_EMAIL", "noreply@vortexfilm.com")
        self.from_name = os.getenv("SMTP_FROM_NAME", "VortexFilm")
        self.frontend_url = os.getenv("FRONTEND_URL", "http://localhost:3000")
        self.templates_dir = Path(__file__).parent / "email_templates"

    def _load_template(self, template_name: str) -> str:
        """بارگذاری قالب HTML"""
        template_path = self.templates_dir / f"{template_name}.html"
        if template_path.exists():
            with open(template_path, 'r', encoding='utf-8') as f:
                return f.read()
        return ""

    def _send_email(self, to_email: str, subject: str, html_content: str) -> bool:
        """ارسال ایمیل با SMTP"""
        if not self.smtp_username or not self.smtp_password:
            logger.warning("SMTP credentials not configured. Email not sent.")
            return False

        try:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = f"{self.from_name} <{self.from_email}>"
            msg['To'] = to_email

            html_part = MIMEText(html_content, 'html', 'utf-8')
            msg.attach(html_part)

            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_username, self.smtp_password)
                server.send_message(msg)

            logger.info(f"Email sent successfully to {to_email}")
            return True
        except Exception as e:
            logger.error(f"Failed to send email to {to_email}: {e}")
            return False

    def send_new_movie_email(self, to_email: str, movie_data: Dict) -> bool:
        """ارسال ایمیل فیلم جدید"""
        template = self._load_template("new_movie")
        if not template:
            logger.error("new_movie template not found")
            return False

        # ساخت HTML برای ژانرها
        genres_html = ""
        for genre in movie_data.get("genres", []):
            genres_html += f'<span class="genre-tag">{genre}</span>'

        # جایگزینی متغیرها
        html_content = template
        html_content = html_content.replace("{{movie_title}}", movie_data.get("title", ""))
        html_content = html_content.replace("{{movie_overview}}", movie_data.get("overview", "")[:200] + "...")
        html_content = html_content.replace("{{poster_url}}", movie_data.get("poster_url", ""))
        html_content = html_content.replace("{{genres_html}}", genres_html)
        html_content = html_content.replace("{{rating}}", str(movie_data.get("vote_average", 0)))
        html_content = html_content.replace("{{release_year}}", movie_data.get("release_year", "N/A"))
        html_content = html_content.replace("{{movie_url}}", f"{self.frontend_url}/movie/{movie_data.get('movie_id', '')}")
        html_content = html_content.replace("{{unsubscribe_url}}", f"{self.frontend_url}/unsubscribe?email={to_email}")

        subject = f"🎬 فیلم جدید: {movie_data.get('title', '')} - VortexFilm"
        return self._send_email(to_email, subject, html_content)

    def send_weekly_recommendations(self, to_email: str, user_name: str, recommendations: Dict) -> bool:
        """ارسال توصیه‌های هفتگی"""
        template = self._load_template("weekly_recommendations")
        if not template:
            logger.error("weekly_recommendations template not found")
            return False

        def create_movie_item(movie: Dict) -> str:
            return f'''
            <div class="movie-item">
                <img src="{movie.get('poster_url', '')}" alt="{movie.get('title', '')}" class="movie-poster-small">
                <div class="movie-details">
                    <div class="movie-title-small">{movie.get('title', '')}</div>
                    <div class="movie-description">{movie.get('overview', '')[:80]}...</div>
                    <div class="movie-meta">⭐ {movie.get('vote_average', 0)}/10</div>
                    <a href="{self.frontend_url}/movie/{movie.get('_id', '')}" class="button">مشاهده</a>
                </div>
            </div>
            '''

        # ساخت HTML برای هر دسته
        top_movies_html = "".join([create_movie_item(m) for m in recommendations.get("top_movies", [])[:3]])
        top_rated_html = "".join([create_movie_item(m) for m in recommendations.get("top_rated", [])[:3]])
        new_movies_html = "".join([create_movie_item(m) for m in recommendations.get("new_movies", [])[:3]])

        # جایگزینی متغیرها
        html_content = template
        html_content = html_content.replace("{{user_name}}", user_name)
        html_content = html_content.replace("{{top_movies_html}}", top_movies_html)
        html_content = html_content.replace("{{top_rated_html}}", top_rated_html)
        html_content = html_content.replace("{{new_movies_html}}", new_movies_html)
        html_content = html_content.replace("{{site_url}}", self.frontend_url)
        html_content = html_content.replace("{{unsubscribe_url}}", f"{self.frontend_url}/unsubscribe?email={to_email}")

        subject = "📺 توصیه‌های هفتگی VortexFilm"
        return self._send_email(to_email, subject, html_content)

    def send_bulk_emails(self, email_list: List[str], subject: str, html_content: str) -> Dict:
        """ارسال ایمیل به لیست"""
        results = {"success": 0, "failed": 0}
        for email in email_list:
            if self._send_email(email, subject, html_content):
                results["success"] += 1
            else:
                results["failed"] += 1
        return results


# سینگلتون instance
email_service = EmailService()
