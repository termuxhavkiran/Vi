#!/usr/bin/env python3
"""
اسکریپت برای import کردن 10 فیلم و 10 سریال از TMDB
"""

import asyncio
import aiohttp
import os
import random
from dotenv import load_dotenv

load_dotenv()

TMDB_API_KEY = os.getenv("TMDB_API_KEY", "61996de84bacda036b7c37cb27fe39e2")
TMDB_BASE_URL = "https://api.themoviedb.org/3"
BACKEND_URL = "http://localhost:8001/api"

# لیست فیلم‌های محبوب برای import (TMDB IDs)
POPULAR_MOVIE_IDS = [
    550,      # Fight Club
    13,       # Forrest Gump
    155,      # The Dark Knight
    27205,    # Inception
    680,      # Pulp Fiction
    122,      # The Lord of the Rings: The Return of the King
    120,      # The Lord of the Rings: The Fellowship of the Ring
    121,      # The Lord of the Rings: The Two Towers
    129,      # Spirited Away
    497,      # The Green Mile
    278,      # The Shawshank Redemption
    240,      # The Godfather
    424,      # Schindler's List
    389,      # 12 Angry Men
    238,      # The Godfather Part II
]

# لیست سریال‌های محبوب (TMDB IDs)
POPULAR_SERIES_IDS = [
    1396,     # Breaking Bad
    1399,     # Game of Thrones
    60735,    # The Flash
    1402,     # The Walking Dead
    46952,    # The Witcher
    82856,    # The Mandalorian
    94605,    # Arcane
    95403,    # The Recruit
    71712,    # The Good Doctor
    100088,   # The Last of Us
    88329,    # House of the Dragon
    76479,    # The Boys
    456,      # The Simpsons
    4194,     # The Mentalist
    1668,     # Friends
]


async def get_admin_token():
    """دریافت توکن admin"""
    # برای تست، باید یک admin user داشته باشید
    # می‌توانید این را در دیتابیس ایجاد کنید یا از API استفاده کنید
    
    # برای سادگی، از یک توکن موقت استفاده می‌کنیم
    # شما باید یک admin user بسازید و با آن لاگین کنید
    async with aiohttp.ClientSession() as session:
        # ابتدا یک admin user بسازید (اگر وجود ندارد)
        try:
            register_data = {
                "email": "admin@vortexfilm.com",
                "password": "admin123456",
                "full_name": "Admin User"
            }
            async with session.post(f"{BACKEND_URL}/auth/register", json=register_data) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data["access_token"]
                else:
                    print("Admin user already exists, trying to login...")
        except Exception as e:
            print(f"Registration error: {e}")
        
        # سعی کنید login کنید
        try:
            login_data = {
                "email": "admin@vortexfilm.com",
                "password": "admin123456"
            }
            async with session.post(f"{BACKEND_URL}/auth/login", json=login_data) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data["access_token"]
                else:
                    error_text = await resp.text()
                    print(f"Login failed: {error_text}")
                    return None
        except Exception as e:
            print(f"Login error: {e}")
            return None


async def import_movie(session, token, tmdb_id):
    """Import یک فیلم"""
    headers = {"Authorization": f"Bearer {token}"}
    data = {"tmdb_id": tmdb_id, "language": "fa"}
    
    try:
        async with session.post(f"{BACKEND_URL}/movies/import", json=data, headers=headers) as resp:
            result = await resp.json()
            if resp.status in [200, 201]:
                print(f"✅ فیلم با ID {tmdb_id} با موفقیت import شد")
                return True
            else:
                print(f"⚠️  فیلم {tmdb_id}: {result.get('detail', 'خطای نامشخص')}")
                return False
    except Exception as e:
        print(f"❌ خطا در import فیلم {tmdb_id}: {e}")
        return False


async def import_series(session, token, tmdb_id):
    """Import یک سریال"""
    headers = {"Authorization": f"Bearer {token}"}
    data = {"tmdb_id": tmdb_id, "language": "fa"}
    
    try:
        async with session.post(f"{BACKEND_URL}/series/import", json=data, headers=headers) as resp:
            result = await resp.json()
            if resp.status in [200, 201]:
                print(f"✅ سریال با ID {tmdb_id} با موفقیت import شد")
                return True
            else:
                print(f"⚠️  سریال {tmdb_id}: {result.get('detail', 'خطای نامشخص')}")
                return False
    except Exception as e:
        print(f"❌ خطا در import سریال {tmdb_id}: {e}")
        return False


async def verify_tmdb_api():
    """بررسی کار کردن TMDB API"""
    async with aiohttp.ClientSession() as session:
        try:
            url = f"{TMDB_BASE_URL}/movie/550"
            params = {"api_key": TMDB_API_KEY}
            async with session.get(url, params=params) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    print(f"✅ TMDB API کار می‌کند - فیلم تست: {data['title']}")
                    return True
                else:
                    print(f"❌ TMDB API خطا دارد - Status: {resp.status}")
                    return False
        except Exception as e:
            print(f"❌ خطا در بررسی TMDB API: {e}")
            return False


async def main():
    """تابع اصلی"""
    print("=" * 60)
    print("🎬 شروع Import فیلم‌ها و سریال‌ها از TMDB")
    print("=" * 60)
    
    # بررسی TMDB API
    print("\n📡 بررسی TMDB API...")
    if not await verify_tmdb_api():
        print("❌ TMDB API کار نمی‌کند. لطفاً API key را بررسی کنید.")
        return
    
    # دریافت توکن admin
    print("\n🔑 دریافت توکن admin...")
    token = await get_admin_token()
    if not token:
        print("❌ نتوانستیم توکن admin دریافت کنیم")
        return
    
    print(f"✅ توکن admin دریافت شد")
    
    async with aiohttp.ClientSession() as session:
        # Import فیلم‌ها
        print("\n🎥 شروع Import فیلم‌ها...")
        print("-" * 60)
        
        # انتخاب 10 فیلم به صورت تصادفی
        selected_movies = random.sample(POPULAR_MOVIE_IDS, min(10, len(POPULAR_MOVIE_IDS)))
        
        movie_count = 0
        for tmdb_id in selected_movies:
            success = await import_movie(session, token, tmdb_id)
            if success:
                movie_count += 1
            # تاخیر کوچک برای جلوگیری از rate limit
            await asyncio.sleep(2)
        
        print(f"\n📊 تعداد فیلم‌های import شده: {movie_count}/10")
        
        # Import سریال‌ها
        print("\n📺 شروع Import سریال‌ها...")
        print("-" * 60)
        
        # انتخاب 10 سریال به صورت تصادفی
        selected_series = random.sample(POPULAR_SERIES_IDS, min(10, len(POPULAR_SERIES_IDS)))
        
        series_count = 0
        for tmdb_id in selected_series:
            success = await import_series(session, token, tmdb_id)
            if success:
                series_count += 1
            # تاخیر کوچک برای جلوگیری از rate limit
            await asyncio.sleep(2)
        
        print(f"\n📊 تعداد سریال‌های import شده: {series_count}/10")
    
    print("\n" + "=" * 60)
    print("✨ Import کامل شد!")
    print("=" * 60)
    print(f"📊 خلاصه:")
    print(f"   - فیلم‌ها: {movie_count}/10")
    print(f"   - سریال‌ها: {series_count}/10")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
