#!/usr/bin/env python3
"""Cron script for automatic backups"""
import asyncio
import sys
import os
from pathlib import Path
from dotenv import load_dotenv
from backup_service import BackupService
import logging

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def main():
    """Run backup and cleanup old backups"""
    mongo_url = os.getenv("MONGO_URL")
    db_name = os.getenv("DB_NAME")
    uploads_dir = Path("/app/uploads")
    
    backup_service = BackupService(mongo_url, db_name, uploads_dir)
    
    logger.info("Starting scheduled backup...")
    result = backup_service.create_backup()
    
    if result.get("success"):
        logger.info(f"Backup completed: {result['backup_name']}")
        
        # Clean up old backups (keep last 10)
        logger.info("Cleaning up old backups...")
        backup_service.cleanup_old_backups(keep_count=10)
        logger.info("Cleanup completed")
    else:
        logger.error(f"Backup failed: {result.get('error')}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
