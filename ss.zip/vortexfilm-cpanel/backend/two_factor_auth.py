"""Two-Factor Authentication service"""
import hashlib
import base64
from PIL import Image
import io
import numpy as np
from typing import Optional
import logging

logger = logging.getLogger(__name__)

class TwoFactorAuth:
    def __init__(self):
        pass
    
    def hash_security_answer(self, answer: str) -> str:
        """Hash security question answer"""
        return hashlib.sha256(answer.lower().strip().encode()).hexdigest()
    
    def verify_security_answer(self, user_answer: str, stored_hash: str) -> bool:
        """Verify security answer"""
        answer_hash = self.hash_security_answer(user_answer)
        return answer_hash == stored_hash
    
    def process_face_image(self, image_data: bytes) -> Optional[str]:
        """Process and store face image
        Returns base64 encoded image or None if invalid
        """
        try:
            # Open image
            image = Image.open(io.BytesIO(image_data))
            
            # Convert to RGB if needed
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Resize to standard size (256x256)
            image = image.resize((256, 256), Image.Resampling.LANCZOS)
            
            # Convert to bytes
            buffer = io.BytesIO()
            image.save(buffer, format='JPEG', quality=85)
            image_bytes = buffer.getvalue()
            
            # Encode to base64
            image_base64 = base64.b64encode(image_bytes).decode('utf-8')
            
            logger.info("Face image processed successfully")
            return image_base64
        
        except Exception as e:
            logger.error(f"Error processing face image: {e}")
            return None
    
    def compare_faces(self, stored_image_base64: str, uploaded_image_data: bytes, tolerance: float = 0.15) -> bool:
        """Compare two face images
        Simple pixel-based comparison (for production, use face recognition library)
        """
        try:
            # Decode stored image
            stored_image_bytes = base64.b64decode(stored_image_base64)
            stored_image = Image.open(io.BytesIO(stored_image_bytes))
            stored_array = np.array(stored_image.resize((64, 64)))
            
            # Process uploaded image
            uploaded_image = Image.open(io.BytesIO(uploaded_image_data))
            if uploaded_image.mode != 'RGB':
                uploaded_image = uploaded_image.convert('RGB')
            uploaded_array = np.array(uploaded_image.resize((64, 64)))
            
            # Calculate similarity (simple MSE)
            mse = np.mean((stored_array - uploaded_array) ** 2)
            max_mse = 255 ** 2  # Maximum possible MSE
            similarity = 1 - (mse / max_mse)
            
            logger.info(f"Face comparison similarity: {similarity:.4f}")
            
            # Return True if similarity is above threshold
            return similarity >= (1 - tolerance)
        
        except Exception as e:
            logger.error(f"Error comparing faces: {e}")
            return False

# Global 2FA service instance
two_factor_auth = TwoFactorAuth()
