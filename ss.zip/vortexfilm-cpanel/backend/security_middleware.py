"""Security middleware for rate limiting and request validation"""
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
import re
import logging

logger = logging.getLogger(__name__)

# Initialize rate limiter
limiter = Limiter(key_func=get_remote_address, default_limits=["100/minute"])

# XSS patterns to detect
XSS_PATTERNS = [
    r'<script[^>]*>.*?</script>',
    r'javascript:',
    r'on\w+\s*=',
    r'<iframe[^>]*>',
    r'<object[^>]*>',
    r'<embed[^>]*>',
]

# SQL Injection patterns
SQL_PATTERNS = [
    r'(\bUNION\b.*\bSELECT\b)',
    r'(\bOR\b.*=.*)',
    r'(\bAND\b.*=.*)',
    r'(\'\s*OR\s*\')',
    r'(--)',
    r'(;\s*DROP)',
    r'(;\s*DELETE)',
    r'(EXEC\s*\()',
]

def detect_xss(text: str) -> bool:
    """Detect potential XSS attacks"""
    if not text:
        return False
    for pattern in XSS_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    return False

def detect_sql_injection(text: str) -> bool:
    """Detect potential SQL injection attacks"""
    if not text:
        return False
    for pattern in SQL_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    return False

def sanitize_input(data: any) -> any:
    """Recursively sanitize input data"""
    if isinstance(data, str):
        # Check for XSS
        if detect_xss(data):
            logger.warning(f"XSS attempt detected: {data[:50]}...")
            raise HTTPException(status_code=400, detail="محتوای مشکوک شناسایی شد")
        # Check for SQL injection
        if detect_sql_injection(data):
            logger.warning(f"SQL injection attempt detected: {data[:50]}...")
            raise HTTPException(status_code=400, detail="محتوای مشکوک شناسایی شد")
        return data
    elif isinstance(data, dict):
        return {k: sanitize_input(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [sanitize_input(item) for item in data]
    return data

async def security_middleware(request: Request, call_next):
    """Security middleware to validate and sanitize requests"""
    try:
        # Validate request size (prevent DoS)
        if request.headers.get("content-length"):
            content_length = int(request.headers.get("content-length"))
            if content_length > 10 * 1024 * 1024:  # 10MB limit
                return JSONResponse(
                    status_code=413,
                    content={"detail": "درخواست بیش از حد بزرگ است"}
                )
        
        # Add security headers
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        
        return response
    except Exception as e:
        logger.error(f"Security middleware error: {e}")
        return JSONResponse(
            status_code=500,
            content={"detail": "خطای سرور"}
        )

def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded):
    """Custom handler for rate limit exceeded"""
    return JSONResponse(
        status_code=429,
        content={"detail": "تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً کمی صبر کنید."}
    )
