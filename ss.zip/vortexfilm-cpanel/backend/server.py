from fastapi import FastAPI, HTTPException, Depends, status, Query, UploadFile, File, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import FileResponse, StreamingResponse
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv
import os
import logging
import bcrypt
import jwt
import aiohttp
from bson import ObjectId
import shutil
from pathlib import Path
from cache_manager import cache
from email_service import email_service
import asyncio
from security_middleware import limiter, security_middleware, rate_limit_exceeded_handler, sanitize_input
from slowapi.errors import RateLimitExceeded
from captcha_service import captcha_service
from two_factor_auth import two_factor_auth
from backup_service import BackupService

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="VortexFilm API", version="1.0.0")

# Add rate limiter state
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add security middleware
app.middleware("http")(security_middleware)

client = AsyncIOMotorClient(os.getenv("MONGO_URL"))
db = client[os.getenv("DB_NAME")]

TMDB_API_KEY = os.getenv("TMDB_API_KEY")
TMDB_BASE_URL = os.getenv("TMDB_BASE_URL")
TMDB_IMAGE_BASE_URL = os.getenv("TMDB_IMAGE_BASE_URL")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
JWT_SECRET = os.getenv("JWT_SECRET", "your-secret-key-change-in-production")
UPLOAD_DIR = Path("/app/uploads/videos")
MONGO_URL = os.getenv("MONGO_URL")
DB_NAME = os.getenv("DB_NAME")

security = HTTPBearer()

# Initialize backup service
backup_service = BackupService(MONGO_URL, DB_NAME, Path("/app/uploads"))

class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)
    @classmethod
    def __get_pydantic_json_schema__(cls, schema, _):
        schema.update(type="string")
        return schema

class UserRegister(BaseModel):
    email: EmailStr
    password: str
    full_name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: Dict[str, Any]

class MovieImport(BaseModel):
    tmdb_id: int
    language: str = "fa"

class ReviewCreate(BaseModel):
    movie_id: str
    rating: int = Field(..., ge=1, le=10)
    comment: str

class UserListCreate(BaseModel):
    name: str
    movies: List[str] = []

class NotificationCreate(BaseModel):
    title: str
    message: str
    type: str = "info"
    link: Optional[str] = None

class DownloadLinkCreate(BaseModel):
    quality: str
    size: Optional[str] = None
    url: Optional[str] = None
    type: str = "link"

class SeriesImport(BaseModel):
    tmdb_id: int
    language: str = "fa"

class EpisodeDownloadLink(BaseModel):
    quality: str
    size: Optional[str] = None
    url: Optional[str] = None
    type: str = "link"

class WatchProgress(BaseModel):
    series_id: str
    season_number: int
    episode_number: int
    watch_time: float  # زمان به ثانیه
    duration: Optional[float] = None  # مدت کل قسمت
    completed: bool = False

class TagCreate(BaseModel):
    name: str

class PublicListCreate(BaseModel):
    name: str
    description: Optional[str] = ""
    is_public: bool = True
    movie_ids: List[str] = []

class PublicListUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_public: Optional[bool] = None

class CaptchaVerify(BaseModel):
    captcha_id: str
    answer: str

class Setup2FA(BaseModel):
    security_question: str
    security_answer: str

class Verify2FA(BaseModel):
    email: EmailStr
    security_answer: Optional[str] = None
    captcha_id: Optional[str] = None
    captcha_answer: Optional[str] = None

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        token = credentials.credentials
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        user_id = payload.get("user_id")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = await db.users.find_one({"_id": ObjectId(user_id)}, {"password": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        user["_id"] = str(user["_id"])
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except Exception as e:
        logger.error(f"Auth error: {e}")
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_admin(current_user: Dict = Depends(get_current_user)):
    """Check if current user is admin"""
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user


async def tmdb_request(endpoint: str, params: Dict = None, use_cache: bool = True) -> Dict:
    if params is None:
        params = {}
    params["api_key"] = TMDB_API_KEY
    
    # Generate cache key from endpoint and params
    cache_key = f"{endpoint}:{str(sorted(params.items()))}"
    
    # Check cache first
    if use_cache:
        cached_data = cache.get('tmdb_movie', cache_key)
        if cached_data:
            logger.info(f"Cache hit for: {endpoint}")
            return cached_data
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(f"{TMDB_BASE_URL}{endpoint}", params=params, timeout=aiohttp.ClientTimeout(total=30)) as response:
                if response.status == 200:
                    data = await response.json()
                    # Store in cache
                    if use_cache:
                        cache.set('tmdb_movie', cache_key, data)
                        logger.info(f"Cached: {endpoint}")
                    return data
                else:
                    logger.error(f"TMDB error: {response.status}")
                    return None
        except Exception as e:
            logger.error(f"TMDB request failed: {e}")
            return None

async def groq_request(system_prompt: str, user_prompt: str) -> str:
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": GROQ_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 1000
    }
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=60)) as response:
                if response.status == 200:
                    data = await response.json()
                    return data["choices"][0]["message"]["content"]
                else:
                    logger.error(f"GROQ error: {response.status}")
                    return None
        except Exception as e:
            logger.error(f"GROQ request failed: {e}")
            return None

async def translate_with_groq(text: str, context: str = "general") -> str:
    """ترجمه متن انگلیسی به فارسی با استفاده از Groq AI و کش"""
    if not text or not text.strip():
        return text
    
    # بررسی کش ترجمه
    cache_key = f"{context}:{text[:100]}"  # استفاده از 100 کاراکتر اول برای کلید
    cached_translation = cache.get('ai_translation', cache_key)
    if cached_translation:
        logger.info(f"Translation cache hit for: {text[:30]}...")
        return cached_translation
    
    system = "تو یک مترجم حرفه‌ای هستی که متن‌های انگلیسی را به فارسی روان و طبیعی ترجمه می‌کنی."
    
    if context == "title":
        user = f"این عنوان یک فیلم یا سریال است. لطفاً آن را به فارسی ترجمه کن (فقط ترجمه را بنویس، بدون توضیح اضافی):\n{text}"
    elif context == "overview":
        user = f"این خلاصه داستان یک فیلم یا سریال است. لطفاً آن را به فارسی روان ترجمه کن:\n{text}"
    elif context == "episode":
        user = f"این عنوان یک قسمت از سریال است. لطفاً آن را به فارسی ترجمه کن:\n{text}"
    else:
        user = f"لطفاً این متن را به فارسی ترجمه کن:\n{text}"
    
    try:
        translation = await groq_request(system, user)
        if translation:
            translation = translation.strip()
            # ذخیره در کش برای استفاده‌های بعدی
            cache.set('ai_translation', cache_key, translation)
            logger.info(f"Translation cached for: {text[:30]}...")
            return translation
        return text
    except Exception as e:
        logger.error(f"Translation error: {e}")
        return text

@app.post("/api/auth/register", response_model=TokenResponse)
@limiter.limit("5/minute")
async def register(request: Request, user_data: UserRegister):
    # Sanitize inputs
    sanitize_input(user_data.full_name)
    
    # Validate password strength
    if len(user_data.password) < 8:
        raise HTTPException(status_code=400, detail="رمز عبور باید حداقل 8 کاراکتر باشد")
    
    existing = await db.users.find_one({"email": user_data.email})
    if existing:
        raise HTTPException(status_code=400, detail="ایمیل قبلاً ثبت شده است")
    
    hashed = bcrypt.hashpw(user_data.password.encode('utf-8'), bcrypt.gensalt())
    user_doc = {
        "email": user_data.email,
        "password": hashed.decode('utf-8'),
        "full_name": user_data.full_name,
        "role": "user",
        "created_at": datetime.now(timezone.utc),
        "watch_later": [],
        "favorites": [],
        "2fa_enabled": False
    }
    
    result = await db.users.insert_one(user_doc)
    user_id = str(result.inserted_id)
    
    token = jwt.encode({
        "user_id": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(days=30)
    }, JWT_SECRET, algorithm="HS256")
    
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user_id,
            "email": user_data.email,
            "full_name": user_data.full_name,
            "role": "user"
        }
    }

@app.post("/api/auth/login", response_model=TokenResponse)
@limiter.limit("10/minute")
async def login(request: Request, credentials: UserLogin):
    user = await db.users.find_one({"email": credentials.email})
    if not user:
        raise HTTPException(status_code=401, detail="ایمیل یا رمز عبور اشتباه است")
    
    if not bcrypt.checkpw(credentials.password.encode('utf-8'), user["password"].encode('utf-8')):
        raise HTTPException(status_code=401, detail="ایمیل یا رمز عبور اشتباه است")
    
    user_id = str(user["_id"])
    token = jwt.encode({
        "user_id": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(days=30)
    }, JWT_SECRET, algorithm="HS256")
    
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user_id,
            "email": user["email"],
            "full_name": user["full_name"],
            "role": user.get("role", "user")
        }
    }

@app.get("/api/auth/me")
async def get_me(current_user: Dict = Depends(get_current_user)):
    return current_user

@app.get("/api/movies")
async def get_movies(page: int = Query(1, ge=1), language: str = Query("fa")):
    skip = (page - 1) * 20
    movies = await db.movies.find({}).sort("created_at", -1).skip(skip).limit(20).to_list(20)
    for movie in movies:
        movie["_id"] = str(movie["_id"])
    total = await db.movies.count_documents({})
    return {"movies": movies, "total": total, "page": page, "per_page": 20}

@app.get("/api/movies/search")
async def search_movies(q: str = Query(..., min_length=1), language: str = Query("fa")):
    data = await tmdb_request("/search/movie", {"query": q, "language": language, "page": 1})
    if not data:
        return {"results": []}
    return {"results": data.get("results", [])}

@app.get("/api/movies/{movie_id}")
async def get_movie(movie_id: str):
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    # افزایش تعداد بازدید
    await db.movies.update_one(
        {"_id": ObjectId(movie_id)},
        {"$inc": {"view_count": 1}}
    )
    
    movie["_id"] = str(movie["_id"])
    # اطمینان از وجود فیلدهای جدید
    if "view_count" not in movie:
        movie["view_count"] = 1
    if "tags" not in movie:
        movie["tags"] = []
    
    return movie

@app.post("/api/movies/import")
async def import_movie(data: MovieImport, background_tasks: BackgroundTasks, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند فیلم وارد کند")
    
    existing = await db.movies.find_one({"tmdb_id": data.tmdb_id})
    if existing:
        return {"message": "فیلم قبلاً وارد شده است", "movie_id": str(existing["_id"])}
    
    # دریافت اطلاعات از TMDB به زبان انگلیسی
    movie_data = await tmdb_request(f"/movie/{data.tmdb_id}", {"language": "en", "append_to_response": "credits,videos,images,keywords"})
    if not movie_data:
        raise HTTPException(status_code=404, detail="فیلم در TMDB یافت نشد")
    
    # ترجمه عنوان و خلاصه و tagline به فارسی با Groq
    title_fa = await translate_with_groq(movie_data.get("title", ""), "title")
    overview_fa = await translate_with_groq(movie_data.get("overview", ""), "overview")
    tagline_fa = await translate_with_groq(movie_data.get("tagline", ""), "general") if movie_data.get("tagline") else ""
    
    # ترجمه ژانرها
    genres_fa = []
    genres_en = []
    for g in movie_data.get("genres", []):
        genre_name_en = g["name"]
        genres_en.append(genre_name_en)
        genre_name_fa = await translate_with_groq(genre_name_en, "general")
        genres_fa.append(genre_name_fa)
    
    # ترجمه Collection (مجموعه)
    collection_data = None
    if movie_data.get("belongs_to_collection"):
        collection = movie_data["belongs_to_collection"]
        collection_name_fa = await translate_with_groq(collection.get("name", ""), "title")
        collection_data = {
            "id": collection.get("id"),
            "name": collection_name_fa,
            "original_name": collection.get("name", ""),
            "poster_path": collection.get("poster_path"),
            "backdrop_path": collection.get("backdrop_path")
        }
    
    # ترجمه Production Companies (شرکت‌های تولید)
    production_companies_fa = []
    production_companies_en = []
    for company in movie_data.get("production_companies", [])[:5]:
        company_name_en = company.get("name", "")
        if company_name_en:
            production_companies_en.append(company_name_en)
            company_name_fa = await translate_with_groq(company_name_en, "general")
            production_companies_fa.append(company_name_fa)
    
    # ترجمه Production Countries (کشورهای تولید)
    production_countries_fa = []
    production_countries_en = []
    for country in movie_data.get("production_countries", []):
        country_name_en = country.get("name", "")
        if country_name_en:
            production_countries_en.append(country_name_en)
            country_name_fa = await translate_with_groq(country_name_en, "general")
            production_countries_fa.append(country_name_fa)
    
    # ترجمه Spoken Languages (زبان‌های گفته شده)
    spoken_languages_fa = []
    spoken_languages_en = []
    for lang in movie_data.get("spoken_languages", []):
        lang_name_en = lang.get("english_name", "")
        if lang_name_en:
            spoken_languages_en.append(lang_name_en)
            lang_name_fa = await translate_with_groq(lang_name_en, "general")
            spoken_languages_fa.append(lang_name_fa)
    
    movie_doc = {
        "tmdb_id": data.tmdb_id,
        "title": title_fa,
        "original_title": movie_data.get("title", ""),
        "overview": overview_fa,
        "original_overview": movie_data.get("overview", ""),
        "release_date": movie_data.get("release_date", ""),
        "poster_path": movie_data.get("poster_path"),
        "backdrop_path": movie_data.get("backdrop_path"),
        "genres": genres_fa,
        "genres_en": genres_en,
        "runtime": movie_data.get("runtime", 0),
        "vote_average": movie_data.get("vote_average", 0),
        "vote_count": movie_data.get("vote_count", 0),
        "imdb_id": movie_data.get("imdb_id"),
        "budget": movie_data.get("budget", 0),
        "revenue": movie_data.get("revenue", 0),
        "tagline": tagline_fa,
        "status": movie_data.get("status", ""),
        "original_language": movie_data.get("original_language", ""),
        "collection": collection_data,
        "production_companies": production_companies_fa,
        "production_companies_en": production_companies_en,
        "production_countries": production_countries_fa,
        "production_countries_en": production_countries_en,
        "spoken_languages": spoken_languages_fa,
        "spoken_languages_en": spoken_languages_en,
        "cast": [],
        "crew": [],
        "videos": [],
        "images": [],
        "download_links": [],
        "keywords": [],
        "keywords_en": [],
        "tags": [],
        "view_count": 0,
        "created_at": datetime.now(timezone.utc),
        "ai_analysis": {}
    }
    
    # ترجمه cast (بازیگران و شخصیت‌ها)
    credits = movie_data.get("credits", {})
    cast_list = []
    for c in credits.get("cast", [])[:15]:
        character_fa = await translate_with_groq(c["character"], "general") if c.get("character") else c.get("character", "")
        cast_list.append({
            "name": c["name"],
            "character": character_fa,
            "character_en": c.get("character", ""),
            "profile_path": c.get("profile_path")
        })
    movie_doc["cast"] = cast_list
    
    # crew
    movie_doc["crew"] = [{"name": c["name"], "job": c["job"], "department": c["department"]} for c in credits.get("crew", []) if c["job"] in ["Director", "Writer", "Producer"]]
    
    # ترجمه عنوان تریلرها و ویدیوها
    videos = movie_data.get("videos", {}).get("results", [])
    video_list = []
    for v in videos:
        if v["site"] == "YouTube" and v["type"] in ["Trailer", "Teaser"]:
            video_name_fa = await translate_with_groq(v.get("name", ""), "general") if v.get("name") else v.get("name", "")
            video_list.append({
                "key": v["key"],
                "site": v["site"],
                "type": v["type"],
                "name": video_name_fa,
                "name_en": v.get("name", "")
            })
    movie_doc["videos"] = video_list
    
    # ترجمه keywords (کلمات کلیدی)
    keywords_data = movie_data.get("keywords", {}).get("keywords", [])
    keywords_fa = []
    keywords_en = []
    for kw in keywords_data[:10]:  # محدود به 10 کلمه کلیدی
        kw_name_en = kw["name"]
        keywords_en.append(kw_name_en)
        kw_name_fa = await translate_with_groq(kw_name_en, "general")
        keywords_fa.append(kw_name_fa)
    movie_doc["keywords"] = keywords_fa
    movie_doc["keywords_en"] = keywords_en
    
    images_data = movie_data.get("images", {})
    movie_doc["images"] = [img["file_path"] for img in images_data.get("backdrops", [])[:10]]
    
    result = await db.movies.insert_one(movie_doc)
    movie_id = str(result.inserted_id)
    
    # ارسال اعلان به کاربران
    await create_notification_for_all_users(
        title="فیلم جدید اضافه شد!",
        message=f"فیلم {title_fa} به سایت اضافه شد.",
        notif_type="new_movie",
        link=f"/movie/{movie_id}"
    )
    
    # ارسال ایمیل به اعضای خبرنامه در background
    background_tasks.add_task(send_new_movie_emails, movie_id, title_fa, overview_fa, genres_fa, movie_data)
    
    return {"message": "فیلم با موفقیت وارد شد", "movie_id": movie_id}

@app.post("/api/movies/{movie_id}/ai/mood")
async def analyze_mood(movie_id: str):
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    if movie.get("ai_analysis", {}).get("mood"):
        return movie["ai_analysis"]["mood"]
    
    system = "تو یک تحلیلگر حرفه‌ای فیلم هستی. وظیفه‌ات تحلیل حس و هوای فیلم‌هاست."
    user = f"برای فیلم '{movie['title']}' با خلاصه داستان: {movie['overview']}، حس و هوای فیلم را در 5-6 کلمه کلیدی (مثل تاریک، سرد، پرتنش، شاعرانه، پرهیجان، نوستالژی) توصیف کن. فقط کلمات کلیدی را با کاما از هم جدا کن."
    
    result = await groq_request(system, user)
    if result:
        mood_data = {"keywords": result.strip()}
        await db.movies.update_one({"_id": ObjectId(movie_id)}, {"$set": {"ai_analysis.mood": mood_data}})
        return mood_data
    raise HTTPException(status_code=500, detail="خطا در تحلیل AI")

@app.post("/api/movies/{movie_id}/ai/characters")
async def analyze_characters(movie_id: str):
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    if movie.get("ai_analysis", {}).get("characters"):
        return movie["ai_analysis"]["characters"]
    
    cast_names = ", ".join([c["name"] for c in movie.get("cast", [])[:5]])
    system = "تو یک تحلیلگر شخصیت‌های فیلم هستی."
    user = f"برای فیلم '{movie['title']}' با بازیگران {cast_names} و خلاصه: {movie['overview']}, شخصیت‌های اصلی را تحلیل کن. برای هر شخصیت اصلی (حداکثر 3 نفر): نام، اهداف، ضعف‌ها، و مسیر رشد را در 2-3 خط توضیح بده."
    
    result = await groq_request(system, user)
    if result:
        char_data = {"analysis": result}
        await db.movies.update_one({"_id": ObjectId(movie_id)}, {"$set": {"ai_analysis.characters": char_data}})
        return char_data
    raise HTTPException(status_code=500, detail="خطا در تحلیل AI")

@app.post("/api/movies/{movie_id}/ai/ending")
async def predict_ending(movie_id: str):
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    if movie.get("ai_analysis", {}).get("ending"):
        return movie["ai_analysis"]["ending"]
    
    system = "تو یک تحلیلگر داستان هستی که پایان‌های احتمالی فیلم را بدون اسپویل واقعی پیش‌بینی می‌کنی."
    user = f"برای فیلم '{movie['title']}' با ژانرهای {', '.join(movie.get('genres', []))} و خلاصه: {movie['overview']}, 3 پایان احتمالی خلاقانه (بدون اسپویل واقعی) پیشنهاد بده. هر کدام در یک خط."
    
    result = await groq_request(system, user)
    if result:
        ending_data = {"predictions": result}
        await db.movies.update_one({"_id": ObjectId(movie_id)}, {"$set": {"ai_analysis.ending": ending_data}})
        return ending_data
    raise HTTPException(status_code=500, detail="خطا در تحلیل AI")

@app.post("/api/movies/{movie_id}/ai/hidden")
async def find_hidden_details(movie_id: str):
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    if movie.get("ai_analysis", {}).get("hidden"):
        return movie["ai_analysis"]["hidden"]
    
    system = "تو یک متخصص تحلیل جزئیات پنهان و نمادهای فیلم هستی."
    user = f"برای فیلم '{movie['title']}' با ژانرهای {', '.join(movie.get('genres', []))}, چند جزئیات پنهان، نمادها، Easter Eggs، یا اشارات به فیلم‌های دیگر که ممکن است وجود داشته باشد را پیشنهاد بده. 4-5 مورد کوتاه."
    
    result = await groq_request(system, user)
    if result:
        hidden_data = {"details": result}
        await db.movies.update_one({"_id": ObjectId(movie_id)}, {"$set": {"ai_analysis.hidden": hidden_data}})
        return hidden_data
    raise HTTPException(status_code=500, detail="خطا در تحلیل AI")

@app.post("/api/reviews")
@limiter.limit("10/hour")
async def create_review(request: Request, review: ReviewCreate, current_user: Dict = Depends(get_current_user)):
    # Sanitize comment to prevent XSS
    sanitize_input(review.comment)
    
    review_doc = {
        "movie_id": ObjectId(review.movie_id),
        "user_id": ObjectId(current_user["_id"]),
        "user_name": current_user["full_name"],
        "rating": review.rating,
        "comment": review.comment,
        "likes": 0,
        "dislikes": 0,
        "liked_by": [],
        "disliked_by": [],
        "created_at": datetime.now(timezone.utc)
    }
    result = await db.reviews.insert_one(review_doc)
    return {"message": "نظر ثبت شد", "review_id": str(result.inserted_id)}

@app.get("/api/movies/{movie_id}/reviews")
async def get_reviews(movie_id: str, sort_by: str = Query("created_at", regex="^(created_at|likes)$")):
    sort_field = "likes" if sort_by == "likes" else "created_at"
    reviews = await db.reviews.find({"movie_id": ObjectId(movie_id)}).sort(sort_field, -1).to_list(50)
    for review in reviews:
        review["_id"] = str(review["_id"])
        review["movie_id"] = str(review["movie_id"])
        review["user_id"] = str(review["user_id"])
        # اطمینان از وجود فیلدهای لایک
        if "likes" not in review:
            review["likes"] = 0
        if "dislikes" not in review:
            review["dislikes"] = 0
        if "liked_by" not in review:
            review["liked_by"] = []
        if "disliked_by" not in review:
            review["disliked_by"] = []
    return {"reviews": reviews}

@app.post("/api/movies/{movie_id}/ai/review-analysis")
async def analyze_reviews(movie_id: str):
    reviews = await db.reviews.find({"movie_id": ObjectId(movie_id)}).to_list(100)
    if not reviews:
        return {"message": "نظری برای تحلیل وجود ندارد"}
    
    comments_text = "\n".join([r["comment"] for r in reviews[:30]])
    system = "تو یک تحلیلگر احساسات و نظرات کاربران هستی."
    user = f"این نظرات کاربران درباره یک فیلم است:\n{comments_text}\n\nدرصد رضایت و نارضایتی را محاسبه کن و نکات مثبت و منفی اصلی را در 3-4 خط خلاصه کن."
    
    result = await groq_request(system, user)
    if result:
        analysis = {"analysis": result, "total_reviews": len(reviews)}
        await db.movies.update_one({"_id": ObjectId(movie_id)}, {"$set": {"ai_analysis.reviews": analysis}})
        return analysis
    raise HTTPException(status_code=500, detail="خطا در تحلیل AI")

@app.post("/api/users/watch-later/{movie_id}")
async def add_watch_later(movie_id: str, current_user: Dict = Depends(get_current_user)):
    await db.users.update_one({"_id": ObjectId(current_user["_id"])}, {"$addToSet": {"watch_later": movie_id}})
    return {"message": "به لیست بعداً اضافه شد"}

@app.delete("/api/users/watch-later/{movie_id}")
async def remove_watch_later(movie_id: str, current_user: Dict = Depends(get_current_user)):
    await db.users.update_one({"_id": ObjectId(current_user["_id"])}, {"$pull": {"watch_later": movie_id}})
    return {"message": "از لیست بعداً حذف شد"}

@app.post("/api/users/favorites/{movie_id}")
async def add_favorite(movie_id: str, current_user: Dict = Depends(get_current_user)):
    await db.users.update_one({"_id": ObjectId(current_user["_id"])}, {"$addToSet": {"favorites": movie_id}})
    return {"message": "به لیست علاقه‌مندی‌ها اضافه شد"}

@app.delete("/api/users/favorites/{movie_id}")
async def remove_favorite(movie_id: str, current_user: Dict = Depends(get_current_user)):
    await db.users.update_one({"_id": ObjectId(current_user["_id"])}, {"$pull": {"favorites": movie_id}})
    return {"message": "از لیست علاقه‌مندی‌ها حذف شد"}

@app.get("/api/users/lists")
async def get_user_lists(current_user: Dict = Depends(get_current_user)):
    user = await db.users.find_one({"_id": ObjectId(current_user["_id"])})
    watch_later_ids = [ObjectId(mid) for mid in user.get("watch_later", []) if ObjectId.is_valid(mid)]
    favorites_ids = [ObjectId(mid) for mid in user.get("favorites", []) if ObjectId.is_valid(mid)]
    
    watch_later = await db.movies.find({"_id": {"$in": watch_later_ids}}).to_list(100)
    favorites = await db.movies.find({"_id": {"$in": favorites_ids}}).to_list(100)
    
    for movie in watch_later + favorites:
        movie["_id"] = str(movie["_id"])
    
    return {"watch_later": watch_later, "favorites": favorites}

@app.get("/api/genres")
async def get_genres(language: str = Query("fa")):
    data = await tmdb_request("/genre/movie/list", {"language": language})
    if data:
        return {"genres": data.get("genres", [])}
    return {"genres": []}

@app.get("/api/genres/{genre_name}/movies")
async def get_movies_by_genre(genre_name: str, page: int = Query(1, ge=1)):
    skip = (page - 1) * 20
    movies = await db.movies.find({"genres": genre_name}).sort("created_at", -1).skip(skip).limit(20).to_list(20)
    for movie in movies:
        movie["_id"] = str(movie["_id"])
    total = await db.movies.count_documents({"genres": genre_name})
    return {"movies": movies, "total": total, "page": page, "genre": genre_name}

@app.get("/api/movies/trending/{time_window}")
async def get_trending(time_window: str = "week", language: str = Query("fa")):
    data = await tmdb_request(f"/trending/movie/{time_window}", {"language": language})
    if data:
        return {"results": data.get("results", [])}
    return {"results": []}

@app.get("/api/notifications")
async def get_notifications(current_user: Dict = Depends(get_current_user), limit: int = Query(20, le=100)):
    notifications = await db.notifications.find({"user_id": ObjectId(current_user["_id"])}).sort("created_at", -1).limit(limit).to_list(limit)
    for notif in notifications:
        notif["_id"] = str(notif["_id"])
        notif["user_id"] = str(notif["user_id"])
    unread_count = await db.notifications.count_documents({"user_id": ObjectId(current_user["_id"]), "read": False})
    return {"notifications": notifications, "unread_count": unread_count}

@app.post("/api/notifications/{notification_id}/read")
async def mark_notification_read(notification_id: str, current_user: Dict = Depends(get_current_user)):
    if not ObjectId.is_valid(notification_id):
        raise HTTPException(status_code=400, detail="شناسه اعلان نامعتبر است")
    await db.notifications.update_one(
        {"_id": ObjectId(notification_id), "user_id": ObjectId(current_user["_id"])},
        {"$set": {"read": True}}
    )
    return {"message": "اعلان به عنوان خوانده شده علامت زده شد"}

@app.post("/api/notifications/read-all")
async def mark_all_notifications_read(current_user: Dict = Depends(get_current_user)):
    await db.notifications.update_many(
        {"user_id": ObjectId(current_user["_id"]), "read": False},
        {"$set": {"read": True}}
    )
    return {"message": "تمام اعلان‌ها خوانده شدند"}

async def create_notification_for_all_users(title: str, message: str, notif_type: str = "info", link: str = None):
    users = await db.users.find({}).to_list(1000)
    notifications = []
    for user in users:
        notifications.append({
            "user_id": user["_id"],
            "title": title,
            "message": message,
            "type": notif_type,
            "link": link,
            "read": False,
            "created_at": datetime.now(timezone.utc)
        })
    if notifications:
        await db.notifications.insert_many(notifications)

async def send_new_movie_emails(movie_id: str, title: str, overview: str, genres: list, movie_data: dict):
    """ارسال ایمیل فیلم جدید به اعضای خبرنامه"""
    try:
        subscribers = await db.newsletter.find({"unsubscribed": False}).to_list(1000)
        if not subscribers:
            return
        
        poster_url = f"https://image.tmdb.org/t/p/w500{movie_data.get('poster_path', '')}" if movie_data.get("poster_path") else ""
        release_year = movie_data.get("release_date", "")[:4] if movie_data.get("release_date") else "N/A"
        
        email_data = {
            "movie_id": movie_id,
            "title": title,
            "overview": overview,
            "genres": genres,
            "poster_url": poster_url,
            "vote_average": movie_data.get("vote_average", 0),
            "release_year": release_year
        }
        
        for subscriber in subscribers[:50]:  # محدودیت برای جلوگیری از overload
            try:
                email_service.send_new_movie_email(subscriber["email"], email_data)
                await asyncio.sleep(0.5)  # تاخیر کوچک بین ایمیل‌ها
            except Exception as e:
                logger.error(f"Failed to send email to {subscriber['email']}: {e}")
                continue
        
        logger.info(f"New movie emails sent for: {title}")
    except Exception as e:
        logger.error(f"Error sending new movie emails: {e}")

@app.post("/api/movies/{movie_id}/downloads/upload")
async def upload_video(movie_id: str, quality: str, file: UploadFile = File(...), current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند فایل آپلود کند")
    
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    file_extension = file.filename.split('.')[-1]
    if file_extension not in ['mp4', 'mkv', 'avi', 'mov', 'webm']:
        raise HTTPException(status_code=400, detail="فرمت فایل پشتیبانی نمی‌شود")
    
    file_name = f"{movie_id}_{quality}.{file_extension}"
    file_path = UPLOAD_DIR / file_name
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    file_size = os.path.getsize(file_path)
    size_mb = round(file_size / (1024 * 1024), 2)
    
    download_link = {
        "quality": quality,
        "size": f"{size_mb} MB",
        "filename": file_name,
        "type": "upload",
        "created_at": datetime.now(timezone.utc)
    }
    
    await db.movies.update_one(
        {"_id": ObjectId(movie_id)},
        {"$push": {"download_links": download_link}}
    )
    
    return {"message": "فایل با موفقیت آپلود شد", "download_link": download_link}

@app.post("/api/movies/{movie_id}/downloads/link")
async def add_download_link(movie_id: str, link_data: DownloadLinkCreate, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند لینک اضافه کند")
    
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    download_link = {
        "quality": link_data.quality,
        "size": link_data.size or "نامشخص",
        "url": link_data.url,
        "type": "link",
        "created_at": datetime.now(timezone.utc)
    }
    
    await db.movies.update_one(
        {"_id": ObjectId(movie_id)},
        {"$push": {"download_links": download_link}}
    )
    
    return {"message": "لینک دانلود اضافه شد", "download_link": download_link}

@app.delete("/api/movies/{movie_id}/downloads/{index}")
async def delete_download_link(movie_id: str, index: int, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند لینک حذف کند")
    
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    download_links = movie.get("download_links", [])
    if index < 0 or index >= len(download_links):
        raise HTTPException(status_code=400, detail="ایندکس نامعتبر است")
    
    link_to_delete = download_links[index]
    if link_to_delete.get("type") == "upload" and link_to_delete.get("filename"):
        file_path = UPLOAD_DIR / link_to_delete["filename"]
        if file_path.exists():
            os.remove(file_path)
    
    download_links.pop(index)
    await db.movies.update_one(
        {"_id": ObjectId(movie_id)},
        {"$set": {"download_links": download_links}}
    )
    
    return {"message": "لینک دانلود حذف شد"}

@app.get("/api/movies/{movie_id}/downloads")
async def get_download_links(movie_id: str):
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    return {"download_links": movie.get("download_links", [])}

@app.get("/api/stream/{movie_id}/{filename}")
async def stream_video(movie_id: str, filename: str):
    file_path = UPLOAD_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="فایل یافت نشد")
    
    return FileResponse(file_path, media_type="video/mp4", filename=filename)

@app.post("/api/series/import")
async def import_series(data: SeriesImport, background_tasks: BackgroundTasks, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند سریال وارد کند")
    
    existing = await db.series.find_one({"tmdb_id": data.tmdb_id})
    if existing:
        return {"message": "سریال قبلاً وارد شده است", "series_id": str(existing["_id"])}
    
    # دریافت اطلاعات سریال از TMDB
    series_data = await tmdb_request(f"/tv/{data.tmdb_id}", {"language": "en", "append_to_response": "credits,videos,images,keywords"})
    if not series_data:
        raise HTTPException(status_code=404, detail="سریال در TMDB یافت نشد")
    
    # ترجمه عنوان و خلاصه به فارسی
    title_fa = await translate_with_groq(series_data.get("name", ""), "title")
    overview_fa = await translate_with_groq(series_data.get("overview", ""), "overview")
    tagline_fa = await translate_with_groq(series_data.get("tagline", ""), "general") if series_data.get("tagline") else ""
    
    # ترجمه ژانرها
    genres_fa = []
    genres_en = []
    for g in series_data.get("genres", []):
        genre_name_en = g["name"]
        genres_en.append(genre_name_en)
        genre_name_fa = await translate_with_groq(genre_name_en, "general")
        genres_fa.append(genre_name_fa)
    
    # ترجمه Networks (شبکه‌ها)
    networks_fa = []
    networks_en = []
    for network in series_data.get("networks", []):
        network_name_en = network.get("name", "")
        if network_name_en:
            networks_en.append(network_name_en)
            network_name_fa = await translate_with_groq(network_name_en, "general")
            networks_fa.append(network_name_fa)
    
    # ترجمه Production Companies (شرکت‌های تولید)
    production_companies_fa = []
    production_companies_en = []
    for company in series_data.get("production_companies", [])[:5]:
        company_name_en = company.get("name", "")
        if company_name_en:
            production_companies_en.append(company_name_en)
            company_name_fa = await translate_with_groq(company_name_en, "general")
            production_companies_fa.append(company_name_fa)
    
    # ترجمه Production Countries (کشورهای تولید)
    production_countries_fa = []
    production_countries_en = []
    for country in series_data.get("production_countries", []):
        country_name_en = country.get("name", "")
        if country_name_en:
            production_countries_en.append(country_name_en)
            country_name_fa = await translate_with_groq(country_name_en, "general")
            production_countries_fa.append(country_name_fa)
    
    # ترجمه Spoken Languages (زبان‌های گفته شده)
    spoken_languages_fa = []
    spoken_languages_en = []
    for lang in series_data.get("spoken_languages", []):
        lang_name_en = lang.get("english_name", "")
        if lang_name_en:
            spoken_languages_en.append(lang_name_en)
            lang_name_fa = await translate_with_groq(lang_name_en, "general")
            spoken_languages_fa.append(lang_name_fa)
    
    series_doc = {
        "tmdb_id": data.tmdb_id,
        "name": title_fa,
        "original_name": series_data.get("name", ""),
        "overview": overview_fa,
        "original_overview": series_data.get("overview", ""),
        "first_air_date": series_data.get("first_air_date", ""),
        "last_air_date": series_data.get("last_air_date", ""),
        "poster_path": series_data.get("poster_path"),
        "backdrop_path": series_data.get("backdrop_path"),
        "genres": genres_fa,
        "genres_en": genres_en,
        "number_of_seasons": series_data.get("number_of_seasons", 0),
        "number_of_episodes": series_data.get("number_of_episodes", 0),
        "vote_average": series_data.get("vote_average", 0),
        "vote_count": series_data.get("vote_count", 0),
        "status": series_data.get("status", ""),
        "tagline": tagline_fa,
        "original_language": series_data.get("original_language", ""),
        "networks": networks_fa,
        "networks_en": networks_en,
        "production_companies": production_companies_fa,
        "production_companies_en": production_companies_en,
        "production_countries": production_countries_fa,
        "production_countries_en": production_countries_en,
        "spoken_languages": spoken_languages_fa,
        "spoken_languages_en": spoken_languages_en,
        "cast": [],
        "crew": [],
        "videos": [],
        "images": [],
        "keywords": [],
        "keywords_en": [],
        "created_at": datetime.now(timezone.utc)
    }
    
    # ترجمه cast
    credits = series_data.get("credits", {})
    cast_list = []
    for c in credits.get("cast", [])[:15]:
        character_fa = await translate_with_groq(c["character"], "general") if c.get("character") else c.get("character", "")
        cast_list.append({
            "name": c["name"],
            "character": character_fa,
            "character_en": c.get("character", ""),
            "profile_path": c.get("profile_path")
        })
    series_doc["cast"] = cast_list
    
    series_doc["crew"] = [{"name": c["name"], "job": c["job"], "department": c["department"]} for c in credits.get("crew", []) if c["job"] in ["Director", "Writer", "Producer", "Creator"]]
    
    # ترجمه عنوان تریلرها
    videos = series_data.get("videos", {}).get("results", [])
    video_list = []
    for v in videos:
        if v["site"] == "YouTube" and v["type"] in ["Trailer", "Teaser"]:
            video_name_fa = await translate_with_groq(v.get("name", ""), "general") if v.get("name") else v.get("name", "")
            video_list.append({
                "key": v["key"],
                "site": v["site"],
                "type": v["type"],
                "name": video_name_fa,
                "name_en": v.get("name", "")
            })
    series_doc["videos"] = video_list
    
    # ترجمه keywords
    keywords_data = series_data.get("keywords", {}).get("results", [])
    keywords_fa = []
    keywords_en = []
    for kw in keywords_data[:10]:
        kw_name_en = kw["name"]
        keywords_en.append(kw_name_en)
        kw_name_fa = await translate_with_groq(kw_name_en, "general")
        keywords_fa.append(kw_name_fa)
    series_doc["keywords"] = keywords_fa
    series_doc["keywords_en"] = keywords_en
    
    images_data = series_data.get("images", {})
    series_doc["images"] = [img["file_path"] for img in images_data.get("backdrops", [])[:10]]
    
    result = await db.series.insert_one(series_doc)
    series_id = str(result.inserted_id)
    
    # دریافت و ذخیره فصل‌ها
    for season_num in range(1, series_data.get("number_of_seasons", 0) + 1):
        season_data = await tmdb_request(f"/tv/{data.tmdb_id}/season/{season_num}", {"language": "en"})
        if season_data:
            season_name_fa = await translate_with_groq(season_data.get("name", f"Season {season_num}"), "title")
            season_overview_fa = await translate_with_groq(season_data.get("overview", ""), "overview")
            
            season_doc = {
                "series_id": ObjectId(series_id),
                "tmdb_series_id": data.tmdb_id,
                "season_number": season_num,
                "name": season_name_fa,
                "original_name": season_data.get("name", ""),
                "overview": season_overview_fa,
                "original_overview": season_data.get("overview", ""),
                "air_date": season_data.get("air_date", ""),
                "poster_path": season_data.get("poster_path"),
                "episode_count": len(season_data.get("episodes", [])),
                "created_at": datetime.now(timezone.utc)
            }
            
            season_result = await db.seasons.insert_one(season_doc)
            season_id = season_result.inserted_id
            
            # ذخیره قسمت‌ها
            for episode in season_data.get("episodes", []):
                episode_name_fa = await translate_with_groq(episode.get("name", ""), "episode")
                episode_overview_fa = await translate_with_groq(episode.get("overview", ""), "overview")
                
                episode_doc = {
                    "series_id": ObjectId(series_id),
                    "season_id": season_id,
                    "tmdb_series_id": data.tmdb_id,
                    "season_number": season_num,
                    "episode_number": episode.get("episode_number", 0),
                    "name": episode_name_fa,
                    "original_name": episode.get("name", ""),
                    "overview": episode_overview_fa,
                    "original_overview": episode.get("overview", ""),
                    "air_date": episode.get("air_date", ""),
                    "still_path": episode.get("still_path"),
                    "runtime": episode.get("runtime", 0),
                    "vote_average": episode.get("vote_average", 0),
                    "vote_count": episode.get("vote_count", 0),
                    "download_links": [],
                    "created_at": datetime.now(timezone.utc)
                }
                await db.episodes.insert_one(episode_doc)
    
    await create_notification_for_all_users(
        title="سریال جدید اضافه شد!",
        message=f"سریال {title_fa} به سایت اضافه شد.",
        notif_type="new_series",
        link=f"/series/{series_id}"
    )
    
    return {"message": "سریال با موفقیت وارد شد", "series_id": series_id}

@app.get("/api/series")
async def get_series(page: int = Query(1, ge=1)):
    skip = (page - 1) * 20
    series_list = await db.series.find({}).sort("created_at", -1).skip(skip).limit(20).to_list(20)
    for series in series_list:
        series["_id"] = str(series["_id"])
    total = await db.series.count_documents({})
    return {"series": series_list, "total": total, "page": page, "per_page": 20}

@app.get("/api/series/search")
async def search_series(q: str = Query(..., min_length=1), language: str = Query("fa")):
    data = await tmdb_request("/search/tv", {"query": q, "language": language, "page": 1})
    if not data:
        return {"results": []}
    return {"results": data.get("results", [])}

@app.get("/api/series/{series_id}")
async def get_series_detail(series_id: str):
    if not ObjectId.is_valid(series_id):
        raise HTTPException(status_code=400, detail="شناسه سریال نامعتبر است")
    
    series = await db.series.find_one({"_id": ObjectId(series_id)})
    if not series:
        raise HTTPException(status_code=404, detail="سریال یافت نشد")
    
    series["_id"] = str(series["_id"])
    
    # دریافت فصل‌ها
    seasons = await db.seasons.find({"series_id": ObjectId(series_id)}).sort("season_number", 1).to_list(100)
    for season in seasons:
        season["_id"] = str(season["_id"])
        season["series_id"] = str(season["series_id"])
    
    series["seasons"] = seasons
    return series

@app.get("/api/series/{series_id}/season/{season_number}")
async def get_season_episodes(series_id: str, season_number: int):
    if not ObjectId.is_valid(series_id):
        raise HTTPException(status_code=400, detail="شناسه سریال نامعتبر است")
    
    episodes = await db.episodes.find({
        "series_id": ObjectId(series_id),
        "season_number": season_number
    }).sort("episode_number", 1).to_list(100)
    
    for episode in episodes:
        episode["_id"] = str(episode["_id"])
        episode["series_id"] = str(episode["series_id"])
        episode["season_id"] = str(episode["season_id"])
    
    return {"episodes": episodes}

@app.post("/api/episodes/{episode_id}/downloads/upload")
async def upload_episode_video(episode_id: str, quality: str, file: UploadFile = File(...), current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند فایل آپلود کند")
    
    if not ObjectId.is_valid(episode_id):
        raise HTTPException(status_code=400, detail="شناسه قسمت نامعتبر است")
    
    episode = await db.episodes.find_one({"_id": ObjectId(episode_id)})
    if not episode:
        raise HTTPException(status_code=404, detail="قسمت یافت نشد")
    
    file_extension = file.filename.split('.')[-1]
    if file_extension not in ['mp4', 'mkv', 'avi', 'mov', 'webm']:
        raise HTTPException(status_code=400, detail="فرمت فایل پشتیبانی نمی‌شود")
    
    file_name = f"ep_{episode_id}_{quality}.{file_extension}"
    file_path = UPLOAD_DIR / file_name
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    file_size = os.path.getsize(file_path)
    size_mb = round(file_size / (1024 * 1024), 2)
    
    download_link = {
        "quality": quality,
        "size": f"{size_mb} MB",
        "filename": file_name,
        "type": "upload",
        "created_at": datetime.now(timezone.utc)
    }
    
    await db.episodes.update_one(
        {"_id": ObjectId(episode_id)},
        {"$push": {"download_links": download_link}}
    )
    
    return {"message": "فایل با موفقیت آپلود شد", "download_link": download_link}

@app.post("/api/episodes/{episode_id}/downloads/link")
async def add_episode_download_link(episode_id: str, link_data: EpisodeDownloadLink, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند لینک اضافه کند")
    
    if not ObjectId.is_valid(episode_id):
        raise HTTPException(status_code=400, detail="شناسه قسمت نامعتبر است")
    
    episode = await db.episodes.find_one({"_id": ObjectId(episode_id)})
    if not episode:
        raise HTTPException(status_code=404, detail="قسمت یافت نشد")
    
    download_link = {
        "quality": link_data.quality,
        "size": link_data.size or "نامشخص",
        "url": link_data.url,
        "type": "link",
        "created_at": datetime.now(timezone.utc)
    }
    
    await db.episodes.update_one(
        {"_id": ObjectId(episode_id)},
        {"$push": {"download_links": download_link}}
    )
    
    return {"message": "لینک دانلود اضافه شد", "download_link": download_link}

@app.delete("/api/episodes/{episode_id}/downloads/{index}")
async def delete_episode_download_link(episode_id: str, index: int, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند لینک حذف کند")
    
    if not ObjectId.is_valid(episode_id):
        raise HTTPException(status_code=400, detail="شناسه قسمت نامعتبر است")
    
    episode = await db.episodes.find_one({"_id": ObjectId(episode_id)})
    if not episode:
        raise HTTPException(status_code=404, detail="قسمت یافت نشد")
    
    download_links = episode.get("download_links", [])
    if index < 0 or index >= len(download_links):
        raise HTTPException(status_code=400, detail="ایندکس نامعتبر است")
    
    link_to_delete = download_links[index]
    if link_to_delete.get("type") == "upload" and link_to_delete.get("filename"):
        file_path = UPLOAD_DIR / link_to_delete["filename"]
        if file_path.exists():
            os.remove(file_path)
    
    download_links.pop(index)
    await db.episodes.update_one(
        {"_id": ObjectId(episode_id)},
        {"$set": {"download_links": download_links}}
    )
    
    return {"message": "لینک دانلود حذف شد"}

@app.post("/api/series/watch-progress")
async def save_watch_progress(progress: WatchProgress, current_user: Dict = Depends(get_current_user)):
    if not ObjectId.is_valid(progress.series_id):
        raise HTTPException(status_code=400, detail="شناسه سریال نامعتبر است")
    
    progress_doc = {
        "user_id": ObjectId(current_user["_id"]),
        "series_id": ObjectId(progress.series_id),
        "season_number": progress.season_number,
        "episode_number": progress.episode_number,
        "watch_time": progress.watch_time,
        "duration": progress.duration,
        "completed": progress.completed,
        "last_updated": datetime.now(timezone.utc)
    }
    
    # به‌روزرسانی یا ایجاد پیشرفت
    await db.watch_progress.update_one(
        {
            "user_id": ObjectId(current_user["_id"]),
            "series_id": ObjectId(progress.series_id),
            "season_number": progress.season_number,
            "episode_number": progress.episode_number
        },
        {"$set": progress_doc},
        upsert=True
    )
    
    return {"message": "پیشرفت ذخیره شد"}

@app.get("/api/series/{series_id}/watch-progress")
async def get_watch_progress(series_id: str, current_user: Dict = Depends(get_current_user)):
    if not ObjectId.is_valid(series_id):
        raise HTTPException(status_code=400, detail="شناسه سریال نامعتبر است")
    
    progress_list = await db.watch_progress.find({
        "user_id": ObjectId(current_user["_id"]),
        "series_id": ObjectId(series_id)
    }).to_list(1000)
    
    for progress in progress_list:
        progress["_id"] = str(progress["_id"])
        progress["user_id"] = str(progress["user_id"])
        progress["series_id"] = str(progress["series_id"])
    
    return {"progress": progress_list}

@app.get("/api/series/trending/{time_window}")
async def get_trending_series(time_window: str = "week", language: str = Query("fa")):
    data = await tmdb_request(f"/trending/tv/{time_window}", {"language": language})
    if data:
        return {"results": data.get("results", [])}
    return {"results": []}

@app.get("/api/health")
async def health_check():
    return {"status": "ok", "message": "VortexFilm API is running"}

# ===== Captcha APIs =====

@app.get("/api/captcha/generate")
async def generate_captcha():
    """تولید کپچا ریاضی جدید"""
    try:
        captcha_id, question, _ = captcha_service.generate_captcha()
        return {
            "captcha_id": captcha_id,
            "question": question
        }
    except Exception as e:
        logger.error(f"Captcha generation error: {e}")
        raise HTTPException(status_code=500, detail="خطا در تولید کپچا")

@app.post("/api/captcha/verify")
async def verify_captcha(data: CaptchaVerify):
    """تأیید پاسخ کپچا"""
    try:
        is_valid = captcha_service.verify_captcha(data.captcha_id, data.answer)
        return {
            "valid": is_valid,
            "message": "کپچا صحیح است" if is_valid else "کپچا نادرست است"
        }
    except Exception as e:
        logger.error(f"Captcha verification error: {e}")
        raise HTTPException(status_code=500, detail="خطا در تأیید کپچا")

# ===== 2FA APIs =====

@app.post("/api/auth/2fa/setup")
async def setup_2fa(data: Setup2FA, current_user: Dict = Depends(get_current_user)):
    """راه‌اندازی احراز هویت دو مرحله‌ای"""
    try:
        # Hash security answer
        answer_hash = two_factor_auth.hash_security_answer(data.security_answer)
        
        # Update user
        await db.users.update_one(
            {"_id": ObjectId(current_user["_id"])},
            {"$set": {
                "2fa_enabled": True,
                "2fa_method": "security_question",
                "security_question": data.security_question,
                "security_answer_hash": answer_hash
            }}
        )
        
        return {"message": "احراز هویت دو مرحله‌ای با موفقیت فعال شد"}
    except Exception as e:
        logger.error(f"2FA setup error: {e}")
        raise HTTPException(status_code=500, detail="خطا در راه‌اندازی 2FA")

@app.post("/api/auth/2fa/disable")
async def disable_2fa(current_user: Dict = Depends(get_current_user)):
    """غیرفعال کردن احراز هویت دو مرحله‌ای"""
    try:
        await db.users.update_one(
            {"_id": ObjectId(current_user["_id"])},
            {"$set": {
                "2fa_enabled": False
            },
            "$unset": {
                "security_question": "",
                "security_answer_hash": "",
                "face_image": ""
            }}
        )
        
        return {"message": "احراز هویت دو مرحله‌ای غیرفعال شد"}
    except Exception as e:
        logger.error(f"2FA disable error: {e}")
        raise HTTPException(status_code=500, detail="خطا در غیرفعال کردن 2FA")

@app.post("/api/auth/2fa/verify")
async def verify_2fa(data: Verify2FA):
    """تأیید احراز هویت دو مرحله‌ای"""
    try:
        user = await db.users.find_one({"email": data.email})
        if not user:
            raise HTTPException(status_code=404, detail="کاربر یافت نشد")
        
        if not user.get("2fa_enabled"):
            raise HTTPException(status_code=400, detail="احراز هویت دو مرحله‌ای فعال نیست")
        
        # Verify based on method
        if user.get("2fa_method") == "security_question":
            if not data.security_answer:
                raise HTTPException(status_code=400, detail="پاسخ امنیتی الزامی است")
            
            is_valid = two_factor_auth.verify_security_answer(
                data.security_answer,
                user["security_answer_hash"]
            )
            
            if not is_valid:
                raise HTTPException(status_code=401, detail="پاسخ امنیتی نادرست است")
            
            return {"verified": True, "message": "احراز هویت موفق"}
        
        raise HTTPException(status_code=400, detail="روش احراز هویت نامعتبر است")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"2FA verification error: {e}")
        raise HTTPException(status_code=500, detail="خطا در تأیید 2FA")

@app.get("/api/auth/2fa/status")
async def get_2fa_status(current_user: Dict = Depends(get_current_user)):
    """دریافت وضعیت احراز هویت دو مرحله‌ای"""
    return {
        "enabled": current_user.get("2fa_enabled", False),
        "method": current_user.get("2fa_method", None),
        "security_question": current_user.get("security_question", None) if current_user.get("2fa_enabled") else None
    }

# ===== Backup APIs =====

@app.post("/api/admin/backup/create")
async def create_backup(
    background_tasks: BackgroundTasks,
    current_user: Dict = Depends(get_current_admin)
):
    """ایجاد نسخه پشتیبان کامل"""
    try:
        # Run backup in background
        result = backup_service.create_backup()
        
        if result["success"]:
            return {
                "message": "نسخه پشتیبان با موفقیت ایجاد شد",
                "backup_name": result["backup_name"],
                "size_mb": result["size_mb"]
            }
        else:
            raise HTTPException(status_code=500, detail=result.get("error", "خطا در ایجاد نسخه پشتیبان"))
    except Exception as e:
        logger.error(f"Backup creation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/admin/backup/list")
async def list_backups(current_user: Dict = Depends(get_current_admin)):
    """لیست نسخه‌های پشتیبان"""
    try:
        backups = backup_service.list_backups()
        return {"backups": backups, "total": len(backups)}
    except Exception as e:
        logger.error(f"List backups error: {e}")
        raise HTTPException(status_code=500, detail="خطا در دریافت لیست نسخه‌های پشتیبان")

@app.post("/api/admin/backup/restore/{backup_name}")
async def restore_backup(
    backup_name: str,
    current_user: Dict = Depends(get_current_admin)
):
    """بازیابی از نسخه پشتیبان"""
    try:
        result = backup_service.restore_backup(backup_name)
        
        if result["success"]:
            return {
                "message": "نسخه پشتیبان با موفقیت بازیابی شد",
                "backup_name": backup_name
            }
        else:
            raise HTTPException(status_code=500, detail=result.get("error", "خطا در بازیابی نسخه پشتیبان"))
    except Exception as e:
        logger.error(f"Restore backup error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/admin/backup/{backup_name}")
async def delete_backup(
    backup_name: str,
    current_user: Dict = Depends(get_current_admin)
):
    """حذف نسخه پشتیبان"""
    try:
        result = backup_service.delete_backup(backup_name)
        
        if result["success"]:
            return {"message": "نسخه پشتیبان با موفقیت حذف شد"}
        else:
            raise HTTPException(status_code=500, detail=result.get("error", "خطا در حذف نسخه پشتیبان"))
    except Exception as e:
        logger.error(f"Delete backup error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ===== Newsletter APIs =====

class NewsletterSubscribe(BaseModel):
    email: EmailStr

@app.post("/api/newsletter/subscribe")
async def subscribe_newsletter(data: NewsletterSubscribe):
    """عضویت در خبرنامه"""
    existing = await db.newsletter.find_one({"email": data.email})
    if existing:
        if existing.get("unsubscribed", False):
            # فعال‌سازی مجدد
            await db.newsletter.update_one(
                {"email": data.email},
                {"$set": {"unsubscribed": False, "resubscribed_at": datetime.now(timezone.utc)}}
            )
            return {"message": "شما دوباره عضو خبرنامه شدید"}
        return {"message": "این ایمیل قبلاً ثبت شده است"}
    
    newsletter_doc = {
        "email": data.email,
        "subscribed_at": datetime.now(timezone.utc),
        "unsubscribed": False
    }
    await db.newsletter.insert_one(newsletter_doc)
    return {"message": "شما با موفقیت عضو خبرنامه شدید"}

@app.post("/api/newsletter/unsubscribe")
async def unsubscribe_newsletter(data: NewsletterSubscribe):
    """لغو عضویت از خبرنامه"""
    result = await db.newsletter.update_one(
        {"email": data.email},
        {"$set": {"unsubscribed": True, "unsubscribed_at": datetime.now(timezone.utc)}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="ایمیل در خبرنامه یافت نشد")
    return {"message": "عضویت شما لغو شد"}

@app.get("/api/admin/newsletter/subscribers")
async def get_newsletter_subscribers(current_user: Dict = Depends(get_current_admin)):
    """لیست اعضای خبرنامه برای ادمین"""
    subscribers = await db.newsletter.find({"unsubscribed": False}).to_list(1000)
    for sub in subscribers:
        sub["_id"] = str(sub["_id"])
    return {"subscribers": subscribers, "total": len(subscribers)}

# ===== SEO APIs =====

@app.get("/api/sitemap.xml", response_class=StreamingResponse)
async def generate_sitemap():
    """تولید خودکار نقشه سایت"""
    base_url = os.getenv("FRONTEND_URL", "http://localhost:3000")
    
    sitemap = ['<?xml version="1.0" encoding="UTF-8"?>']
    sitemap.append('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">')
    
    # صفحه اصلی
    sitemap.append(f'<url><loc>{base_url}</loc><changefreq>daily</changefreq><priority>1.0</priority></url>')
    
    # صفحات ثابت
    static_pages = ['/genres', '/series', '/tags', '/public-lists', '/login']
    for page in static_pages:
        sitemap.append(f'<url><loc>{base_url}{page}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>')
    
    # فیلم‌ها
    movies = await db.movies.find({}).to_list(1000)
    for movie in movies:
        movie_id = str(movie["_id"])
        sitemap.append(f'<url><loc>{base_url}/movie/{movie_id}</loc><changefreq>weekly</changefreq><priority>0.9</priority></url>')
    
    # سریال‌ها
    series = await db.series.find({}).to_list(1000)
    for s in series:
        series_id = str(s["_id"])
        sitemap.append(f'<url><loc>{base_url}/series/{series_id}</loc><changefreq>weekly</changefreq><priority>0.9</priority></url>')
    
    sitemap.append('</urlset>')
    
    sitemap_content = '\n'.join(sitemap)
    
    return StreamingResponse(
        iter([sitemap_content]),
        media_type="application/xml",
        headers={"Content-Disposition": "inline; filename=sitemap.xml"}
    )

@app.get("/api/robots.txt", response_class=StreamingResponse)
async def get_robots_txt():
    """فایل robots.txt"""
    base_url = os.getenv("FRONTEND_URL", "http://localhost:3000")
    robots = f"""User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/

Sitemap: {base_url}/api/sitemap.xml
"""
    return StreamingResponse(
        iter([robots]),
        media_type="text/plain",
        headers={"Content-Disposition": "inline; filename=robots.txt"}
    )

# ===== Analytics APIs =====

@app.post("/api/analytics/track")
async def track_event(
    event_type: str,
    event_data: Dict = {},
    current_user: Optional[Dict] = None
):
    """ردیابی رویدادها برای آمار"""
    tracking_doc = {
        "event_type": event_type,
        "event_data": event_data,
        "user_id": ObjectId(current_user["_id"]) if current_user else None,
        "timestamp": datetime.now(timezone.utc),
        "ip_address": None  # در production باید IP واقعی ذخیره شود
    }
    await db.analytics.insert_one(tracking_doc)
    return {"message": "Event tracked"}

@app.get("/api/admin/analytics/overview")
async def get_analytics_overview(
    days: int = Query(7, ge=1, le=90),
    current_user: Dict = Depends(get_current_admin)
):
    """آمار کلی برای ادمین"""
    start_date = datetime.now(timezone.utc) - timedelta(days=days)
    
    # آمار بازدیدها
    total_views = await db.movies.aggregate([
        {"$group": {"_id": None, "total": {"$sum": "$view_count"}}}
    ]).to_list(1)
    
    # آمار کاربران فعال
    active_users = await db.users.count_documents({
        "created_at": {"$gte": start_date}
    })
    
    # فیلم‌های پربازدید
    top_movies = await db.movies.find({}).sort("view_count", -1).limit(10).to_list(10)
    for movie in top_movies:
        movie["_id"] = str(movie["_id"])
    
    # آمار روزانه
    daily_stats = []
    for i in range(days):
        day_start = start_date + timedelta(days=i)
        day_end = day_start + timedelta(days=1)
        
        users_count = await db.users.count_documents({
            "created_at": {"$gte": day_start, "$lt": day_end}
        })
        
        movies_count = await db.movies.count_documents({
            "created_at": {"$gte": day_start, "$lt": day_end}
        })
        
        daily_stats.append({
            "date": day_start.strftime("%Y-%m-%d"),
            "new_users": users_count,
            "new_movies": movies_count
        })
    
    return {
        "total_views": total_views[0]["total"] if total_views else 0,
        "active_users": active_users,
        "top_movies": top_movies,
        "daily_stats": daily_stats,
        "period_days": days
    }

# ===== Admin APIs =====

@app.get("/api/admin/stats")
async def get_admin_stats(current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    # آمار کلی
    total_movies = await db.movies.count_documents({})
    total_series = await db.series.count_documents({})
    total_users = await db.users.count_documents({})
    total_reviews = await db.reviews.count_documents({})
    
    # فیلم‌های اخیر
    recent_movies = await db.movies.find({}).sort("created_at", -1).limit(5).to_list(5)
    for movie in recent_movies:
        movie["_id"] = str(movie["_id"])
    
    # کاربران اخیر
    recent_users = await db.users.find({}, {"password": 0}).sort("created_at", -1).limit(5).to_list(5)
    for user in recent_users:
        user["_id"] = str(user["_id"])
    
    # فیلم‌های پربازدید (فعلاً بر اساس امتیاز)
    popular_movies = await db.movies.find({}).sort("vote_average", -1).limit(5).to_list(5)
    for movie in popular_movies:
        movie["_id"] = str(movie["_id"])
    
    # آمار هفتگی فعالیت کاربران (تعداد ثبت‌نام‌ها در 7 روز اخیر)
    from datetime import timedelta
    seven_days_ago = datetime.now(timezone.utc) - timedelta(days=7)
    weekly_users = []
    for i in range(7):
        day_start = seven_days_ago + timedelta(days=i)
        day_end = day_start + timedelta(days=1)
        count = await db.users.count_documents({
            "created_at": {"$gte": day_start, "$lt": day_end}
        })
        weekly_users.append({
            "date": day_start.strftime("%Y-%m-%d"),
            "count": count
        })
    
    # آمار ماهانه فیلم‌ها (30 روز اخیر)
    thirty_days_ago = datetime.now(timezone.utc) - timedelta(days=30)
    monthly_movies = []
    for i in range(30):
        day_start = thirty_days_ago + timedelta(days=i)
        day_end = day_start + timedelta(days=1)
        count = await db.movies.count_documents({
            "created_at": {"$gte": day_start, "$lt": day_end}
        })
        if count > 0:  # فقط روزهایی که فیلم اضافه شده
            monthly_movies.append({
                "date": day_start.strftime("%Y-%m-%d"),
                "count": count
            })
    
    return {
        "totals": {
            "movies": total_movies,
            "series": total_series,
            "users": total_users,
            "reviews": total_reviews
        },
        "recent_movies": recent_movies,
        "recent_users": recent_users,
        "popular_movies": popular_movies,
        "weekly_users": weekly_users,
        "monthly_movies": monthly_movies
    }

@app.get("/api/admin/movies")
async def get_all_movies_admin(
    page: int = Query(1, ge=1),
    search: str = Query(""),
    current_user: Dict = Depends(get_current_user)
):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    skip = (page - 1) * 20
    query = {}
    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"original_title": {"$regex": search, "$options": "i"}}
        ]
    
    movies = await db.movies.find(query).sort("created_at", -1).skip(skip).limit(20).to_list(20)
    for movie in movies:
        movie["_id"] = str(movie["_id"])
    
    total = await db.movies.count_documents(query)
    return {"movies": movies, "total": total, "page": page, "per_page": 20}

class MovieUpdate(BaseModel):
    title: Optional[str] = None
    overview: Optional[str] = None
    release_date: Optional[str] = None
    poster_path: Optional[str] = None
    backdrop_path: Optional[str] = None
    genres: Optional[List[str]] = None
    runtime: Optional[int] = None
    tagline: Optional[str] = None

@app.put("/api/admin/movies/{movie_id}")
async def update_movie(
    movie_id: str,
    movie_data: MovieUpdate,
    current_user: Dict = Depends(get_current_user)
):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    update_data = {k: v for k, v in movie_data.dict().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="هیچ داده‌ای برای به‌روزرسانی ارسال نشده")
    
    result = await db.movies.update_one(
        {"_id": ObjectId(movie_id)},
        {"$set": update_data}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    return {"message": "فیلم با موفقیت به‌روزرسانی شد"}

@app.delete("/api/admin/movies/{movie_id}")
async def delete_movie(movie_id: str, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    # حذف فیلم
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    # حذف فایل‌های آپلود شده
    for link in movie.get("download_links", []):
        if link.get("type") == "upload" and link.get("filename"):
            file_path = UPLOAD_DIR / link["filename"]
            if file_path.exists():
                os.remove(file_path)
    
    # حذف نظرات مربوط به فیلم
    await db.reviews.delete_many({"movie_id": ObjectId(movie_id)})
    
    # حذف فیلم
    await db.movies.delete_one({"_id": ObjectId(movie_id)})
    
    return {"message": "فیلم و تمام اطلاعات مرتبط حذف شد"}

class MovieManualCreate(BaseModel):
    title: str
    overview: str
    release_date: Optional[str] = ""
    poster_path: Optional[str] = None
    backdrop_path: Optional[str] = None
    genres: List[str] = []
    runtime: Optional[int] = 0
    tagline: Optional[str] = ""

@app.post("/api/admin/movies/manual")
async def create_movie_manual(
    movie_data: MovieManualCreate,
    current_user: Dict = Depends(get_current_user)
):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    movie_doc = {
        "tmdb_id": None,
        "title": movie_data.title,
        "original_title": movie_data.title,
        "overview": movie_data.overview,
        "original_overview": movie_data.overview,
        "release_date": movie_data.release_date or "",
        "poster_path": movie_data.poster_path,
        "backdrop_path": movie_data.backdrop_path,
        "genres": movie_data.genres,
        "runtime": movie_data.runtime or 0,
        "vote_average": 0,
        "vote_count": 0,
        "tagline": movie_data.tagline or "",
        "status": "Released",
        "original_language": "fa",
        "cast": [],
        "crew": [],
        "videos": [],
        "images": [],
        "download_links": [],
        "created_at": datetime.now(timezone.utc),
        "ai_analysis": {}
    }
    
    result = await db.movies.insert_one(movie_doc)
    return {"message": "فیلم با موفقیت اضافه شد", "movie_id": str(result.inserted_id)}

@app.get("/api/admin/users")
async def get_all_users_admin(
    page: int = Query(1, ge=1),
    search: str = Query(""),
    role_filter: str = Query(""),
    current_user: Dict = Depends(get_current_user)
):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    skip = (page - 1) * 20
    query = {}
    
    if search:
        query["$or"] = [
            {"email": {"$regex": search, "$options": "i"}},
            {"full_name": {"$regex": search, "$options": "i"}}
        ]
    
    if role_filter and role_filter in ["admin", "user"]:
        query["role"] = role_filter
    
    users = await db.users.find(query, {"password": 0}).sort("created_at", -1).skip(skip).limit(20).to_list(20)
    for user in users:
        user["_id"] = str(user["_id"])
    
    total = await db.users.count_documents(query)
    return {"users": users, "total": total, "page": page, "per_page": 20}

@app.put("/api/admin/users/{user_id}/role")
async def update_user_role(
    user_id: str,
    role: str = Query(..., regex="^(admin|user)$"),
    current_user: Dict = Depends(get_current_user)
):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    if not ObjectId.is_valid(user_id):
        raise HTTPException(status_code=400, detail="شناسه کاربر نامعتبر است")
    
    result = await db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$set": {"role": role}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد")
    
    return {"message": f"نقش کاربر به {role} تغییر یافت"}

@app.delete("/api/admin/users/{user_id}")
async def delete_user(user_id: str, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    if not ObjectId.is_valid(user_id):
        raise HTTPException(status_code=400, detail="شناسه کاربر نامعتبر است")
    
    # جلوگیری از حذف خودش
    if str(current_user["_id"]) == user_id:
        raise HTTPException(status_code=400, detail="نمی‌توانید حساب خود را حذف کنید")
    
    # حذف نظرات کاربر
    await db.reviews.delete_many({"user_id": ObjectId(user_id)})
    
    # حذف اعلان‌های کاربر
    await db.notifications.delete_many({"user_id": ObjectId(user_id)})
    
    # حذف پیشرفت تماشای کاربر
    await db.watch_progress.delete_many({"user_id": ObjectId(user_id)})
    
    # حذف کاربر
    result = await db.users.delete_one({"_id": ObjectId(user_id)})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد")
    
    return {"message": "کاربر و تمام اطلاعات مرتبط حذف شد"}

@app.get("/api/admin/reviews")
async def get_all_reviews_admin(
    page: int = Query(1, ge=1),
    movie_id: str = Query(""),
    current_user: Dict = Depends(get_current_user)
):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    skip = (page - 1) * 20
    query = {}
    
    if movie_id and ObjectId.is_valid(movie_id):
        query["movie_id"] = ObjectId(movie_id)
    
    reviews = await db.reviews.find(query).sort("created_at", -1).skip(skip).limit(20).to_list(20)
    
    # دریافت اطلاعات فیلم برای هر نظر
    for review in reviews:
        review["_id"] = str(review["_id"])
        review["user_id"] = str(review["user_id"])
        movie = await db.movies.find_one({"_id": review["movie_id"]}, {"title": 1})
        review["movie_id"] = str(review["movie_id"])
        review["movie_title"] = movie["title"] if movie else "نامشخص"
    
    total = await db.reviews.count_documents(query)
    return {"reviews": reviews, "total": total, "page": page, "per_page": 20}

@app.delete("/api/admin/reviews/{review_id}")
async def delete_review(review_id: str, current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    if not ObjectId.is_valid(review_id):
        raise HTTPException(status_code=400, detail="شناسه نظر نامعتبر است")
    
    result = await db.reviews.delete_one({"_id": ObjectId(review_id)})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="نظر یافت نشد")
    
    return {"message": "نظر حذف شد"}

@app.get("/api/admin/ai-stats")
async def get_ai_stats(current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    # شمارش فیلم‌هایی که تحلیل AI دارند
    movies_with_mood = await db.movies.count_documents({"ai_analysis.mood": {"$exists": True}})
    movies_with_characters = await db.movies.count_documents({"ai_analysis.characters": {"$exists": True}})
    movies_with_ending = await db.movies.count_documents({"ai_analysis.ending": {"$exists": True}})
    movies_with_hidden = await db.movies.count_documents({"ai_analysis.hidden": {"$exists": True}})
    movies_with_reviews_analysis = await db.movies.count_documents({"ai_analysis.reviews": {"$exists": True}})
    
    total_movies = await db.movies.count_documents({})
    
    return {
        "total_movies": total_movies,
        "analyses": {
            "mood": movies_with_mood,
            "characters": movies_with_characters,
            "ending": movies_with_ending,
            "hidden": movies_with_hidden,
            "reviews": movies_with_reviews_analysis
        },
        "total_analyses": movies_with_mood + movies_with_characters + movies_with_ending + movies_with_hidden + movies_with_reviews_analysis
    }

class SiteSettings(BaseModel):
    site_title: Optional[str] = None
    site_description: Optional[str] = None
    site_logo: Optional[str] = None
    tmdb_api_key: Optional[str] = None
    groq_api_key: Optional[str] = None

@app.get("/api/admin/settings")
async def get_settings(current_user: Dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    settings = await db.settings.find_one({}) or {}
    if settings:
        settings["_id"] = str(settings.get("_id", ""))
    
    # افزودن کلیدهای فعلی (بدون نمایش کامل)
    settings["tmdb_api_key_exists"] = bool(os.getenv("TMDB_API_KEY"))
    settings["groq_api_key_exists"] = bool(os.getenv("GROQ_API_KEY"))
    
    return settings

@app.put("/api/admin/settings")
async def update_settings(
    settings_data: SiteSettings,
    current_user: Dict = Depends(get_current_user)
):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین دسترسی دارد")
    
    update_data = {k: v for k, v in settings_data.dict().items() if v is not None}
    
    if update_data:
        await db.settings.update_one(
            {},
            {"$set": update_data},
            upsert=True
        )
    
    return {"message": "تنظیمات با موفقیت به‌روزرسانی شد"}

# ===== فیلم‌های مشابه =====

@app.get("/api/movies/{movie_id}/similar")
async def get_similar_movies(movie_id: str, limit: int = Query(10, le=20)):
    """دریافت فیلم‌های مشابه بر اساس ژانر، بازیگران و کارگردان"""
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    # فیلم‌های مشابه بر اساس ژانر
    similar_movies = []
    genres = movie.get("genres", [])
    cast_names = [c["name"] for c in movie.get("cast", [])[:5]]
    crew_names = [c["name"] for c in movie.get("crew", []) if c.get("job") == "Director"]
    
    # جستجو بر اساس ژانر
    if genres:
        genre_movies = await db.movies.find({
            "_id": {"$ne": ObjectId(movie_id)},
            "genres": {"$in": genres}
        }).limit(limit).to_list(limit)
        similar_movies.extend(genre_movies)
    
    # جستجو بر اساس بازیگران
    if cast_names:
        cast_movies = await db.movies.find({
            "_id": {"$ne": ObjectId(movie_id)},
            "cast.name": {"$in": cast_names}
        }).limit(5).to_list(5)
        similar_movies.extend(cast_movies)
    
    # جستجو بر اساس کارگردان
    if crew_names:
        crew_movies = await db.movies.find({
            "_id": {"$ne": ObjectId(movie_id)},
            "crew.name": {"$in": crew_names}
        }).limit(5).to_list(5)
        similar_movies.extend(crew_movies)
    
    # حذف تکراری‌ها
    unique_movies = {}
    for m in similar_movies:
        m_id = str(m["_id"])
        if m_id not in unique_movies:
            m["_id"] = m_id
            unique_movies[m_id] = m
    
    result = list(unique_movies.values())[:limit]
    return {"similar_movies": result}

@app.get("/api/collections/{collection_id}")
async def get_collection_movies(collection_id: int):
    """دریافت فیلم‌های یک مجموعه (Collection) از TMDB با ترجمه"""
    # بررسی کش
    cached = await db.collections.find_one({"tmdb_id": collection_id})
    if cached:
        cached["_id"] = str(cached["_id"])
        return cached
    
    # دریافت از TMDB
    collection_data = await tmdb_request(f"/collection/{collection_id}", {"language": "en"})
    if not collection_data:
        raise HTTPException(status_code=404, detail="مجموعه در TMDB یافت نشد")
    
    # ترجمه نام و توضیحات مجموعه
    name_fa = await translate_with_groq(collection_data.get("name", ""), "title")
    overview_fa = await translate_with_groq(collection_data.get("overview", ""), "overview")
    
    # ترجمه اطلاعات فیلم‌های مجموعه
    parts_fa = []
    for part in collection_data.get("parts", [])[:10]:
        title_fa = await translate_with_groq(part.get("title", ""), "title")
        part_overview_fa = await translate_with_groq(part.get("overview", ""), "overview")
        parts_fa.append({
            "id": part.get("id"),
            "title": title_fa,
            "original_title": part.get("title", ""),
            "overview": part_overview_fa,
            "original_overview": part.get("overview", ""),
            "poster_path": part.get("poster_path"),
            "backdrop_path": part.get("backdrop_path"),
            "release_date": part.get("release_date", "")
        })
    
    collection_doc = {
        "tmdb_id": collection_id,
        "name": name_fa,
        "original_name": collection_data.get("name", ""),
        "overview": overview_fa,
        "original_overview": collection_data.get("overview", ""),
        "poster_path": collection_data.get("poster_path"),
        "backdrop_path": collection_data.get("backdrop_path"),
        "parts": parts_fa,
        "created_at": datetime.now(timezone.utc)
    }
    
    # ذخیره در دیتابیس برای استفاده بعدی
    await db.collections.insert_one(collection_doc)
    collection_doc["_id"] = str(collection_doc["_id"])
    
    return collection_doc


# ===== تاریخچه تماشا =====

@app.post("/api/watch-history/{movie_id}")
async def add_to_watch_history(movie_id: str, current_user: Dict = Depends(get_current_user)):
    """افزودن فیلم به تاریخچه تماشا"""
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    # بررسی اگر قبلاً در تاریخچه هست
    existing = await db.watch_history.find_one({
        "user_id": ObjectId(current_user["_id"]),
        "movie_id": ObjectId(movie_id)
    })
    
    if existing:
        # به‌روزرسانی زمان آخرین بازدید
        await db.watch_history.update_one(
            {"_id": existing["_id"]},
            {"$set": {"last_watched": datetime.now(timezone.utc)}}
        )
    else:
        # ایجاد رکورد جدید
        history_doc = {
            "user_id": ObjectId(current_user["_id"]),
            "movie_id": ObjectId(movie_id),
            "first_watched": datetime.now(timezone.utc),
            "last_watched": datetime.now(timezone.utc)
        }
        await db.watch_history.insert_one(history_doc)
    
    return {"message": "به تاریخچه تماشا اضافه شد"}

@app.get("/api/watch-history")
async def get_watch_history(current_user: Dict = Depends(get_current_user), limit: int = Query(50, le=100)):
    """دریافت تاریخچه تماشای کاربر"""
    history = await db.watch_history.find({
        "user_id": ObjectId(current_user["_id"])
    }).sort("last_watched", -1).limit(limit).to_list(limit)
    
    # دریافت اطلاعات فیلم‌ها
    movie_ids = [h["movie_id"] for h in history]
    movies = await db.movies.find({"_id": {"$in": movie_ids}}).to_list(len(movie_ids))
    
    # ترکیب داده‌ها
    movies_dict = {str(m["_id"]): m for m in movies}
    result = []
    for h in history:
        movie_id = str(h["movie_id"])
        if movie_id in movies_dict:
            movie_data = movies_dict[movie_id]
            movie_data["_id"] = movie_id
            movie_data["last_watched"] = h["last_watched"]
            result.append(movie_data)
    
    return {"watch_history": result}

@app.delete("/api/watch-history")
async def clear_watch_history(current_user: Dict = Depends(get_current_user)):
    """پاک کردن تاریخچه تماشا"""
    await db.watch_history.delete_many({"user_id": ObjectId(current_user["_id"])})
    return {"message": "تاریخچه تماشا پاک شد"}

@app.delete("/api/watch-history/{movie_id}")
async def remove_from_watch_history(movie_id: str, current_user: Dict = Depends(get_current_user)):
    """حذف یک فیلم از تاریخچه تماشا"""
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    await db.watch_history.delete_one({
        "user_id": ObjectId(current_user["_id"]),
        "movie_id": ObjectId(movie_id)
    })
    return {"message": "از تاریخچه تماشا حذف شد"}

# ===== سیستم توصیه هوشمند =====

@app.get("/api/recommendations")
async def get_smart_recommendations(current_user: Dict = Depends(get_current_user), limit: int = Query(10, le=20)):
    """دریافت توصیه‌های هوشمند بر اساس سلیقه کاربر"""
    
    # دریافت علاقه‌مندی‌های کاربر
    user = await db.users.find_one({"_id": ObjectId(current_user["_id"])})
    favorites_ids = [ObjectId(mid) for mid in user.get("favorites", []) if ObjectId.is_valid(mid)]
    
    # دریافت تاریخچه تماشا
    watch_history = await db.watch_history.find({
        "user_id": ObjectId(current_user["_id"])
    }).sort("last_watched", -1).limit(10).to_list(10)
    watched_ids = [h["movie_id"] for h in watch_history]
    
    # دریافت نظرات کاربر
    reviews = await db.reviews.find({
        "user_id": ObjectId(current_user["_id"])
    }).sort("rating", -1).limit(10).to_list(10)
    reviewed_ids = [r["movie_id"] for r in reviews]
    
    # ترکیب همه IDها
    all_ids = list(set([str(id) for id in favorites_ids + watched_ids + reviewed_ids if ObjectId.is_valid(str(id))]))
    
    if not all_ids:
        # اگر هیچ اطلاعاتی نداریم، فیلم‌های پرطرفدار رو برمی‌گردونیم
        popular_movies = await db.movies.find({}).sort("vote_average", -1).limit(limit).to_list(limit)
        for movie in popular_movies:
            movie["_id"] = str(movie["_id"])
        return {"recommendations": popular_movies, "reason": "popular"}
    
    # دریافت فیلم‌های مرجع
    reference_movies = await db.movies.find({
        "_id": {"$in": [ObjectId(id) for id in all_ids if ObjectId.is_valid(id)]}
    }).to_list(len(all_ids))
    
    if not reference_movies:
        popular_movies = await db.movies.find({}).sort("vote_average", -1).limit(limit).to_list(limit)
        for movie in popular_movies:
            movie["_id"] = str(movie["_id"])
        return {"recommendations": popular_movies, "reason": "popular"}
    
    # استخراج ژانرها
    all_genres = []
    for movie in reference_movies:
        all_genres.extend(movie.get("genres", []))
    
    # محاسبه ژانرهای محبوب
    from collections import Counter
    genre_counts = Counter(all_genres)
    top_genres = [genre for genre, count in genre_counts.most_common(3)]
    
    # جستجوی فیلم‌های مشابه
    recommended = await db.movies.find({
        "_id": {"$nin": [ObjectId(id) for id in all_ids if ObjectId.is_valid(id)]},
        "genres": {"$in": top_genres}
    }).sort("vote_average", -1).limit(limit * 2).to_list(limit * 2)
    
    # استفاده از Groq برای پالایش هوشمند
    if recommended and len(recommended) > limit:
        movie_titles = [m["title"] for m in recommended[:20]]
        user_preferences = ", ".join([m["title"] for m in reference_movies[:5]])
        
        system = "تو یک سیستم توصیه فیلم هوشمند هستی که بر اساس سلیقه کاربر، بهترین فیلم‌ها را پیشنهاد می‌دهی."
        user_prompt = f"کاربر این فیلم‌ها را دوست دارد: {user_preferences}\n\nاز لیست زیر، {limit} فیلم برتر را که بیشترین تطابق را با سلیقه کاربر دارند انتخاب کن و فقط عنوان‌ها را با کاما جدا کن:\n" + "\n".join(movie_titles)
        
        try:
            ai_result = await groq_request(system, user_prompt)
            if ai_result:
                # پردازش نتیجه AI
                suggested_titles = [t.strip() for t in ai_result.split(",")]
                # مرتب‌سازی بر اساس پیشنهاد AI
                sorted_movies = []
                for title in suggested_titles:
                    for movie in recommended:
                        if movie["title"].strip() in title or title in movie["title"].strip():
                            if movie not in sorted_movies:
                                sorted_movies.append(movie)
                                break
                
                if sorted_movies:
                    recommended = sorted_movies[:limit]
        except:
            pass
    
    recommended = recommended[:limit]
    for movie in recommended:
        movie["_id"] = str(movie["_id"])
    
    return {"recommendations": recommended, "reason": "personalized", "top_genres": top_genres}

# ===== برچسب‌ها و کلمات کلیدی =====

@app.post("/api/movies/{movie_id}/tags")
async def add_tag_to_movie(movie_id: str, tag: TagCreate, current_user: Dict = Depends(get_current_user)):
    """افزودن برچسب به فیلم"""
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند برچسب اضافه کند")
    
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    # اضافه کردن برچسب به فیلم
    await db.movies.update_one(
        {"_id": ObjectId(movie_id)},
        {"$addToSet": {"tags": tag.name}}
    )
    
    # ثبت برچسب در کالکشن tags برای آمارگیری
    await db.tags.update_one(
        {"name": tag.name},
        {"$inc": {"count": 1}, "$set": {"last_used": datetime.now(timezone.utc)}},
        upsert=True
    )
    
    return {"message": "برچسب اضافه شد"}

@app.delete("/api/movies/{movie_id}/tags/{tag_name}")
async def remove_tag_from_movie(movie_id: str, tag_name: str, current_user: Dict = Depends(get_current_user)):
    """حذف برچسب از فیلم"""
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="فقط ادمین می‌تواند برچسب حذف کند")
    
    if not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه فیلم نامعتبر است")
    
    await db.movies.update_one(
        {"_id": ObjectId(movie_id)},
        {"$pull": {"tags": tag_name}}
    )
    
    # کاهش شمارنده برچسب
    await db.tags.update_one(
        {"name": tag_name},
        {"$inc": {"count": -1}}
    )
    
    return {"message": "برچسب حذف شد"}

@app.get("/api/tags")
async def get_all_tags(limit: int = Query(50, le=100)):
    """دریافت همه برچسب‌ها"""
    tags = await db.tags.find({"count": {"$gt": 0}}).sort("count", -1).limit(limit).to_list(limit)
    for tag in tags:
        tag["_id"] = str(tag["_id"])
    return {"tags": tags}

@app.get("/api/tags/{tag_name}/movies")
async def get_movies_by_tag(tag_name: str, page: int = Query(1, ge=1)):
    """دریافت فیلم‌های یک برچسب"""
    skip = (page - 1) * 20
    movies = await db.movies.find({"tags": tag_name}).sort("created_at", -1).skip(skip).limit(20).to_list(20)
    for movie in movies:
        movie["_id"] = str(movie["_id"])
    total = await db.movies.count_documents({"tags": tag_name})
    return {"movies": movies, "total": total, "page": page, "tag": tag_name}

# ===== امتیازدهی به نظرات =====

@app.post("/api/reviews/{review_id}/like")
async def like_review(review_id: str, current_user: Dict = Depends(get_current_user)):
    """لایک کردن نظر"""
    if not ObjectId.is_valid(review_id):
        raise HTTPException(status_code=400, detail="شناسه نظر نامعتبر است")
    
    review = await db.reviews.find_one({"_id": ObjectId(review_id)})
    if not review:
        raise HTTPException(status_code=404, detail="نظر یافت نشد")
    
    user_id_str = str(current_user["_id"])
    
    # بررسی اگر قبلاً لایک کرده
    liked_users = review.get("liked_by", [])
    disliked_users = review.get("disliked_by", [])
    
    if user_id_str in liked_users:
        # حذف لایک
        await db.reviews.update_one(
            {"_id": ObjectId(review_id)},
            {"$pull": {"liked_by": user_id_str}, "$inc": {"likes": -1}}
        )
        return {"message": "لایک حذف شد", "action": "unlike"}
    else:
        # اگر قبلاً دیسلایک کرده، اول دیسلایک رو حذف می‌کنیم
        if user_id_str in disliked_users:
            await db.reviews.update_one(
                {"_id": ObjectId(review_id)},
                {"$pull": {"disliked_by": user_id_str}, "$inc": {"dislikes": -1}}
            )
        
        # افزودن لایک
        await db.reviews.update_one(
            {"_id": ObjectId(review_id)},
            {"$addToSet": {"liked_by": user_id_str}, "$inc": {"likes": 1}}
        )
        return {"message": "نظر لایک شد", "action": "like"}

@app.post("/api/reviews/{review_id}/dislike")
async def dislike_review(review_id: str, current_user: Dict = Depends(get_current_user)):
    """دیسلایک کردن نظر"""
    if not ObjectId.is_valid(review_id):
        raise HTTPException(status_code=400, detail="شناسه نظر نامعتبر است")
    
    review = await db.reviews.find_one({"_id": ObjectId(review_id)})
    if not review:
        raise HTTPException(status_code=404, detail="نظر یافت نشد")
    
    user_id_str = str(current_user["_id"])
    
    liked_users = review.get("liked_by", [])
    disliked_users = review.get("disliked_by", [])
    
    if user_id_str in disliked_users:
        # حذف دیسلایک
        await db.reviews.update_one(
            {"_id": ObjectId(review_id)},
            {"$pull": {"disliked_by": user_id_str}, "$inc": {"dislikes": -1}}
        )
        return {"message": "دیسلایک حذف شد", "action": "undislike"}
    else:
        # اگر قبلاً لایک کرده، اول لایک رو حذف می‌کنیم
        if user_id_str in liked_users:
            await db.reviews.update_one(
                {"_id": ObjectId(review_id)},
                {"$pull": {"liked_by": user_id_str}, "$inc": {"likes": -1}}
            )
        
        # افزودن دیسلایک
        await db.reviews.update_one(
            {"_id": ObjectId(review_id)},
            {"$addToSet": {"disliked_by": user_id_str}, "$inc": {"dislikes": 1}}
        )
        return {"message": "نظر دیسلایک شد", "action": "dislike"}

# ===== فیلتر و مرتب‌سازی پیشرفته =====

@app.get("/api/movies/advanced-search")
async def advanced_movie_search(
    page: int = Query(1, ge=1),
    sort_by: str = Query("created_at", regex="^(created_at|vote_average|title|runtime|release_date)$"),
    sort_order: str = Query("desc", regex="^(asc|desc)$"),
    year_from: Optional[int] = Query(None, ge=1900),
    year_to: Optional[int] = Query(None, le=2030),
    rating_from: Optional[float] = Query(None, ge=0, le=10),
    rating_to: Optional[float] = Query(None, ge=0, le=10),
    runtime_from: Optional[int] = Query(None, ge=0),
    runtime_to: Optional[int] = Query(None, le=500),
    language: Optional[str] = Query(None),
    genres: Optional[str] = Query(None),
):
    """جستجوی پیشرفته فیلم با فیلترها و مرتب‌سازی"""
    
    query = {}
    
    # فیلتر سال
    if year_from or year_to:
        query["release_date"] = {}
        if year_from:
            query["release_date"]["$gte"] = f"{year_from}-01-01"
        if year_to:
            query["release_date"]["$lte"] = f"{year_to}-12-31"
    
    # فیلتر امتیاز
    if rating_from is not None or rating_to is not None:
        query["vote_average"] = {}
        if rating_from is not None:
            query["vote_average"]["$gte"] = rating_from
        if rating_to is not None:
            query["vote_average"]["$lte"] = rating_to
    
    # فیلتر مدت زمان
    if runtime_from is not None or runtime_to is not None:
        query["runtime"] = {}
        if runtime_from is not None:
            query["runtime"]["$gte"] = runtime_from
        if runtime_to is not None:
            query["runtime"]["$lte"] = runtime_to
    
    # فیلتر زبان
    if language:
        query["original_language"] = language
    
    # فیلتر ژانر
    if genres:
        genre_list = [g.strip() for g in genres.split(",")]
        query["genres"] = {"$in": genre_list}
    
    # مرتب‌سازی
    sort_direction = -1 if sort_order == "desc" else 1
    
    # محاسبه pagination
    skip = (page - 1) * 20
    
    # اجرای query
    movies = await db.movies.find(query).sort(sort_by, sort_direction).skip(skip).limit(20).to_list(20)
    for movie in movies:
        movie["_id"] = str(movie["_id"])
    
    total = await db.movies.count_documents(query)
    
    return {
        "movies": movies,
        "total": total,
        "page": page,
        "per_page": 20,
        "filters": {
            "year_from": year_from,
            "year_to": year_to,
            "rating_from": rating_from,
            "rating_to": rating_to,
            "runtime_from": runtime_from,
            "runtime_to": runtime_to,
            "language": language,
            "genres": genres
        },
        "sort": {"by": sort_by, "order": sort_order}
    }

# ===== صفحه بازیگر =====

@app.get("/api/actor/{actor_id}")
async def get_actor_info(actor_id: int):
    """دریافت اطلاعات بازیگر از TMDB و ترجمه با Groq"""
    
    # بررسی کش
    cached = await db.actors.find_one({"tmdb_id": actor_id})
    if cached:
        cached["_id"] = str(cached["_id"])
        return cached
    
    # دریافت از TMDB
    actor_data = await tmdb_request(f"/person/{actor_id}", {"language": "en", "append_to_response": "movie_credits,tv_credits"})
    if not actor_data:
        raise HTTPException(status_code=404, detail="بازیگر در TMDB یافت نشد")
    
    # ترجمه بیوگرافی
    biography_fa = await translate_with_groq(actor_data.get("biography", ""), "general")
    
    # ساخت سند بازیگر
    actor_doc = {
        "tmdb_id": actor_id,
        "name": actor_data.get("name", ""),
        "biography": biography_fa,
        "original_biography": actor_data.get("biography", ""),
        "birthday": actor_data.get("birthday"),
        "deathday": actor_data.get("deathday"),
        "place_of_birth": actor_data.get("place_of_birth"),
        "profile_path": actor_data.get("profile_path"),
        "popularity": actor_data.get("popularity", 0),
        "known_for_department": actor_data.get("known_for_department"),
        "movie_credits": [],
        "created_at": datetime.now(timezone.utc)
    }
    
    # پردازش فیلم‌های بازیگر
    movie_credits = actor_data.get("movie_credits", {}).get("cast", [])
    actor_doc["movie_credits"] = [
        {
            "tmdb_id": credit.get("id"),
            "title": credit.get("title"),
            "character": credit.get("character"),
            "release_date": credit.get("release_date"),
            "poster_path": credit.get("poster_path"),
            "vote_average": credit.get("vote_average", 0)
        }
        for credit in movie_credits[:20]
    ]
    
    # ذخیره در کش
    await db.actors.insert_one(actor_doc)
    
    actor_doc["_id"] = str(actor_doc["_id"])
    return actor_doc

@app.get("/api/actor/{actor_id}/movies")
async def get_actor_movies(actor_id: int, page: int = Query(1, ge=1)):
    """دریافت فیلم‌های یک بازیگر از دیتابیس محلی"""
    
    actor = await db.actors.find_one({"tmdb_id": actor_id})
    if not actor:
        # اگر بازیگر در کش نیست، اول اطلاعاتش رو بگیر
        await get_actor_info(actor_id)
        actor = await db.actors.find_one({"tmdb_id": actor_id})
    
    actor_name = actor.get("name", "")
    
    # جستجوی فیلم‌ها در دیتابیس محلی
    skip = (page - 1) * 20
    movies = await db.movies.find({
        "cast.name": actor_name
    }).sort("release_date", -1).skip(skip).limit(20).to_list(20)
    
    for movie in movies:
        movie["_id"] = str(movie["_id"])
    
    total = await db.movies.count_documents({"cast.name": actor_name})
    
    return {"movies": movies, "total": total, "page": page, "actor_name": actor_name}

# ===== لیست‌های عمومی =====

@app.post("/api/public-lists")
async def create_public_list(list_data: PublicListCreate, current_user: Dict = Depends(get_current_user)):
    """ساخت لیست عمومی جدید"""
    
    list_doc = {
        "name": list_data.name,
        "description": list_data.description,
        "is_public": list_data.is_public,
        "owner_id": ObjectId(current_user["_id"]),
        "owner_name": current_user["full_name"],
        "movie_ids": [ObjectId(mid) for mid in list_data.movie_ids if ObjectId.is_valid(mid)],
        "followers": [],
        "created_at": datetime.now(timezone.utc),
        "updated_at": datetime.now(timezone.utc)
    }
    
    result = await db.public_lists.insert_one(list_doc)
    return {"message": "لیست با موفقیت ساخته شد", "list_id": str(result.inserted_id)}

@app.get("/api/public-lists")
async def get_public_lists(page: int = Query(1, ge=1), search: str = Query("")):
    """دریافت لیست‌های عمومی"""
    
    query = {"is_public": True}
    if search:
        query["$or"] = [
            {"name": {"$regex": search, "$options": "i"}},
            {"description": {"$regex": search, "$options": "i"}}
        ]
    
    skip = (page - 1) * 20
    lists = await db.public_lists.find(query).sort("created_at", -1).skip(skip).limit(20).to_list(20)
    
    for lst in lists:
        lst["_id"] = str(lst["_id"])
        lst["owner_id"] = str(lst["owner_id"])
        lst["movie_ids"] = [str(mid) for mid in lst["movie_ids"]]
        lst["movie_count"] = len(lst["movie_ids"])
        lst["follower_count"] = len(lst.get("followers", []))
    
    total = await db.public_lists.count_documents(query)
    return {"lists": lists, "total": total, "page": page}

@app.get("/api/public-lists/{list_id}")
async def get_public_list_detail(list_id: str):
    """دریافت جزئیات یک لیست عمومی"""
    
    if not ObjectId.is_valid(list_id):
        raise HTTPException(status_code=400, detail="شناسه لیست نامعتبر است")
    
    lst = await db.public_lists.find_one({"_id": ObjectId(list_id)})
    if not lst:
        raise HTTPException(status_code=404, detail="لیست یافت نشد")
    
    # دریافت فیلم‌ها
    movies = await db.movies.find({"_id": {"$in": lst["movie_ids"]}}).to_list(len(lst["movie_ids"]))
    for movie in movies:
        movie["_id"] = str(movie["_id"])
    
    lst["_id"] = str(lst["_id"])
    lst["owner_id"] = str(lst["owner_id"])
    lst["movie_ids"] = [str(mid) for mid in lst["movie_ids"]]
    lst["movies"] = movies
    lst["follower_count"] = len(lst.get("followers", []))
    
    return lst

@app.get("/api/my-lists")
async def get_my_lists(current_user: Dict = Depends(get_current_user)):
    """دریافت لیست‌های خودم"""
    
    lists = await db.public_lists.find({
        "owner_id": ObjectId(current_user["_id"])
    }).sort("created_at", -1).to_list(100)
    
    for lst in lists:
        lst["_id"] = str(lst["_id"])
        lst["owner_id"] = str(lst["owner_id"])
        lst["movie_ids"] = [str(mid) for mid in lst["movie_ids"]]
        lst["movie_count"] = len(lst["movie_ids"])
        lst["follower_count"] = len(lst.get("followers", []))
    
    return {"lists": lists}

@app.put("/api/public-lists/{list_id}")
async def update_public_list(
    list_id: str,
    list_data: PublicListUpdate,
    current_user: Dict = Depends(get_current_user)
):
    """ویرایش لیست"""
    
    if not ObjectId.is_valid(list_id):
        raise HTTPException(status_code=400, detail="شناسه لیست نامعتبر است")
    
    lst = await db.public_lists.find_one({"_id": ObjectId(list_id)})
    if not lst:
        raise HTTPException(status_code=404, detail="لیست یافت نشد")
    
    # بررسی مالکیت
    if str(lst["owner_id"]) != str(current_user["_id"]):
        raise HTTPException(status_code=403, detail="فقط صاحب لیست می‌تواند آن را ویرایش کند")
    
    update_data = {k: v for k, v in list_data.dict().items() if v is not None}
    update_data["updated_at"] = datetime.now(timezone.utc)
    
    await db.public_lists.update_one(
        {"_id": ObjectId(list_id)},
        {"$set": update_data}
    )
    
    return {"message": "لیست به‌روزرسانی شد"}

@app.post("/api/public-lists/{list_id}/movies/{movie_id}")
async def add_movie_to_public_list(
    list_id: str,
    movie_id: str,
    current_user: Dict = Depends(get_current_user)
):
    """افزودن فیلم به لیست"""
    
    if not ObjectId.is_valid(list_id) or not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه نامعتبر است")
    
    lst = await db.public_lists.find_one({"_id": ObjectId(list_id)})
    if not lst:
        raise HTTPException(status_code=404, detail="لیست یافت نشد")
    
    # بررسی مالکیت
    if str(lst["owner_id"]) != str(current_user["_id"]):
        raise HTTPException(status_code=403, detail="فقط صاحب لیست می‌تواند فیلم اضافه کند")
    
    # بررسی وجود فیلم
    movie = await db.movies.find_one({"_id": ObjectId(movie_id)})
    if not movie:
        raise HTTPException(status_code=404, detail="فیلم یافت نشد")
    
    await db.public_lists.update_one(
        {"_id": ObjectId(list_id)},
        {
            "$addToSet": {"movie_ids": ObjectId(movie_id)},
            "$set": {"updated_at": datetime.now(timezone.utc)}
        }
    )
    
    return {"message": "فیلم به لیست اضافه شد"}

@app.delete("/api/public-lists/{list_id}/movies/{movie_id}")
async def remove_movie_from_public_list(
    list_id: str,
    movie_id: str,
    current_user: Dict = Depends(get_current_user)
):
    """حذف فیلم از لیست"""
    
    if not ObjectId.is_valid(list_id) or not ObjectId.is_valid(movie_id):
        raise HTTPException(status_code=400, detail="شناسه نامعتبر است")
    
    lst = await db.public_lists.find_one({"_id": ObjectId(list_id)})
    if not lst:
        raise HTTPException(status_code=404, detail="لیست یافت نشد")
    
    # بررسی مالکیت
    if str(lst["owner_id"]) != str(current_user["_id"]):
        raise HTTPException(status_code=403, detail="فقط صاحب لیست می‌تواند فیلم حذف کند")
    
    await db.public_lists.update_one(
        {"_id": ObjectId(list_id)},
        {
            "$pull": {"movie_ids": ObjectId(movie_id)},
            "$set": {"updated_at": datetime.now(timezone.utc)}
        }
    )
    
    return {"message": "فیلم از لیست حذف شد"}

@app.post("/api/public-lists/{list_id}/follow")
async def follow_public_list(list_id: str, current_user: Dict = Depends(get_current_user)):
    """دنبال کردن لیست"""
    
    if not ObjectId.is_valid(list_id):
        raise HTTPException(status_code=400, detail="شناسه لیست نامعتبر است")
    
    lst = await db.public_lists.find_one({"_id": ObjectId(list_id)})
    if not lst:
        raise HTTPException(status_code=404, detail="لیست یافت نشد")
    
    user_id_str = str(current_user["_id"])
    followers = lst.get("followers", [])
    
    if user_id_str in followers:
        # آنفالو
        await db.public_lists.update_one(
            {"_id": ObjectId(list_id)},
            {"$pull": {"followers": user_id_str}}
        )
        return {"message": "لیست از دنبال شده‌ها حذف شد", "action": "unfollow"}
    else:
        # فالو
        await db.public_lists.update_one(
            {"_id": ObjectId(list_id)},
            {"$addToSet": {"followers": user_id_str}}
        )
        return {"message": "لیست دنبال شد", "action": "follow"}

@app.delete("/api/public-lists/{list_id}")
async def delete_public_list(list_id: str, current_user: Dict = Depends(get_current_user)):
    """حذف لیست"""
    
    if not ObjectId.is_valid(list_id):
        raise HTTPException(status_code=400, detail="شناسه لیست نامعتبر است")
    
    lst = await db.public_lists.find_one({"_id": ObjectId(list_id)})
    if not lst:
        raise HTTPException(status_code=404, detail="لیست یافت نشد")
    
    # بررسی مالکیت
    if str(lst["owner_id"]) != str(current_user["_id"]):
        raise HTTPException(status_code=403, detail="فقط صاحب لیست می‌تواند آن را حذف کند")
    
    await db.public_lists.delete_one({"_id": ObjectId(list_id)})
    return {"message": "لیست حذف شد"}

@app.get("/api/public-lists/following")
async def get_following_lists(current_user: Dict = Depends(get_current_user)):
    """دریافت لیست‌هایی که دنبال می‌کنم"""
    
    user_id_str = str(current_user["_id"])
    lists = await db.public_lists.find({
        "followers": user_id_str
    }).sort("updated_at", -1).to_list(100)
    
    for lst in lists:
        lst["_id"] = str(lst["_id"])
        lst["owner_id"] = str(lst["owner_id"])
        lst["movie_ids"] = [str(mid) for mid in lst["movie_ids"]]
        lst["movie_count"] = len(lst["movie_ids"])
        lst["follower_count"] = len(lst.get("followers", []))
    
    return {"lists": lists}


# ============= Cache Management APIs =============

@app.get("/api/admin/cache/stats")
async def get_cache_stats(current_user: Dict = Depends(get_current_admin)):
    """Get cache statistics (Admin only)"""
    stats = cache.get_stats()
    return {
        "success": True,
        "stats": stats
    }

@app.delete("/api/admin/cache/clear")
async def clear_all_cache(current_user: Dict = Depends(get_current_admin)):
    """Clear all cache (Admin only)"""
    cache.clear_all()
    return {
        "success": True,
        "message": "همه کش پاک شد"
    }

@app.delete("/api/admin/cache/clear/{cache_type}")
async def clear_cache_type(cache_type: str, current_user: Dict = Depends(get_current_admin)):
    """Clear specific cache type (Admin only)"""
    count = cache.clear_type(cache_type)
    return {
        "success": True,
        "message": f"{count} مورد از کش {cache_type} پاک شد",
        "cleared_count": count
    }

# ============= Weekly Newsletter APIs =============

@app.post("/api/admin/newsletter/send-weekly")
async def send_weekly_newsletter(background_tasks: BackgroundTasks, current_user: Dict = Depends(get_current_admin)):
    """ارسال توصیه‌های هفتگی به اعضای خبرنامه (فقط ادمین)"""
    background_tasks.add_task(send_weekly_recommendations_task)
    return {"message": "ارسال ایمیل‌های هفتگی شروع شد"}

async def send_weekly_recommendations_task():
    """تسک ارسال توصیه‌های هفتگی"""
    try:
        # دریافت اعضای خبرنامه
        subscribers = await db.newsletter.find({"unsubscribed": False}).to_list(1000)
        if not subscribers:
            logger.info("No subscribers found for weekly newsletter")
            return
        
        # دریافت فیلم‌های پربازدید
        top_movies = await db.movies.find({}).sort("view_count", -1).limit(5).to_list(5)
        
        # دریافت فیلم‌های با بالاترین امتیاز
        top_rated = await db.movies.find({"vote_average": {"$gte": 7}}).sort("vote_average", -1).limit(5).to_list(5)
        
        # دریافت فیلم‌های جدید (7 روز اخیر)
        seven_days_ago = datetime.now(timezone.utc) - timedelta(days=7)
        new_movies = await db.movies.find({"created_at": {"$gte": seven_days_ago}}).sort("created_at", -1).limit(5).to_list(5)
        
        # تبدیل ObjectId به string و اضافه کردن poster_url
        for movie_list in [top_movies, top_rated, new_movies]:
            for movie in movie_list:
                movie["_id"] = str(movie["_id"])
                movie["poster_url"] = f"https://image.tmdb.org/t/p/w200{movie.get('poster_path', '')}" if movie.get("poster_path") else ""
        
        recommendations = {
            "top_movies": top_movies,
            "top_rated": top_rated,
            "new_movies": new_movies
        }
        
        # ارسال به هر subscriber
        success_count = 0
        for subscriber in subscribers[:100]:  # محدود به 100 نفر در هر بار
            try:
                email_service.send_weekly_recommendations(
                    subscriber["email"],
                    "کاربر عزیز",
                    recommendations
                )
                success_count += 1
                await asyncio.sleep(1)  # تاخیر برای جلوگیری از rate limiting
            except Exception as e:
                logger.error(f"Failed to send weekly email to {subscriber['email']}: {e}")
                continue
        
        logger.info(f"Weekly recommendations sent to {success_count} subscribers")
    except Exception as e:
        logger.error(f"Error in weekly recommendations task: {e}")

# ===== Security & Captcha APIs =====

@app.get("/api/security/captcha")
@limiter.limit("20/minute")
async def get_captcha(request: Request):
    """دریافت کپچای ریاضی"""
    captcha_id, question, _ = captcha_service.generate_captcha()
    return {
        "captcha_id": captcha_id,
        "question": question
    }

@app.post("/api/security/captcha/verify")
async def verify_captcha(data: CaptchaVerify):
    """تأیید پاسخ کپچا"""
    is_valid = captcha_service.verify_captcha(data.captcha_id, data.answer)
    if not is_valid:
        raise HTTPException(status_code=400, detail="پاسخ کپچا نادرست است")
    return {"message": "کپچا با موفقیت تأیید شد"}

# ===== Two-Factor Authentication APIs =====

@app.post("/api/auth/2fa/setup")
async def setup_2fa(data: Setup2FA, current_user: Dict = Depends(get_current_user)):
    """تنظیم احراز هویت دو مرحله‌ای"""
    # Hash security answer
    answer_hash = two_factor_auth.hash_security_answer(data.security_answer)
    
    # Update user
    await db.users.update_one(
        {"_id": ObjectId(current_user["_id"])},
        {"$set": {
            "security_question": data.security_question,
            "security_answer_hash": answer_hash,
            "2fa_enabled": True
        }}
    )
    
    return {"message": "احراز هویت دو مرحله‌ای با موفقیت تنظیم شد"}

@app.post("/api/auth/2fa/upload-face")
async def upload_face_image(
    file: UploadFile = File(...),
    current_user: Dict = Depends(get_current_user)
):
    """آپلود عکس چهره برای احراز هویت"""
    # Read file
    image_data = await file.read()
    
    # Validate file type
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="فقط فایل‌های تصویری مجاز هستند")
    
    # Process and store image
    image_base64 = two_factor_auth.process_face_image(image_data)
    if not image_base64:
        raise HTTPException(status_code=400, detail="خطا در پردازش تصویر")
    
    # Update user
    await db.users.update_one(
        {"_id": ObjectId(current_user["_id"])},
        {"$set": {"face_image": image_base64}}
    )
    
    return {"message": "عکس چهره با موفقیت ذخیره شد"}

@app.post("/api/auth/2fa/verify")
@limiter.limit("10/minute")
async def verify_2fa(request: Request, data: Verify2FA):
    """تأیید مرحله دوم احراز هویت"""
    # Find user
    user = await db.users.find_one({"email": data.email})
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد")
    
    if not user.get("2fa_enabled"):
        raise HTTPException(status_code=400, detail="احراز هویت دو مرحله‌ای فعال نیست")
    
    # Verify security answer
    if data.security_answer:
        if not user.get("security_answer_hash"):
            raise HTTPException(status_code=400, detail="سوال امنیتی تنظیم نشده است")
        
        is_valid = two_factor_auth.verify_security_answer(
            data.security_answer,
            user["security_answer_hash"]
        )
        if not is_valid:
            raise HTTPException(status_code=401, detail="پاسخ امنیتی نادرست است")
        
        return {"verified": True, "method": "security_question"}
    
    # Verify captcha if provided
    if data.captcha_id and data.captcha_answer:
        is_valid = captcha_service.verify_captcha(data.captcha_id, data.captcha_answer)
        if not is_valid:
            raise HTTPException(status_code=400, detail="پاسخ کپچا نادرست است")
        return {"verified": True, "method": "captcha"}
    
    raise HTTPException(status_code=400, detail="روش احراز هویت معتبری ارائه نشده است")

@app.post("/api/auth/2fa/verify-face")
@limiter.limit("5/minute")
async def verify_face(
    request: Request,
    file: UploadFile = File(...),
    email: EmailStr = Query(...)
):
    """تأیید هویت با عکس چهره"""
    # Find user
    user = await db.users.find_one({"email": email})
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد")
    
    if not user.get("face_image"):
        raise HTTPException(status_code=400, detail="عکس چهره ثبت نشده است")
    
    # Read uploaded file
    image_data = await file.read()
    
    # Compare faces
    is_match = two_factor_auth.compare_faces(user["face_image"], image_data)
    
    if not is_match:
        raise HTTPException(status_code=401, detail="عکس چهره مطابقت ندارد")
    
    return {"verified": True, "method": "face_recognition"}

@app.get("/api/auth/2fa/status")
async def get_2fa_status(current_user: Dict = Depends(get_current_user)):
    """دریافت وضعیت احراز هویت دو مرحله‌ای"""
    return {
        "2fa_enabled": current_user.get("2fa_enabled", False),
        "has_security_question": bool(current_user.get("security_question")),
        "has_face_image": bool(current_user.get("face_image")),
        "security_question": current_user.get("security_question") if current_user.get("2fa_enabled") else None
    }

# ===== Backup & Restore APIs =====

@app.post("/api/admin/backup/create")
async def create_backup(current_user: Dict = Depends(get_current_admin)):
    """ایجاد نسخه پشتیبان"""
    result = backup_service.create_backup()
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result.get("error", "خطا در ایجاد پشتیبان"))
    return result

@app.get("/api/admin/backup/list")
async def list_backups(current_user: Dict = Depends(get_current_admin)):
    """لیست نسخه‌های پشتیبان"""
    backups = backup_service.list_backups()
    return {"backups": backups}

@app.post("/api/admin/backup/restore/{backup_name}")
async def restore_backup(backup_name: str, current_user: Dict = Depends(get_current_admin)):
    """بازیابی از نسخه پشتیبان"""
    result = backup_service.restore_backup(backup_name)
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result.get("error", "خطا در بازیابی"))
    return result

@app.delete("/api/admin/backup/{backup_name}")
async def delete_backup(backup_name: str, current_user: Dict = Depends(get_current_admin)):
    """حذف نسخه پشتیبان"""
    result = backup_service.delete_backup(backup_name)
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result.get("error", "خطا در حذف"))
    return result

@app.post("/api/admin/backup/cleanup")
async def cleanup_backups(keep_count: int = Query(10, ge=1), current_user: Dict = Depends(get_current_admin)):
    """پاکسازی نسخه‌های قدیمی"""
    backup_service.cleanup_old_backups(keep_count)
    return {"message": f"نسخه‌های قدیمی پاک شدند. {keep_count} نسخه نگه داشته شد"}

@app.on_event("shutdown")
async def shutdown():
    client.close()
