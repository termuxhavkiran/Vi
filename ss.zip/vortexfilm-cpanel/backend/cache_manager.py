"""
Cache Manager for VortexFilm
Handles caching of TMDB data, AI translations, and search results
"""
from datetime import datetime, timedelta
from typing import Optional, Any, Dict
import json
import hashlib


class CacheManager:
    def __init__(self):
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._expiry_times = {
            'tmdb_movie': timedelta(hours=24),  # فیلم‌ها 24 ساعت
            'tmdb_series': timedelta(hours=24),  # سریال‌ها 24 ساعت
            'tmdb_search': timedelta(hours=6),   # جستجو 6 ساعت
            'ai_translation': timedelta(days=7), # ترجمه هوش مصنوعی 7 روز
            'trending': timedelta(hours=2),      # ترندینگ 2 ساعت
            'genres': timedelta(days=1),         # ژانرها 1 روز
        }
    
    def _generate_key(self, prefix: str, identifier: str) -> str:
        """Generate a unique cache key"""
        combined = f"{prefix}:{identifier}"
        return hashlib.md5(combined.encode()).hexdigest()
    
    def _is_expired(self, cache_entry: Dict[str, Any]) -> bool:
        """Check if cache entry is expired"""
        if 'expires_at' not in cache_entry:
            return True
        return datetime.now() > cache_entry['expires_at']
    
    def get(self, cache_type: str, identifier: str) -> Optional[Any]:
        """Get value from cache"""
        key = self._generate_key(cache_type, identifier)
        
        if key not in self._cache:
            return None
        
        entry = self._cache[key]
        
        if self._is_expired(entry):
            del self._cache[key]
            return None
        
        return entry['data']
    
    def set(self, cache_type: str, identifier: str, data: Any) -> None:
        """Set value in cache"""
        key = self._generate_key(cache_type, identifier)
        
        expiry_delta = self._expiry_times.get(cache_type, timedelta(hours=1))
        expires_at = datetime.now() + expiry_delta
        
        self._cache[key] = {
            'data': data,
            'expires_at': expires_at,
            'cached_at': datetime.now()
        }
    
    def invalidate(self, cache_type: str, identifier: str) -> bool:
        """Remove specific item from cache"""
        key = self._generate_key(cache_type, identifier)
        
        if key in self._cache:
            del self._cache[key]
            return True
        return False
    
    def clear_all(self) -> None:
        """Clear all cache"""
        self._cache.clear()
    
    def clear_type(self, cache_type: str) -> int:
        """Clear all cache entries of a specific type"""
        keys_to_delete = []
        prefix = f"{cache_type}:"
        
        for key, entry in self._cache.items():
            if key.startswith(prefix):
                keys_to_delete.append(key)
        
        for key in keys_to_delete:
            del self._cache[key]
        
        return len(keys_to_delete)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_entries = len(self._cache)
        expired_entries = sum(1 for entry in self._cache.values() if self._is_expired(entry))
        active_entries = total_entries - expired_entries
        
        return {
            'total_entries': total_entries,
            'active_entries': active_entries,
            'expired_entries': expired_entries,
            'cache_types': list(self._expiry_times.keys())
        }


# Global cache instance
cache = CacheManager()
