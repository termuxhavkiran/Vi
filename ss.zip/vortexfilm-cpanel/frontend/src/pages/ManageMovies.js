import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { adminAPI } from '../utils/api';
import { useNavigate } from 'react-router-dom';
import { Film, Search, Edit, Trash2, Loader2, Plus, X } from 'lucide-react';

const ManageMovies = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [showEditModal, setShowEditModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [editData, setEditData] = useState({});
  const [createData, setCreateData] = useState({
    title: '',
    overview: '',
    release_date: '',
    poster_path: '',
    backdrop_path: '',
    genres: [],
    runtime: 0,
    tagline: ''
  });

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    loadMovies();
  }, [user, navigate, page, search]);

  const loadMovies = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getAllMovies(page, search);
      setMovies(response.data.movies);
      setTotal(response.data.total);
    } catch (error) {
      console.error('خطا:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (movie) => {
    setSelectedMovie(movie);
    setEditData({
      title: movie.title,
      overview: movie.overview,
      release_date: movie.release_date,
      poster_path: movie.poster_path,
      backdrop_path: movie.backdrop_path,
      genres: movie.genres || [],
      runtime: movie.runtime,
      tagline: movie.tagline || ''
    });
    setShowEditModal(true);
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await adminAPI.updateMovie(selectedMovie._id, editData);
      alert('فیلم با موفقیت به‌روزرسانی شد');
      setShowEditModal(false);
      loadMovies();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در به‌روزرسانی فیلم');
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await adminAPI.createMovieManual(createData);
      alert('فیلم با موفقیت اضافه شد');
      setShowCreateModal(false);
      setCreateData({
        title: '',
        overview: '',
        release_date: '',
        poster_path: '',
        backdrop_path: '',
        genres: [],
        runtime: 0,
        tagline: ''
      });
      loadMovies();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در افزودن فیلم');
    }
  };

  const handleDelete = async (movieId, title) => {
    if (!window.confirm(`آیا از حذف فیلم "${title}" مطمئن هستید؟`)) return;
    
    try {
      await adminAPI.deleteMovie(movieId);
      alert('فیلم با موفقیت حذف شد');
      loadMovies();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در حذف فیلم');
    }
  };

  const totalPages = Math.ceil(total / 20);

  if (loading && page === 1) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="manage-movies-page">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-black mb-2">مدیریت فیلم‌ها</h1>
          <p className="text-gray-400">مشاهده، ویرایش و حذف فیلم‌ها</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full font-bold"
        >
          <Plus className="w-5 h-5" />
          افزودن فیلم دستی
        </button>
      </div>

      {/* جستجو */}
      <div className="glass-effect rounded-2xl p-6 mb-6">
        <div className="flex items-center gap-3">
          <Search className="w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="جستجوی فیلم..."
            className="flex-1 bg-transparent border-none outline-none text-lg"
          />
        </div>
      </div>

      {/* لیست فیلم‌ها */}
      <div className="glass-effect rounded-2xl p-6 mb-6">
        <div className="space-y-4">
          {movies.map((movie) => (
            <div key={movie._id} className="flex items-center gap-4 p-4 bg-slate-900/50 rounded-xl">
              {movie.poster_path ? (
                <img
                  src={`https://image.tmdb.org/t/p/w92${movie.poster_path}`}
                  alt={movie.title}
                  className="w-16 h-24 object-cover rounded"
                />
              ) : (
                <div className="w-16 h-24 bg-slate-800 rounded flex items-center justify-center">
                  <Film className="w-8 h-8 text-gray-600" />
                </div>
              )}
              <div className="flex-1">
                <h3 className="font-bold text-lg">{movie.title}</h3>
                <p className="text-sm text-gray-400 line-clamp-2">{movie.overview}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs text-gray-500">{movie.release_date}</span>
                  <span className="text-xs text-gray-500">•</span>
                  <span className="text-xs text-gray-500">امتیاز: {movie.vote_average?.toFixed(1)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleEdit(movie)}
                  className="p-3 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-lg text-cyan-400"
                >
                  <Edit className="w-5 h-5" />
                </button>
                <button
                  onClick={() => handleDelete(movie._id, movie.title)}
                  className="p-3 bg-red-500/20 hover:bg-red-500/30 rounded-lg text-red-400"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* صفحه‌بندی */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-6">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="px-4 py-2 bg-slate-900 rounded-lg disabled:opacity-50"
            >
              قبلی
            </button>
            <span className="text-gray-400">
              صفحه {page} از {totalPages}
            </span>
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="px-4 py-2 bg-slate-900 rounded-lg disabled:opacity-50"
            >
              بعدی
            </button>
          </div>
        )}
      </div>

      {/* Modal ویرایش */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="glass-effect rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">ویرایش فیلم</h2>
              <button onClick={() => setShowEditModal(false)} className="p-2 hover:bg-white/10 rounded-full">
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={handleUpdate} className="space-y-4">
              <div>
                <label className="block mb-2 text-sm">عنوان</label>
                <input
                  type="text"
                  value={editData.title}
                  onChange={(e) => setEditData({...editData, title: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
              <div>
                <label className="block mb-2 text-sm">خلاصه داستان</label>
                <textarea
                  value={editData.overview}
                  onChange={(e) => setEditData({...editData, overview: e.target.value})}
                  rows="4"
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
              <div>
                <label className="block mb-2 text-sm">تاریخ انتشار</label>
                <input
                  type="text"
                  value={editData.release_date}
                  onChange={(e) => setEditData({...editData, release_date: e.target.value})}
                  placeholder="YYYY-MM-DD"
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
              <div>
                <label className="block mb-2 text-sm">مدت زمان (دقیقه)</label>
                <input
                  type="number"
                  value={editData.runtime}
                  onChange={(e) => setEditData({...editData, runtime: parseInt(e.target.value)})}
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold"
                >
                  ذخیره تغییرات
                </button>
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 rounded-lg font-bold"
                >
                  انصراف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal افزودن */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="glass-effect rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">افزودن فیلم دستی</h2>
              <button onClick={() => setShowCreateModal(false)} className="p-2 hover:bg-white/10 rounded-full">
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block mb-2 text-sm">عنوان *</label>
                <input
                  type="text"
                  value={createData.title}
                  onChange={(e) => setCreateData({...createData, title: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                  required
                />
              </div>
              <div>
                <label className="block mb-2 text-sm">خلاصه داستان *</label>
                <textarea
                  value={createData.overview}
                  onChange={(e) => setCreateData({...createData, overview: e.target.value})}
                  rows="4"
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                  required
                />
              </div>
              <div>
                <label className="block mb-2 text-sm">تاریخ انتشار</label>
                <input
                  type="text"
                  value={createData.release_date}
                  onChange={(e) => setCreateData({...createData, release_date: e.target.value})}
                  placeholder="YYYY-MM-DD"
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
              <div>
                <label className="block mb-2 text-sm">مدت زمان (دقیقه)</label>
                <input
                  type="number"
                  value={createData.runtime}
                  onChange={(e) => setCreateData({...createData, runtime: parseInt(e.target.value) || 0})}
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold"
                >
                  افزودن فیلم
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 rounded-lg font-bold"
                >
                  انصراف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageMovies;