import React, { useEffect, useState, useCallback } from 'react';
import { moviesAPI, seriesAPI } from '../utils/api';
import MovieCard from '../components/MovieCard';
import MovieSkeleton from '../components/MovieSkeleton';
import Newsletter from '../components/Newsletter';
import SEO from '../components/SEO';
import useInfiniteScroll from '../hooks/useInfiniteScroll';
import { Loader2, TrendingUp, Tv } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  const [series, setSeries] = useState([]);
  const [trending, setTrending] = useState([]);
  const [initialLoading, setInitialLoading] = useState(true);

  const IMAGE_BASE = process.env.REACT_APP_TMDB_IMAGE_BASE || 'https://image.tmdb.org/t/p';

  // Add SEO at the beginning of return
  const renderSEO = () => (
    <SEO
      title="خانه"
      description="تماشای آنلاین هزاران فیلم و سریال با بهترین کیفیت و زیرنویس فارسی. جدیدترین و محبوب‌ترین فیلم‌ها و سریال‌ها را در VortexFilm تماشا کنید."
      keywords="فیلم آنلاین, سریال آنلاین, دانلود فیلم, دانلود سریال, زیرنویس فارسی, فیلم جدید, سریال جدید"
    />
  );

  // Infinite scroll for movies
  const fetchMovies = useCallback(async (page) => {
    try {
      const response = await moviesAPI.getMovies(page, 'fa');
      return response.data.movies || [];
    } catch (error) {
      console.error('خطا در بارگذاری فیلم‌ها:', error);
      return [];
    }
  }, []);

  const {
    data: movies,
    loading: moviesLoading,
    hasMore,
  } = useInfiniteScroll(fetchMovies);

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    try {
      setInitialLoading(true);
      const [seriesRes, trendingRes] = await Promise.all([
        seriesAPI.getSeries(1),
        moviesAPI.getTrending('week', 'fa'),
      ]);
      setSeries(seriesRes.data.series || []);
      setTrending(trendingRes.data.results || []);
    } catch (error) {
      console.error('خطا در بارگذاری:', error);
    } finally {
      setInitialLoading(false);
    }
  };

  if (initialLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen" data-testid="loading-spinner">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <>
      {renderSEO()}
      <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="home-page">
      <div
        className="relative h-96 rounded-2xl overflow-hidden mb-8"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1746470320754-e0f1b261007e?w=1200)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent flex items-end p-8">
          <div>
            <h1 className="text-5xl md:text-6xl font-black mb-4 tracking-tighter">
              دریچه‌ای به دنیای سینما
            </h1>
            <p className="text-lg text-gray-300">
              تجربه تماشای فیلم با تحلیل‌های هوش مصنوعی
            </p>
          </div>
        </div>
      </div>

      {trending.length > 0 && (
        <section className="mb-12" data-testid="trending-section">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-6 h-6 text-fuchsia-500" />
            <h2 className="text-2xl md:text-3xl font-bold">پرطرفدار این هفته</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {trending.slice(0, 12).map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        </section>
      )}

      {series.length > 0 && (
        <section className="mb-12" data-testid="series-section">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Tv className="w-6 h-6 text-cyan-500" />
              <h2 className="text-2xl md:text-3xl font-bold">سریال‌ها</h2>
            </div>
            <Link to="/series" className="text-cyan-400 hover:text-cyan-300 text-sm">
              مشاهده همه
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {series.slice(0, 6).map((item) => (
              <Link
                key={item._id}
                to={`/series/${item._id}`}
                className="group relative overflow-hidden rounded-2xl glass-effect hover:scale-105 transition-all duration-300"
              >
                <div className="aspect-[2/3] relative">
                  {item.poster_path ? (
                    <img
                      src={`${IMAGE_BASE}/w500${item.poster_path}`}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-fuchsia-500/20 to-cyan-500/20 flex items-center justify-center">
                      <Tv className="w-16 h-16 text-white/50" />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg line-clamp-1 mb-2">{item.name}</h3>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-cyan-400">
                      {item.vote_average ? `⭐ ${item.vote_average.toFixed(1)}` : 'N/A'}
                    </span>
                    {item.number_of_seasons && (
                      <span className="text-gray-400">{item.number_of_seasons} فصل</span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section data-testid="all-movies-section">
        <h2 className="text-2xl md:text-3xl font-bold mb-6">فیلم‌های ما</h2>
        {movies.length > 0 ? (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {movies.map((movie) => (
                <MovieCard key={movie._id} movie={movie} />
              ))}
              
              {/* Loading skeleton for infinite scroll */}
              {moviesLoading && <MovieSkeleton count={6} />}
            </div>
            
            {/* Load more indicator */}
            {moviesLoading && (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-fuchsia-500" />
                <span className="mr-3 text-gray-400">در حال بارگذاری...</span>
              </div>
            )}
            
            {/* End of results */}
            {!hasMore && movies.length > 0 && (
              <div className="text-center py-8 text-gray-400">
                <p>همه فیلم‌ها نمایش داده شدند</p>
              </div>
            )}
          </>
        ) : moviesLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <MovieSkeleton count={12} />
          </div>
        ) : (
          <div className="text-center py-12 text-gray-400">
            <p>فیلمی برای نمایش وجود ندارد</p>
          </div>
        )}
      </section>

      {/* Newsletter Section */}
      <section className="mt-12 mb-8">
        <Newsletter />
      </section>
    </div>
    </>
  );
};

export default Home;
