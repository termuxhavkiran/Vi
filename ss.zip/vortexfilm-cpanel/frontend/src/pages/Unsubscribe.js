import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { Mail, CheckCircle, XCircle, Loader2 } from 'lucide-react';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const Unsubscribe = () => {
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null); // 'success', 'error', null
  const [message, setMessage] = useState('');
  const email = searchParams.get('email');

  useEffect(() => {
    if (email) {
      handleUnsubscribe();
    }
  }, [email]);

  const handleUnsubscribe = async () => {
    if (!email) {
      setStatus('error');
      setMessage('ایمیل معتبر نیست');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/api/newsletter/unsubscribe`, {
        email: email
      });
      setStatus('success');
      setMessage(response.data.message || 'عضویت شما با موفقیت لغو شد');
    } catch (error) {
      setStatus('error');
      setMessage(error.response?.data?.detail || 'خطا در لغو عضویت. لطفاً دوباره تلاش کنید.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 pt-20 pb-24 bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      <div className="max-w-md w-full">
        <div className="glass-effect rounded-2xl p-8 text-center">
          {loading ? (
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-16 h-16 animate-spin text-purple-500" />
              <p className="text-lg text-gray-300">در حال پردازش...</p>
            </div>
          ) : status === 'success' ? (
            <div className="flex flex-col items-center gap-4">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center">
                <CheckCircle className="w-12 h-12 text-green-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">عضویت لغو شد!</h2>
              <p className="text-gray-300">{message}</p>
              <p className="text-sm text-gray-400 mt-4">
                متاسفیم که شما را از دست دادیم. امیدواریم دوباره به ما بپیوندید.
              </p>
              <a 
                href="/" 
                className="mt-6 px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-full font-bold transition-all"
              >
                بازگشت به صفحه اصلی
              </a>
            </div>
          ) : status === 'error' ? (
            <div className="flex flex-col items-center gap-4">
              <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center">
                <XCircle className="w-12 h-12 text-red-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">خطا در لغو عضویت</h2>
              <p className="text-gray-300">{message}</p>
              <a 
                href="/" 
                className="mt-6 px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-full font-bold transition-all"
              >
                بازگشت به صفحه اصلی
              </a>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <div className="w-20 h-20 bg-purple-500/20 rounded-full flex items-center justify-center">
                <Mail className="w-12 h-12 text-purple-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">لغو عضویت خبرنامه</h2>
              <p className="text-gray-300">ایمیل معتبری یافت نشد</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Unsubscribe;
