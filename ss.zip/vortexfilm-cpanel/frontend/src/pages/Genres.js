import React, { useEffect, useState } from 'react';
import { genresAPI, moviesAPI } from '../utils/api';
import MovieCard from '../components/MovieCard';
import { Loader2, Film } from 'lucide-react';
import api from '../utils/api';
import SEO from '../components/SEO';

const Genres = () => {
  const [genres, setGenres] = useState([]);
  const [selectedGenre, setSelectedGenre] = useState(null);
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [moviesLoading, setMoviesLoading] = useState(false);

  useEffect(() => {
    loadGenres();
  }, []);

  const loadGenres = async () => {
    try {
      setLoading(true);
      const response = await genresAPI.getGenres('en');
      setGenres(response.data.genres || []);
    } catch (error) {
      console.error('خطا در بارگذاری ژانرها:', error);
    } finally {
      setLoading(false);
    }
  };

  const selectGenre = async (genreName) => {
    setSelectedGenre(genreName);
    try {
      setMoviesLoading(true);
      const response = await api.get(`/api/genres/${encodeURIComponent(genreName)}/movies`);
      setMovies(response.data.movies || []);
    } catch (error) {
      console.error('خطا در بارگذاری فیلم‌ها:', error);
      setMovies([]);
    } finally {
      setMoviesLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen" data-testid="loading-spinner">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <>
      <SEO
        title={selectedGenre ? `ژانر ${selectedGenre}` : 'ژانرهای فیلم'}
        description={selectedGenre ? `مشاهده فیلم‌های ژانر ${selectedGenre}` : 'مرور فیلم‌ها بر اساس ژانرهای مختلف'}
        keywords={`ژانر فیلم, ${selectedGenre || 'اکشن، درام، کمدی، ترسناک'}, فیلم‌های ${selectedGenre || 'مختلف'}`}
      />
      <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="genres-page">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-6">
          <Film className="w-8 h-8 text-fuchsia-500" />
          <h1 className="text-3xl md:text-4xl font-black">ژانرهای فیلم</h1>
        </div>
        <p className="text-gray-400">فیلم‌ها را بر اساس ژانر مورد علاقه خود کشف کنید</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-12">
        {genres.map((genre) => (
          <button
            key={genre.id}
            onClick={() => selectGenre(genre.name)}
            className={`p-6 rounded-2xl glass-effect hover:border-fuchsia-500/50 transition-all transform hover:scale-105 ${
              selectedGenre === genre.name ? 'border-fuchsia-500 bg-fuchsia-500/10' : ''
            }`}
            data-testid={`genre-${genre.id}`}
          >
            <h3 className="text-xl font-bold text-center">{genre.name}</h3>
          </button>
        ))}
      </div>

      {selectedGenre && (
        <div data-testid="genre-movies-section">
          <h2 className="text-2xl md:text-3xl font-bold mb-6">
            فیلم‌های ژانر {selectedGenre}
          </h2>

          {moviesLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
            </div>
          ) : movies.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {movies.map((movie) => (
                <MovieCard key={movie._id} movie={movie} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 glass-effect rounded-2xl">
              <p className="text-xl text-gray-400">فیلمی با این ژانر وجود ندارد</p>
            </div>
          )}
        </div>
      )}

      {!selectedGenre && (
        <div className="text-center py-20 glass-effect rounded-2xl">
          <Film className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-xl text-gray-400">یک ژانر را انتخاب کنید</p>
        </div>
      )}
      </div>
    </>
  );
};

export default Genres;
