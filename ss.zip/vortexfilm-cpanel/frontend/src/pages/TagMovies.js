import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Tag, ArrowLeft } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const TagMovies = () => {
  const { tagName } = useParams();
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    fetchMovies();
  }, [tagName, page]);

  const fetchMovies = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API_URL}/api/tags/${encodeURIComponent(tagName)}/movies?page=${page}`);
      setMovies(response.data.movies || []);
      setTotal(response.data.total || 0);
    } catch (error) {
      console.error('خطا در دریافت فیلم‌ها:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalPages = Math.ceil(total / 20);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <Link to="/tags" className="text-red-500 hover:text-red-400 flex items-center gap-2 mb-4 transition">
            <ArrowLeft className="w-4 h-4" />
            بازگشت به برچسب‌ها
          </Link>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Tag className="w-8 h-8 text-red-500" />
            {tagName}
          </h1>
          <p className="text-gray-400 mt-2">{total} فیلم</p>
        </div>

        {loading ? (
          <div className="text-center text-gray-400 py-20">در حال بارگذاری...</div>
        ) : movies.length === 0 ? (
          <div className="text-center py-20">
            <Tag className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">فیلمی با این برچسب یافت نشد</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mb-8">
              {movies.map((movie) => (
                <MovieCard key={movie._id} movie={movie} />
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center gap-2">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-600 text-white px-4 py-2 rounded-lg transition"
                >
                  قبلی
                </button>
                <span className="text-white px-4 py-2">
                  صفحه {page} از {totalPages}
                </span>
                <button
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                  disabled={page === totalPages}
                  className="bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-600 text-white px-4 py-2 rounded-lg transition"
                >
                  بعدی
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default TagMovies;
