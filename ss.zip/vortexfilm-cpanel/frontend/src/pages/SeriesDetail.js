import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { seriesAPI } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { 
  Tv, Calendar, Star, Clock, Play, Download, 
  ChevronDown, ChevronUp, CheckCircle, Circle, Loader2
} from 'lucide-react';
import SEO from '../components/SEO';
import MovieSchema from '../components/MovieSchema';

const SeriesDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [series, setSeries] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSeason, setSelectedSeason] = useState(null);
  const [episodes, setEpisodes] = useState([]);
  const [loadingEpisodes, setLoadingEpisodes] = useState(false);
  const [expandedEpisodes, setExpandedEpisodes] = useState({});
  const [watchProgress, setWatchProgress] = useState([]);

  const IMAGE_BASE = process.env.REACT_APP_TMDB_IMAGE_BASE || 'https://image.tmdb.org/t/p';
  const posterUrl = series?.poster_path ? `${IMAGE_BASE}/w500${series.poster_path}` : '';
  const seriesUrl = typeof window !== 'undefined' ? window.location.href : '';

  useEffect(() => {
    loadSeriesDetail();
    if (user) {
      loadWatchProgress();
    }
  }, [id, user]);

  const loadSeriesDetail = async () => {
    try {
      setLoading(true);
      const response = await seriesAPI.getSeriesDetail(id);
      setSeries(response.data);
      if (response.data.seasons && response.data.seasons.length > 0) {
        loadSeasonEpisodes(response.data.seasons[0].season_number);
        setSelectedSeason(response.data.seasons[0].season_number);
      }
    } catch (error) {
      console.error('Error loading series:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadSeasonEpisodes = async (seasonNumber) => {
    try {
      setLoadingEpisodes(true);
      const response = await seriesAPI.getSeasonEpisodes(id, seasonNumber);
      setEpisodes(response.data.episodes);
      setSelectedSeason(seasonNumber);
    } catch (error) {
      console.error('Error loading episodes:', error);
    } finally {
      setLoadingEpisodes(false);
    }
  };

  const loadWatchProgress = async () => {
    try {
      const response = await seriesAPI.getWatchProgress(id);
      setWatchProgress(response.data.progress);
    } catch (error) {
      console.error('Error loading watch progress:', error);
    }
  };

  const isEpisodeWatched = (seasonNum, episodeNum) => {
    return watchProgress.some(
      p => p.season_number === seasonNum && 
           p.episode_number === episodeNum && 
           p.completed
    );
  };

  const getEpisodeProgress = (seasonNum, episodeNum) => {
    const progress = watchProgress.find(
      p => p.season_number === seasonNum && p.episode_number === episodeNum
    );
    if (progress && progress.duration) {
      return Math.round((progress.watch_time / progress.duration) * 100);
    }
    return 0;
  };

  const toggleEpisode = (episodeId) => {
    setExpandedEpisodes(prev => ({
      ...prev,
      [episodeId]: !prev[episodeId]
    }));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  if (!series) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-gray-400">سریال یافت نشد</p>
      </div>
    );
  }

  return (
    <>
      <SEO
        title={series?.name || series?.original_name}
        description={series?.overview || `تماشای آنلاین سریال ${series?.name}`}
        keywords={`${series?.name}, ${series?.genres?.join(', ')}, سریال, تماشای آنلاین, دانلود سریال`}
        image={posterUrl}
        type="video.tv_show"
        url={seriesUrl}
      />
      <MovieSchema movie={series} />
      <div className="pb-24 pt-16" data-testid="series-detail">
      {/* Hero Section */}
      <div className="relative h-[60vh] mb-8">
        <div className="absolute inset-0">
          {series.backdrop_path ? (
            <img
              src={`${IMAGE_BASE}/original${series.backdrop_path}`}
              alt={series.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-fuchsia-500/20 to-cyan-500/20" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent" />
        </div>

        <div className="relative h-full max-w-7xl mx-auto px-4 flex items-end pb-8">
          <div className="flex gap-6 items-end w-full">
            {/* Poster */}
            <div className="hidden md:block w-48 flex-shrink-0">
              {series.poster_path ? (
                <img
                  src={`${IMAGE_BASE}/w500${series.poster_path}`}
                  alt={series.name}
                  className="w-full rounded-2xl shadow-2xl"
                />
              ) : (
                <div className="w-full aspect-[2/3] bg-slate-800 rounded-2xl flex items-center justify-center">
                  <Tv className="w-16 h-16 text-gray-600" />
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1">
              <h1 className="text-4xl md:text-5xl font-black mb-4">{series.name}</h1>
              {series.original_name !== series.name && (
                <p className="text-xl text-gray-400 mb-4">{series.original_name}</p>
              )}
              
              <div className="flex flex-wrap gap-4 mb-4">
                {series.first_air_date && (
                  <div className="flex items-center gap-2 text-gray-300">
                    <Calendar className="w-5 h-5" />
                    <span>{new Date(series.first_air_date).getFullYear()}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-cyan-400">
                  <Star className="w-5 h-5 fill-cyan-400" />
                  <span>{series.vote_average ? series.vote_average.toFixed(1) : 'N/A'}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-300">
                  <Tv className="w-5 h-5" />
                  <span>{series.number_of_seasons} فصل</span>
                </div>
                <div className="flex items-center gap-2 text-gray-300">
                  <Clock className="w-5 h-5" />
                  <span>{series.number_of_episodes} قسمت</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {series.genres?.map((genre, idx) => (
                  <span key={idx} className="px-4 py-1 bg-fuchsia-500/20 rounded-full text-sm">
                    {genre}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4">
        {/* Overview */}
        {series.overview && (
          <div className="mb-8 glass-effect p-6 rounded-2xl">
            <h2 className="text-2xl font-bold mb-4">خلاصه داستان</h2>
            <p className="text-gray-300 leading-relaxed">{series.overview}</p>
          </div>
        )}

        {/* Seasons */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">فصل‌ها</h2>
          <div className="flex gap-2 overflow-x-auto pb-4">
            {series.seasons?.map((season) => (
              <button
                key={season._id}
                onClick={() => loadSeasonEpisodes(season.season_number)}
                className={`px-6 py-3 rounded-full font-bold whitespace-nowrap transition-all ${
                  selectedSeason === season.season_number
                    ? 'bg-fuchsia-600 neon-glow-pink'
                    : 'bg-slate-800 hover:bg-slate-700'
                }`}
                data-testid={`season-${season.season_number}`}
              >
                فصل {season.season_number}
              </button>
            ))}
          </div>
        </div>

        {/* Episodes */}
        <div>
          <h2 className="text-2xl font-bold mb-4">قسمت‌ها</h2>
          {loadingEpisodes ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-fuchsia-500" />
            </div>
          ) : (
            <div className="space-y-4">
              {episodes.map((episode) => {
                const isWatched = isEpisodeWatched(episode.season_number, episode.episode_number);
                const progress = getEpisodeProgress(episode.season_number, episode.episode_number);
                const isExpanded = expandedEpisodes[episode._id];

                return (
                  <div
                    key={episode._id}
                    className="glass-effect rounded-2xl overflow-hidden"
                    data-testid={`episode-${episode.episode_number}`}
                  >
                    <div
                      onClick={() => toggleEpisode(episode._id)}
                      className="flex items-center gap-4 p-4 cursor-pointer hover:bg-white/5 transition-colors"
                    >
                      {/* Episode Thumbnail */}
                      <div className="w-32 h-20 flex-shrink-0 rounded-lg overflow-hidden bg-slate-800">
                        {episode.still_path ? (
                          <img
                            src={`${IMAGE_BASE}/w300${episode.still_path}`}
                            alt={episode.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Play className="w-8 h-8 text-gray-600" />
                          </div>
                        )}
                      </div>

                      {/* Episode Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="text-fuchsia-400 font-bold">
                            قسمت {episode.episode_number}
                          </span>
                          {isWatched && (
                            <CheckCircle className="w-5 h-5 text-green-500 fill-green-500" />
                          )}
                          {!isWatched && progress > 0 && (
                            <span className="text-xs text-cyan-400">
                              {progress}% تماشا شده
                            </span>
                          )}
                        </div>
                        <h3 className="font-bold text-lg line-clamp-1 mb-1">{episode.name}</h3>
                        {episode.runtime > 0 && (
                          <p className="text-sm text-gray-400">{episode.runtime} دقیقه</p>
                        )}
                        {progress > 0 && progress < 100 && (
                          <div className="mt-2 h-1 bg-slate-700 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-fuchsia-500 to-cyan-500"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        )}
                      </div>

                      {/* Expand Icon */}
                      {isExpanded ? (
                        <ChevronUp className="w-6 h-6 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-6 h-6 text-gray-400" />
                      )}
                    </div>

                    {/* Expanded Content */}
                    {isExpanded && (
                      <div className="px-4 pb-4 border-t border-white/10">
                        {episode.overview && (
                          <p className="text-gray-300 mt-4 mb-4">{episode.overview}</p>
                        )}
                        
                        {/* Download Links */}
                        {episode.download_links && episode.download_links.length > 0 && (
                          <div className="mt-4">
                            <h4 className="font-bold mb-2 flex items-center gap-2">
                              <Download className="w-5 h-5" />
                              لینک‌های دانلود
                            </h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {episode.download_links.map((link, idx) => (
                                <a
                                  key={idx}
                                  href={link.url || `${process.env.REACT_APP_BACKEND_URL}/api/stream/${id}/${link.filename}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center justify-between p-3 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                                >
                                  <span className="font-bold">{link.quality}</span>
                                  <span className="text-sm text-gray-400">{link.size}</span>
                                </a>
                              ))}
                            </div>
                          </div>
                        )}

                        {user && user.role === 'admin' && (
                          <Link
                            to={`/admin/episode-downloads/${episode._id}`}
                            className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold transition-colors"
                          >
                            <Download className="w-5 h-5" />
                            مدیریت دانلود
                          </Link>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Cast */}
        {series.cast && series.cast.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-4">بازیگران</h2>
            <div className="flex gap-4 overflow-x-auto pb-4">
              {series.cast.map((actor, idx) => (
                <div key={idx} className="flex-shrink-0 w-32">
                  <div className="w-32 h-32 rounded-full overflow-hidden bg-slate-800 mb-2">
                    {actor.profile_path ? (
                      <img
                        src={`${IMAGE_BASE}/w185${actor.profile_path}`}
                        alt={actor.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Circle className="w-12 h-12 text-gray-600" />
                      </div>
                    )}
                  </div>
                  <p className="text-sm font-bold text-center line-clamp-1">{actor.name}</p>
                  <p className="text-xs text-gray-400 text-center line-clamp-1">{actor.character}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      </div>
    </>
  );
};

export default SeriesDetail;
