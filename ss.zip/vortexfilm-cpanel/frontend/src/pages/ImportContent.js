import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { moviesAPI, seriesAPI } from '../utils/api';
import { useNavigate } from 'react-router-dom';
import { Film, Loader2, CheckCircle, Tv } from 'lucide-react';

const ImportContent = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [tmdbId, setTmdbId] = useState('');
  const [seriesTmdbId, setSeriesTmdbId] = useState('');
  const [loading, setLoading] = useState(false);
  const [seriesLoading, setSeriesLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [seriesMessage, setSeriesMessage] = useState('');
  const [seriesMessageType, setSeriesMessageType] = useState('');

  if (!user || user.role !== 'admin') {
    navigate('/');
    return null;
  }

  const handleImport = async (e) => {
    e.preventDefault();
    if (!tmdbId) return;

    setLoading(true);
    setMessage('');
    try {
      const response = await moviesAPI.importMovie(parseInt(tmdbId), 'fa');
      setMessageType('success');
      setMessage(response.data.message);
      setTmdbId('');
      setTimeout(() => {
        if (response.data.movie_id) {
          navigate(`/movie/${response.data.movie_id}`);
        }
      }, 2000);
    } catch (error) {
      setMessageType('error');
      setMessage(error.response?.data?.detail || 'خطا در وارد کردن فیلم');
    } finally {
      setLoading(false);
    }
  };

  const handleSeriesImport = async (e) => {
    e.preventDefault();
    if (!seriesTmdbId) return;

    setSeriesLoading(true);
    setSeriesMessage('');
    try {
      const response = await seriesAPI.importSeries(parseInt(seriesTmdbId), 'fa');
      setSeriesMessageType('success');
      setSeriesMessage(response.data.message);
      setSeriesTmdbId('');
      setTimeout(() => {
        if (response.data.series_id) {
          navigate(`/series/${response.data.series_id}`);
        }
      }, 2000);
    } catch (error) {
      setSeriesMessageType('error');
      setSeriesMessage(error.response?.data?.detail || 'خطا در وارد کردن سریال');
    } finally {
      setSeriesLoading(false);
    }
  };

  return (
    <div className="px-4 pb-24 pt-20 max-w-4xl mx-auto" data-testid="import-content-page">
      <div className="glass-effect rounded-2xl p-8">
        <div className="flex items-center gap-3 mb-8">
          <Film className="w-8 h-8 text-fuchsia-500" />
          <h1 className="text-3xl font-black">وارد کردن فیلم</h1>
        </div>

        <div className="mb-6 p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
          <p className="text-sm text-cyan-400 mb-2">راهنما:</p>
          <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
            <li>به سایت TMDB.org بروید</li>
            <li>فیلم مورد نظر را جستجو کنید</li>
            <li>ID فیلم را از URL کپی کنید (مثال: themoviedb.org/movie/550 → ID: 550)</li>
            <li>ID را در فیلد زیر وارد کنید و روی دکمه کلیک کنید</li>
          </ol>
        </div>

        <form onSubmit={handleImport} className="space-y-6">
          <div>
            <label className="block text-lg font-semibold mb-3">TMDB ID</label>
            <input
              type="number"
              value={tmdbId}
              onChange={(e) => setTmdbId(e.target.value)}
              placeholder="مثال: 550"
              className="w-full px-6 py-4 bg-slate-900/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500 text-lg"
              required
              disabled={loading}
              data-testid="tmdb-id-input"
            />
          </div>

          {message && (
            <div
              className={`p-4 rounded-lg border flex items-center gap-3 ${
                messageType === 'success'
                  ? 'bg-green-500/10 border-green-500/30 text-green-400'
                  : 'bg-red-500/10 border-red-500/30 text-red-400'
              }`}
              data-testid="message"
            >
              {messageType === 'success' && <CheckCircle className="w-5 h-5" />}
              <p>{message}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !tmdbId}
            className="w-full py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full font-bold text-lg neon-glow-pink disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
            data-testid="import-button"
          >
            {loading ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                <span>در حال وارد کردن...</span>
              </>
            ) : (
              <>
                <Film className="w-6 h-6" />
                <span>وارد کردن فیلم از TMDB</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-8 p-4 bg-slate-900/50 rounded-lg">
          <p className="text-sm text-gray-400">
            <strong className="text-white">نکته:</strong> پس از وارد شدن موفقیت‌آمیز، به طور خودکار به صفحه فیلم هدایت می‌شوید.
            می‌توانید تحلیل‌های AI را برای فیلم اجرا کنید.
          </p>
        </div>
      </div>

      {/* Series Import Section */}
      <div className="glass-effect rounded-2xl p-8 mt-8">
        <div className="flex items-center gap-3 mb-8">
          <Tv className="w-8 h-8 text-cyan-500" />
          <h1 className="text-3xl font-black">وارد کردن سریال</h1>
        </div>

        <div className="mb-6 p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
          <p className="text-sm text-cyan-400 mb-2">راهنما:</p>
          <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
            <li>به سایت TMDB.org بروید</li>
            <li>سریال مورد نظر را جستجو کنید</li>
            <li>ID سریال را از URL کپی کنید (مثال: themoviedb.org/tv/1399 → ID: 1399)</li>
            <li>ID را در فیلد زیر وارد کنید و روی دکمه کلیک کنید</li>
          </ol>
        </div>

        <form onSubmit={handleSeriesImport} className="space-y-6">
          <div>
            <label className="block text-lg font-semibold mb-3">TMDB ID سریال</label>
            <input
              type="number"
              value={seriesTmdbId}
              onChange={(e) => setSeriesTmdbId(e.target.value)}
              placeholder="مثال: 1399"
              className="w-full px-6 py-4 bg-slate-900/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 text-lg"
              required
              disabled={seriesLoading}
              data-testid="series-tmdb-id-input"
            />
          </div>

          {seriesMessage && (
            <div
              className={`p-4 rounded-lg border flex items-center gap-3 ${
                seriesMessageType === 'success'
                  ? 'bg-green-500/10 border-green-500/30 text-green-400'
                  : 'bg-red-500/10 border-red-500/30 text-red-400'
              }`}
              data-testid="series-message"
            >
              {seriesMessageType === 'success' && <CheckCircle className="w-5 h-5" />}
              <p>{seriesMessage}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={seriesLoading || !seriesTmdbId}
            className="w-full py-4 bg-cyan-600 hover:bg-cyan-500 rounded-full font-bold text-lg neon-glow-cyan disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
            data-testid="import-series-button"
          >
            {seriesLoading ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                <span>در حال وارد کردن سریال...</span>
              </>
            ) : (
              <>
                <Tv className="w-6 h-6" />
                <span>وارد کردن سریال از TMDB</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-8 p-4 bg-slate-900/50 rounded-lg">
          <p className="text-sm text-gray-400">
            <strong className="text-white">نکته:</strong> واردات سریال ممکن است چند دقیقه طول بکشد چون تمام فصل‌ها و قسمت‌ها دریافت و ترجمه می‌شوند.
            تمام اطلاعات به صورت خودکار با هوش مصنوعی به فارسی ترجمه می‌شوند.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ImportContent;
