import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { episodesAPI } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { Download, Upload, Link as LinkIcon, Trash2, Loader2, X } from 'lucide-react';

const ManageEpisodeDownloads = () => {
  const { episodeId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const episode = location.state?.episode;
  
  const [downloadLinks, setDownloadLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddLink, setShowAddLink] = useState(false);
  const [showUpload, setShowUpload] = useState(false);
  
  const [linkQuality, setLinkQuality] = useState('720p');
  const [linkSize, setLinkSize] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  
  const [uploadQuality, setUploadQuality] = useState('720p');
  const [uploadFile, setUploadFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    if (episode) {
      setDownloadLinks(episode.download_links || []);
      setLoading(false);
    }
  }, [episodeId, user, episode]);

  const handleAddLink = async (e) => {
    e.preventDefault();
    try {
      await episodesAPI.addDownloadLink(episodeId, {
        quality: linkQuality,
        size: linkSize,
        url: linkUrl,
        type: 'link'
      });
      setLinkQuality('720p');
      setLinkSize('');
      setLinkUrl('');
      setShowAddLink(false);
      // Reload episode data
      window.location.reload();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در افزودن لینک');
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!uploadFile) return;

    try {
      setUploading(true);
      await episodesAPI.uploadVideo(episodeId, uploadQuality, uploadFile);
      setUploadFile(null);
      setUploadQuality('720p');
      setShowUpload(false);
      window.location.reload();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در آپلود فایل');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (index) => {
    if (!window.confirm('آیا از حذف این لینک مطمئن هستید؟')) return;
    
    try {
      await episodesAPI.deleteDownloadLink(episodeId, index);
      window.location.reload();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در حذف لینک');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-cyan-500" />
      </div>
    );
  }

  return (
    <div className="px-4 pb-24 pt-20 max-w-4xl mx-auto" data-testid="manage-episode-downloads-page">
      <div className="glass-effect rounded-2xl p-8 mb-6">
        <div className="flex items-center gap-3 mb-6">
          <Download className="w-8 h-8 text-cyan-500" />
          <div>
            <h1 className="text-3xl font-black">مدیریت دانلود قسمت</h1>
            {episode && (
              <p className="text-gray-400 mt-1">
                {episode.name} - فصل {episode.season_number} قسمت {episode.episode_number}
              </p>
            )}
          </div>
        </div>

        <div className="flex gap-3 mb-8">
          <button
            onClick={() => setShowAddLink(!showAddLink)}
            className="flex-1 py-3 bg-cyan-600 hover:bg-cyan-500 rounded-xl font-bold flex items-center justify-center gap-2"
          >
            <LinkIcon className="w-5 h-5" />
            افزودن لینک
          </button>
          <button
            onClick={() => setShowUpload(!showUpload)}
            className="flex-1 py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold flex items-center justify-center gap-2"
          >
            <Upload className="w-5 h-5" />
            آپلود فایل
          </button>
        </div>

        {showAddLink && (
          <form onSubmit={handleAddLink} className="mb-8 p-6 bg-slate-900/50 rounded-xl border border-cyan-500/30">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">افزودن لینک دانلود</h3>
              <button type="button" onClick={() => setShowAddLink(false)} className="p-2 hover:bg-white/10 rounded-full">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block mb-2 text-sm">کیفیت</label>
                <select
                  value={linkQuality}
                  onChange={(e) => setLinkQuality(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  required
                >
                  <option value="480p">480p</option>
                  <option value="720p">720p</option>
                  <option value="1080p">1080p</option>
                  <option value="4K">4K</option>
                </select>
              </div>
              <div>
                <label className="block mb-2 text-sm">حجم فایل (مثال: 500 MB)</label>
                <input
                  type="text"
                  value={linkSize}
                  onChange={(e) => setLinkSize(e.target.value)}
                  placeholder="500 MB"
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label className="block mb-2 text-sm">لینک دانلود</label>
                <input
                  type="url"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 rounded-lg font-bold"
              >
                افزودن لینک
              </button>
            </div>
          </form>
        )}

        {showUpload && (
          <form onSubmit={handleUpload} className="mb-8 p-6 bg-slate-900/50 rounded-xl border border-fuchsia-500/30">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">آپلود فایل ویدئو</h3>
              <button type="button" onClick={() => setShowUpload(false)} className="p-2 hover:bg-white/10 rounded-full">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block mb-2 text-sm">کیفیت</label>
                <select
                  value={uploadQuality}
                  onChange={(e) => setUploadQuality(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                  required
                >
                  <option value="480p">480p</option>
                  <option value="720p">720p</option>
                  <option value="1080p">1080p</option>
                  <option value="4K">4K</option>
                </select>
              </div>
              <div>
                <label className="block mb-2 text-sm">فایل ویدئو (MP4, MKV, AVI, MOV, WEBM)</label>
                <input
                  type="file"
                  accept="video/mp4,video/x-matroska,video/avi,video/quicktime,video/webm"
                  onChange={(e) => setUploadFile(e.target.files[0])}
                  className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-fuchsia-600 file:text-white hover:file:bg-fuchsia-500"
                  required
                />
              </div>
              <button
                type="submit"
                disabled={uploading}
                className="w-full py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    در حال آپلود...
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5" />
                    آپلود فایل
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>

      <div className="glass-effect rounded-2xl p-8">
        <h2 className="text-2xl font-bold mb-6">لینک‌های دانلود موجود</h2>
        
        {downloadLinks.length > 0 ? (
          <div className="space-y-3">
            {downloadLinks.map((link, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-slate-900/50 rounded-xl border border-white/10">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 ${link.type === 'upload' ? 'bg-fuchsia-500/20' : 'bg-cyan-500/20'} rounded-lg flex items-center justify-center`}>
                    {link.type === 'upload' ? (
                      <Upload className={`w-6 h-6 ${link.type === 'upload' ? 'text-fuchsia-500' : 'text-cyan-500'}`} />
                    ) : (
                      <LinkIcon className="w-6 h-6 text-cyan-500" />
                    )}
                  </div>
                  <div>
                    <p className="font-bold">{link.quality}</p>
                    <p className="text-sm text-gray-400">{link.size} • {link.type === 'upload' ? 'فایل آپلود شده' : 'لینک خارجی'}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(index)}
                  className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg text-red-400"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-400">
            <Download className="w-16 h-16 mx-auto mb-4 text-gray-600" />
            <p>لینک دانلود موجود نیست</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageEpisodeDownloads;
