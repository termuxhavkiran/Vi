import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { Mail, Users, Download, Search, Calendar, Send } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const NewsletterManagement = () => {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [subscribers, setSubscribers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sendingEmail, setSendingEmail] = useState(false);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    fetchSubscribers();
  }, [user, navigate, token]);

  const fetchSubscribers = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${API_URL}/api/admin/newsletter/subscribers`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      setSubscribers(response.data.subscribers || []);
    } catch (error) {
      console.error('Error fetching subscribers:', error);
    } finally {
      setLoading(false);
    }
  };

  const exportToCSV = () => {
    const csvContent = [
      ['Email', 'تاریخ عضویت'],
      ...subscribers.map(sub => [
        sub.email,
        new Date(sub.subscribed_at).toLocaleDateString('fa-IR')
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `newsletter_subscribers_${Date.now()}.csv`;
    link.click();
  };

  const filteredSubscribers = subscribers.filter(sub =>
    sub.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const sendWeeklyNewsletter = async () => {
    if (!window.confirm('آیا مطمئن هستید که می‌خواهید ایمیل هفتگی را به همه اعضا ارسال کنید؟')) {
      return;
    }
    
    try {
      setSendingEmail(true);
      await axios.post(
        `${API_URL}/api/admin/newsletter/send-weekly`,
        {},
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      alert('ارسال ایمیل‌ها شروع شد! این فرآیند ممکن است چند دقیقه طول بکشد.');
    } catch (error) {
      console.error('Error sending weekly newsletter:', error);
      alert('خطا در ارسال ایمیل‌ها. لطفاً دوباره تلاش کنید.');
    } finally {
      setSendingEmail(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 p-6 pt-24">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Mail className="w-8 h-8 text-purple-400" />
            <h1 className="text-3xl font-bold text-white">مدیریت خبرنامه</h1>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={sendWeeklyNewsletter}
              disabled={sendingEmail || subscribers.length === 0}
              className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
              <span>{sendingEmail ? 'در حال ارسال...' : 'ارسال ایمیل هفتگی'}</span>
            </button>
            
            <button
              onClick={exportToCSV}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg transition-colors"
            >
              <Download className="w-5 h-5" />
              <span>دانلود CSV</span>
            </button>
          </div>
        </div>

        {/* Stats Card */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-6 mb-8 shadow-xl">
          <div className="flex items-center gap-4">
            <div className="bg-white/20 p-4 rounded-full">
              <Users className="w-8 h-8 text-white" />
            </div>
            <div>
              <p className="text-purple-200 text-sm">مجموع اعضا</p>
              <p className="text-4xl font-bold text-white">
                {subscribers.length.toLocaleString('fa-IR')}
              </p>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20 mb-6">
          <div className="relative">
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="جستجوی ایمیل..."
              className="w-full bg-gray-700 text-white pr-12 pl-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>

        {/* Subscribers List */}
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl border border-purple-500/20 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right">
              <thead className="bg-gray-700/50">
                <tr>
                  <th className="py-4 px-6 text-purple-400 font-semibold">#</th>
                  <th className="py-4 px-6 text-purple-400 font-semibold">ایمیل</th>
                  <th className="py-4 px-6 text-purple-400 font-semibold">تاریخ عضویت</th>
                </tr>
              </thead>
              <tbody>
                {filteredSubscribers.length === 0 ? (
                  <tr>
                    <td colSpan="3" className="py-12 text-center text-gray-400">
                      {searchTerm ? 'نتیجه‌ای یافت نشد' : 'هیچ عضوی وجود ندارد'}
                    </td>
                  </tr>
                ) : (
                  filteredSubscribers.map((subscriber, index) => (
                    <tr 
                      key={subscriber._id}
                      className="border-b border-gray-700/50 hover:bg-gray-700/30 transition-colors"
                    >
                      <td className="py-4 px-6 text-gray-400">
                        {index + 1}
                      </td>
                      <td className="py-4 px-6 text-white font-medium">
                        {subscriber.email}
                      </td>
                      <td className="py-4 px-6 text-gray-300 flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-purple-400" />
                        {new Date(subscriber.subscribed_at).toLocaleDateString('fa-IR', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Info Card */}
        <div className="mt-8 bg-blue-900/30 border border-blue-500/30 rounded-xl p-6">
          <div className="flex items-start gap-4">
            <Mail className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-blue-300 font-bold text-lg mb-2">
                نکات مهم درباره خبرنامه
              </h3>
              <ul className="text-blue-200 space-y-2 text-sm">
                <li>• برای ارسال ایمیل به اعضا، باید تنظیمات SMTP را در فایل .env پیکربندی کنید</li>
                <li>• می‌توانید لیست اعضا را به صورت CSV دانلود کنید</li>
                <li>• اعضا می‌توانند از طریق صفحه اصلی سایت عضو شوند</li>
                <li>• امکان لغو عضویت برای کاربران در هر ایمیل ارسالی وجود دارد</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewsletterManagement;
