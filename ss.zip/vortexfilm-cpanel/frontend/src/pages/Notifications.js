import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Loader2, Check, Film, MessageSquare, Info } from 'lucide-react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadNotifications();
  }, [user]);

  const loadNotifications = async () => {
    try {
      setLoading(true);
      const response = await api.get('/api/notifications');
      setNotifications(response.data.notifications || []);
    } catch (error) {
      console.error('خطا در بارگذاری اعلان‌ها:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId) => {
    try {
      await api.post(`/api/notifications/${notificationId}/read`);
      setNotifications(notifications.map(n => 
        n._id === notificationId ? { ...n, read: true } : n
      ));
    } catch (error) {
      console.error('خطا:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      await api.post('/api/notifications/read-all');
      setNotifications(notifications.map(n => ({ ...n, read: true })));
    } catch (error) {
      console.error('خطا:', error);
    }
  };

  const handleNotificationClick = (notification) => {
    if (!notification.read) {
      markAsRead(notification._id);
    }
    if (notification.link) {
      navigate(notification.link);
    }
  };

  const getIcon = (type) => {
    switch (type) {
      case 'new_movie':
        return <Film className="w-6 h-6 text-fuchsia-500" />;
      case 'comment':
        return <MessageSquare className="w-6 h-6 text-cyan-500" />;
      default:
        return <Info className="w-6 h-6 text-blue-500" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="px-4 pb-24 pt-20 max-w-4xl mx-auto" data-testid="notifications-page">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <Bell className="w-8 h-8 text-fuchsia-500" />
          <h1 className="text-3xl md:text-4xl font-black">اعلان‌ها</h1>
        </div>
        {notifications.some(n => !n.read) && (
          <button
            onClick={markAllAsRead}
            className="px-4 py-2 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full text-sm font-bold flex items-center gap-2"
            data-testid="mark-all-read-button"
          >
            <Check className="w-4 h-4" />
            علامت‌زدن همه
          </button>
        )}
      </div>

      {notifications.length > 0 ? (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <div
              key={notification._id}
              onClick={() => handleNotificationClick(notification)}
              className={`glass-effect rounded-2xl p-6 cursor-pointer transition-all hover:scale-[1.02] ${
                !notification.read ? 'border-fuchsia-500/50 bg-fuchsia-500/5' : 'opacity-70'
              }`}
              data-testid="notification-item"
            >
              <div className="flex items-start gap-4">
                <div className="mt-1">{getIcon(notification.type)}</div>
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4">
                    <h3 className="font-bold text-lg">{notification.title}</h3>
                    {!notification.read && (
                      <div className="w-3 h-3 bg-fuchsia-500 rounded-full animate-pulse" />
                    )}
                  </div>
                  <p className="text-gray-300 mt-2">{notification.message}</p>
                  <p className="text-sm text-gray-500 mt-3">
                    {new Date(notification.created_at).toLocaleDateString('fa-IR', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="glass-effect rounded-2xl p-20 text-center">
          <Bell className="w-20 h-20 text-gray-600 mx-auto mb-4" />
          <p className="text-xl text-gray-400">اعلانی وجود ندارد</p>
        </div>
      )}
    </div>
  );
};

export default Notifications;
