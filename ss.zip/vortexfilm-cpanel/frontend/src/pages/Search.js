import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { moviesAPI } from '../utils/api';
import MovieCard from '../components/MovieCard';
import MovieSkeleton from '../components/MovieSkeleton';
import AdvancedSearch from '../components/AdvancedSearch';
import { Search as SearchIcon, Loader2 } from 'lucide-react';
import SEO from '../components/SEO';

const Search = () => {
  const [searchParams] = useSearchParams();
  const queryParam = searchParams.get('q');
  
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    if (queryParam) {
      handleSearch(queryParam);
    }
  }, [queryParam]);

  const handleSearch = async (searchQuery) => {
    if (!searchQuery || !searchQuery.trim()) return;

    setLoading(true);
    setSearched(true);
    try {
      const response = await moviesAPI.searchMovies(searchQuery, 'fa');
      setResults(response.data.results || []);
    } catch (error) {
      console.error('خطا در جستجو:', error);
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <SEO
        title={queryParam ? `جستجو: ${queryParam}` : 'جستجوی فیلم و سریال'}
        description={queryParam ? `نتایج جستجو برای "${queryParam}"` : 'جستجوی پیشرفته در فیلم‌ها و سریال‌ها'}
        keywords={`جستجو, ${queryParam || 'فیلم، سریال'}`}
      />
      <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="search-page">
      <div className="mb-8">
        <h1 className="text-4xl font-black mb-6 tracking-tighter">جستجوی پیشرفته</h1>
        
        {/* Advanced Search Component */}
        <AdvancedSearch />
      </div>

      {loading && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <MovieSkeleton count={12} />
        </div>
      )}

      {!loading && searched && (
        <div>
          {results.length > 0 ? (
            <>
              <p className="text-gray-400 mb-6">
                {results.length} نتیجه برای "{queryParam}" یافت شد
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4" data-testid="search-results">
                {results.map((movie) => (
                  <MovieCard key={movie.id} movie={movie} />
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-12">
              <SearchIcon className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-xl text-gray-400">نتیجه‌ای برای "{queryParam}" یافت نشد</p>
            </div>
          )}
        </div>
      )}

      {!searched && !loading && (
        <div className="text-center py-12">
          <SearchIcon className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-xl text-gray-400">برای شروع جستجو، از کادر بالا استفاده کنید</p>
        </div>
      )}
      </div>
    </>
  );
};

export default Search;
