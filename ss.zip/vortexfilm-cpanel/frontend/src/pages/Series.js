import React, { useState, useEffect } from 'react';
import { seriesAPI } from '../utils/api';
import { Link } from 'react-router-dom';
import { Tv, Search, Loader2, TrendingUp } from 'lucide-react';
import SEO from '../components/SEO';

const Series = () => {
  const [series, setSeries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);

  const IMAGE_BASE = process.env.REACT_APP_TMDB_IMAGE_BASE || 'https://image.tmdb.org/t/p';

  useEffect(() => {
    loadSeries();
  }, [page]);

  const loadSeries = async () => {
    try {
      setLoading(true);
      const response = await seriesAPI.getSeries(page);
      setSeries(response.data.series);
      setTotal(response.data.total);
    } catch (error) {
      console.error('Error loading series:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      setSearching(true);
      const response = await seriesAPI.searchSeries(searchQuery);
      setSearchResults(response.data.results);
    } catch (error) {
      console.error('Error searching series:', error);
    } finally {
      setSearching(false);
    }
  };

  const SeriesCard = ({ item, fromSearch = false }) => (
    <Link
      to={fromSearch ? '#' : `/series/${item._id}`}
      className="group relative overflow-hidden rounded-2xl glass-effect hover:scale-105 transition-all duration-300"
      data-testid={`series-card-${item._id || item.id}`}
    >
      <div className="aspect-[2/3] relative">
        {item.poster_path ? (
          <img
            src={`${IMAGE_BASE}/w500${item.poster_path}`}
            alt={item.name || item.original_name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-fuchsia-500/20 to-cyan-500/20 flex items-center justify-center">
            <Tv className="w-16 h-16 text-white/50" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg line-clamp-1 mb-2">{item.name || item.original_name}</h3>
        <div className="flex items-center justify-between text-sm">
          <span className="text-cyan-400">
            {item.vote_average ? `⭐ ${item.vote_average.toFixed(1)}` : 'بدون امتیاز'}
          </span>
          {item.number_of_seasons && (
            <span className="text-gray-400">{item.number_of_seasons} فصل</span>
          )}
        </div>
        {item.first_air_date && (
          <p className="text-xs text-gray-500 mt-2">
            {new Date(item.first_air_date).getFullYear()}
          </p>
        )}
      </div>
    </Link>
  );

  return (
    <>
      <SEO
        title="سریال‌ها"
        description="مشاهده و دانلود جدیدترین سریال‌های خارجی و داخلی با زیرنویس فارسی"
        keywords="سریال, دانلود سریال, تماشای آنلاین سریال, سریال خارجی"
      />
      <div className="px-4 pb-24 pt-20" data-testid="series-page">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <Tv className="w-8 h-8 text-fuchsia-500" />
          <h1 className="text-3xl font-black">سریال‌ها</h1>
        </div>

        {/* Search Box */}
        <form onSubmit={handleSearch} className="mb-8">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجوی سریال در TMDB..."
              className="w-full px-6 py-4 pr-12 bg-slate-900/50 border border-white/10 rounded-full focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
              data-testid="search-input"
            />
            <button
              type="submit"
              className="absolute right-4 top-1/2 -translate-y-1/2 text-fuchsia-500"
              data-testid="search-button"
            >
              {searching ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Search className="w-5 h-5" />
              )}
            </button>
          </div>
        </form>

        {/* Search Results */}
        {searchResults.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Search className="w-6 h-6" />
              نتایج جستجو
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {searchResults.map((item) => (
                <SeriesCard key={item.id} item={item} fromSearch={true} />
              ))}
            </div>
            <div className="mt-6 text-center">
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSearchResults([]);
                }}
                className="text-cyan-400 hover:text-cyan-300 underline"
              >
                پاک کردن نتایج جستجو
              </button>
            </div>
          </div>
        )}

        {/* Series Grid */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-cyan-400" />
            سریال‌های موجود
          </h2>
          {loading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-fuchsia-500" />
            </div>
          ) : series.length === 0 ? (
            <div className="text-center py-20 glass-effect rounded-2xl">
              <Tv className="w-16 h-16 mx-auto mb-4 text-gray-500" />
              <p className="text-gray-400">هنوز سریالی اضافه نشده است</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {series.map((item) => (
                <SeriesCard key={item._id} item={item} />
              ))}
            </div>
          )}
        </div>

        {/* Pagination */}
        {total > 20 && (
          <div className="flex justify-center gap-4 mt-8">
            <button
              onClick={() => setPage(page - 1)}
              disabled={page === 1}
              className="px-6 py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full font-bold disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="prev-page"
            >
              قبلی
            </button>
            <span className="px-6 py-3 glass-effect rounded-full font-bold">
              صفحه {page} از {Math.ceil(total / 20)}
            </span>
            <button
              onClick={() => setPage(page + 1)}
              disabled={page >= Math.ceil(total / 20)}
              className="px-6 py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full font-bold disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="next-page"
            >
              بعدی
            </button>
          </div>
        )}
      </div>
      </div>
    </>
  );
};

export default Series;
