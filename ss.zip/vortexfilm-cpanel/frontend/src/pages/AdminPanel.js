import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Film, 
  Users, 
  MessageSquare, 
  Brain, 
  Settings, 
  Upload,
  Tv
} from 'lucide-react';

const AdminPanel = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  if (!user || user.role !== 'admin') {
    navigate('/');
    return null;
  }

  const menuItems = [
    {
      title: 'داشبورد اصلی',
      description: 'مشاهده آمار و اطلاعات کلی',
      icon: LayoutDashboard,
      color: 'fuchsia',
      path: '/admin/dashboard'
    },
    {
      title: 'وارد کردن محتوا',
      description: 'واردات فیلم و سریال از TMDB',
      icon: Upload,
      color: 'cyan',
      path: '/admin/import'
    },
    {
      title: 'مدیریت فیلم‌ها',
      description: 'مشاهده، ویرایش و حذف فیلم‌ها',
      icon: Film,
      color: 'purple',
      path: '/admin/movies'
    },
    {
      title: 'مدیریت کاربران',
      description: 'مدیریت کاربران و نقش‌ها',
      icon: Users,
      color: 'green',
      path: '/admin/users'
    },
    {
      title: 'مدیریت نظرات',
      description: 'مشاهده و مدیریت نظرات',
      icon: MessageSquare,
      color: 'yellow',
      path: '/admin/reviews'
    },
    {
      title: 'داشبورد AI',
      description: 'آمار تحلیل‌های هوش مصنوعی',
      icon: Brain,
      color: 'pink',
      path: '/admin/ai'
    },
    {
      title: 'تنظیمات سایت',
      description: 'تنظیمات عمومی و کلیدهای API',
      icon: Settings,
      color: 'orange',
      path: '/admin/settings'
    }
  ];

  const colorClasses = {
    fuchsia: 'bg-fuchsia-500/10 border-fuchsia-500/30 hover:bg-fuchsia-500/20',
    cyan: 'bg-cyan-500/10 border-cyan-500/30 hover:bg-cyan-500/20',
    purple: 'bg-purple-500/10 border-purple-500/30 hover:bg-purple-500/20',
    green: 'bg-green-500/10 border-green-500/30 hover:bg-green-500/20',
    yellow: 'bg-yellow-500/10 border-yellow-500/30 hover:bg-yellow-500/20',
    pink: 'bg-pink-500/10 border-pink-500/30 hover:bg-pink-500/20',
    orange: 'bg-orange-500/10 border-orange-500/30 hover:bg-orange-500/20'
  };

  const iconColors = {
    fuchsia: 'text-fuchsia-500',
    cyan: 'text-cyan-500',
    purple: 'text-purple-500',
    green: 'text-green-500',
    yellow: 'text-yellow-500',
    pink: 'text-pink-500',
    orange: 'text-orange-500'
  };

  return (
    <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="admin-panel">
      <div className="mb-8">
        <h1 className="text-4xl font-black mb-2">پنل مدیریت VortexFilm</h1>
        <p className="text-gray-400">مدیریت کامل سایت و محتوا</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <div
              key={index}
              onClick={() => navigate(item.path)}
              className={`glass-effect rounded-2xl p-6 border-2 cursor-pointer transition-all duration-300 ${colorClasses[item.color]}`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${item.color === 'fuchsia' ? 'bg-fuchsia-500/20' : item.color === 'cyan' ? 'bg-cyan-500/20' : item.color === 'purple' ? 'bg-purple-500/20' : item.color === 'green' ? 'bg-green-500/20' : item.color === 'yellow' ? 'bg-yellow-500/20' : item.color === 'pink' ? 'bg-pink-500/20' : 'bg-orange-500/20'}`}>
                  <Icon className={`w-6 h-6 ${iconColors[item.color]}`} />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-sm text-gray-400">{item.description}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* اطلاعات کلی */}
      <div className="mt-8 glass-effect rounded-2xl p-6">
        <h2 className="text-2xl font-bold mb-4">راهنمای سریع</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-400">
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="font-bold text-white mb-2">📊 داشبورد اصلی</p>
            <p>مشاهده آمار کلی سایت، نمودارها و آخرین فعالیت‌ها</p>
          </div>
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="font-bold text-white mb-2">📤 وارد کردن محتوا</p>
            <p>واردات فیلم و سریال از پایگاه داده TMDB با ترجمه خودکار</p>
          </div>
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="font-bold text-white mb-2">🎬 مدیریت فیلم‌ها</p>
            <p>ویرایش، حذف و مدیریت کامل فیلم‌ها و لینک‌های دانلود</p>
          </div>
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="font-bold text-white mb-2">🤖 تحلیل‌های AI</p>
            <p>مشاهده آمار استفاده از تحلیل‌های هوش مصنوعی</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
