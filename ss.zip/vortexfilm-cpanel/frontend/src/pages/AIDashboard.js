import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { adminAPI } from '../utils/api';
import { useNavigate } from 'react-router-dom';
import { Brain, TrendingUp, Loader2 } from 'lucide-react';

const AIDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    loadStats();
  }, [user, navigate]);

  const loadStats = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getAIStats();
      setStats(response.data);
    } catch (error) {
      console.error('خطا:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  const analysisTypes = [
    { key: 'mood', label: 'تحلیل حس و حال', color: 'fuchsia' },
    { key: 'characters', label: 'تحلیل شخصیت‌ها', color: 'cyan' },
    { key: 'ending', label: 'پیش‌بینی پایان', color: 'green' },
    { key: 'hidden', label: 'جزئیات پنهان', color: 'yellow' },
    { key: 'reviews', label: 'تحلیل نظرات', color: 'purple' },
  ];

  return (
    <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="ai-dashboard">
      <div className="mb-8">
        <h1 className="text-4xl font-black mb-2">داشبورد هوش مصنوعی</h1>
        <p className="text-gray-400">آمار استفاده از تحلیل‌های AI</p>
      </div>

      {/* آمار کلی */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-fuchsia-500/20 rounded-lg flex items-center justify-center">
              <Brain className="w-6 h-6 text-fuchsia-500" />
            </div>
            <div>
              <p className="text-sm text-gray-400">تعداد کل تحلیل‌ها</p>
              <p className="text-2xl font-black">{stats?.total_analyses || 0}</p>
            </div>
          </div>
        </div>

        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-cyan-500" />
            </div>
            <div>
              <p className="text-sm text-gray-400">تعداد فیلم‌ها</p>
              <p className="text-2xl font-black">{stats?.total_movies || 0}</p>
            </div>
          </div>
        </div>

        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <Brain className="w-6 h-6 text-green-500" />
            </div>
            <div>
              <p className="text-sm text-gray-400">درصد پوشش</p>
              <p className="text-2xl font-black">
                {stats?.total_movies > 0 
                  ? Math.round((stats.total_analyses / (stats.total_movies * 5)) * 100)
                  : 0}%
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* تحلیل بر اساس نوع */}
      <div className="glass-effect rounded-2xl p-6 mb-8">
        <h2 className="text-2xl font-bold mb-6">تحلیل‌ها بر اساس نوع</h2>
        <div className="space-y-4">
          {analysisTypes.map(({ key, label, color }) => (
            <div key={key}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold">{label}</span>
                <span className="text-sm text-gray-400">
                  {stats?.analyses?.[key] || 0} / {stats?.total_movies || 0}
                </span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-3">
                <div
                  className={`bg-${color}-500 h-3 rounded-full transition-all duration-500`}
                  style={{
                    width: `${stats?.total_movies > 0 
                      ? ((stats.analyses?.[key] || 0) / stats.total_movies) * 100
                      : 0}%`
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* اطلاعات موتور AI */}
      <div className="glass-effect rounded-2xl p-6">
        <h2 className="text-2xl font-bold mb-6">اطلاعات موتور AI</h2>
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-1">مدل استفاده شده</p>
            <p className="font-bold">Groq LLaMA 3.1 8B Instant</p>
          </div>
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-1">استفاده</p>
            <p className="text-sm">ترجمه خودکار فیلم‌ها و سریال‌ها از TMDB به فارسی</p>
          </div>
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-1">قابلیت‌ها</p>
            <ul className="text-sm space-y-1 list-disc list-inside">
              <li>تحلیل حس و حال فیلم</li>
              <li>تحلیل شخصیت‌های فیلم</li>
              <li>پیش‌بینی پایان‌های محتمل</li>
              <li>کشف جزئیات پنهان و نمادها</li>
              <li>تحلیل احساسات نظرات کاربران</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIDashboard;