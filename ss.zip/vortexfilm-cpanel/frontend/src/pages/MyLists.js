import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { List, Plus, Edit, Trash2, Eye } from 'lucide-react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const MyLists = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newList, setNewList] = useState({ name: '', description: '', is_public: true });

  useEffect(() => {
    if (user) {
      fetchMyLists();
    }
  }, [user]);

  const fetchMyLists = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/api/my-lists`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setLists(response.data.lists || []);
    } catch (error) {
      console.error('خطا در دریافت لیست‌ها:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateList = async (e) => {
    e.preventDefault();
    if (!newList.name.trim()) {
      alert('لطفاً نام لیست را وارد کنید');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_URL}/api/public-lists`,
        newList,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setNewList({ name: '', description: '', is_public: true });
      setShowCreateForm(false);
      fetchMyLists();
    } catch (error) {
      console.error('خطا در ساخت لیست:', error);
      alert('خطا در ساخت لیست');
    }
  };

  const handleDeleteList = async (listId) => {
    if (!window.confirm('آیا مطمئن هستید که می‌خواهید این لیست را حذف کنید؟')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_URL}/api/public-lists/${listId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchMyLists();
    } catch (error) {
      console.error('خطا در حذف لیست:', error);
      alert('خطا در حذف لیست');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-white mb-4">لطفاً وارد شوید</h2>
          <Link to="/login" className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg">
            ورود به حساب کاربری
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <List className="w-8 h-8 text-red-500" />
            لیست‌های من
          </h1>
          <button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition"
          >
            <Plus className="w-5 h-5" />
            لیست جدید
          </button>
        </div>

        <div className="mb-6">
          <Link
            to="/public-lists"
            className="text-red-500 hover:text-red-400 transition"
          >
            ← بازگشت به لیست‌های عمومی
          </Link>
        </div>

        {/* فرم ساخت لیست */}
        {showCreateForm && (
          <div className="bg-gray-800/50 rounded-lg p-6 mb-8">
            <form onSubmit={handleCreateList}>
              <div className="mb-4">
                <label className="block text-white mb-2">نام لیست *</label>
                <input
                  type="text"
                  value={newList.name}
                  onChange={(e) => setNewList({ ...newList, name: e.target.value })}
                  className="w-full bg-gray-700 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block text-white mb-2">توضیحات</label>
                <textarea
                  value={newList.description}
                  onChange={(e) => setNewList({ ...newList, description: e.target.value })}
                  className="w-full bg-gray-700 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  rows="3"
                />
              </div>
              <div className="mb-4">
                <label className="flex items-center gap-2 text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newList.is_public}
                    onChange={(e) => setNewList({ ...newList, is_public: e.target.checked })}
                    className="w-5 h-5"
                  />
                  <span>لیست عمومی (دیگران می‌توانند ببینند)</span>
                </label>
              </div>
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition"
                >
                  ایجاد لیست
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-lg transition"
                >
                  انصراف
                </button>
              </div>
            </form>
          </div>
        )}

        {/* لیست‌ها */}
        {loading ? (
          <div className="text-center text-gray-400 py-20">در حال بارگذاری...</div>
        ) : lists.length === 0 ? (
          <div className="text-center py-20">
            <List className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg mb-4">شما هنوز لیستی ایجاد نکرده‌اید</p>
            <button
              onClick={() => setShowCreateForm(true)}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg"
            >
              اولین لیست خود را بسازید
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lists.map((list) => (
              <div key={list._id} className="bg-gray-800/50 rounded-lg p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-white mb-1">{list.name}</h3>
                    {list.description && (
                      <p className="text-gray-400 text-sm line-clamp-2">{list.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {list.is_public ? (
                      <Eye className="w-4 h-4 text-green-500" title="عمومی" />
                    ) : (
                      <Eye className="w-4 h-4 text-gray-500" title="خصوصی" />
                    )}
                  </div>
                </div>
                <div className="text-gray-400 text-sm mb-4">
                  {list.movie_count || 0} فیلم • {list.follower_count || 0} دنبال‌کننده
                </div>
                <div className="flex gap-2">
                  <Link
                    to={`/public-lists/${list._id}`}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-center transition"
                  >
                    مشاهده
                  </Link>
                  <button
                    onClick={() => handleDeleteList(list._id)}
                    className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-lg transition"
                    title="حذف"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyLists;