import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import { List, Users, Heart, ArrowLeft } from 'lucide-react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const FollowingLists = () => {
  const { user } = useAuth();
  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchFollowingLists();
    }
  }, [user]);

  const fetchFollowingLists = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/api/public-lists/following`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setLists(response.data.lists || []);
    } catch (error) {
      console.error('خطا در دریافت لیست‌ها:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-white mb-4">لطفاً وارد شوید</h2>
          <Link to="/login" className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg">
            ورود به حساب کاربری
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
      <div className="max-w-6xl mx-auto">
        <Link
          to="/public-lists"
          className="text-red-500 hover:text-red-400 flex items-center gap-2 mb-6 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          بازگشت به لیست‌های عمومی
        </Link>

        <h1 className="text-3xl font-bold text-white flex items-center gap-3 mb-8">
          <Heart className="w-8 h-8 text-red-500 fill-current" />
          لیست‌های دنبال شده
        </h1>

        {loading ? (
          <div className="text-center text-gray-400 py-20">در حال بارگذاری...</div>
        ) : lists.length === 0 ? (
          <div className="text-center py-20">
            <Heart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg mb-4">شما هنوز هیچ لیستی را دنبال نمی‌کنید</p>
            <Link
              to="/public-lists"
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg inline-block"
            >
              کشف لیست‌ها
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lists.map((list) => (
              <Link
                key={list._id}
                to={`/public-lists/${list._id}`}
                className="bg-gray-800/50 hover:bg-gray-700/50 rounded-lg p-6 transition-all duration-300 transform hover:scale-105"
              >
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-xl font-bold text-white flex-1 line-clamp-2">{list.name}</h3>
                  <List className="w-6 h-6 text-red-500 flex-shrink-0" />
                </div>
                {list.description && (
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">{list.description}</p>
                )}
                <div className="flex items-center gap-4 text-sm text-gray-300">
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    <span>{list.owner_name}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    <span>{list.follower_count || 0}</span>
                  </div>
                  <div>
                    {list.movie_count || 0} فیلم
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FollowingLists;
