import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { List, Users, Heart, Search } from 'lucide-react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const PublicLists = () => {
  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    fetchLists();
  }, [page, search]);

  const fetchLists = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API_URL}/api/public-lists?page=${page}&search=${search}`);
      setLists(response.data.lists || []);
      setTotal(response.data.total || 0);
    } catch (error) {
      console.error('خطا در دریافت لیست‌ها:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    fetchLists();
  };

  const totalPages = Math.ceil(total / 20);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white flex items-center gap-3 mb-4">
            <List className="w-8 h-8 text-red-500" />
            لیست‌های عمومی
          </h1>
          <p className="text-gray-400 mb-6">کشف و دنبال کردن لیست‌های ساخته شده توسط کاربران</p>

          {/* جستجو */}
          <form onSubmit={handleSearch} className="flex gap-2 max-w-md">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجوی لیست..."
              className="flex-1 bg-gray-800 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            />
            <button
              type="submit"
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition"
            >
              <Search className="w-5 h-5" />
            </button>
          </form>
        </div>

        <div className="mb-6 flex gap-4">
          <Link
            to="/my-lists"
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition"
          >
            لیست‌های من
          </Link>
          <Link
            to="/following-lists"
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition"
          >
            دنبال شده‌ها
          </Link>
        </div>

        {loading ? (
          <div className="text-center text-gray-400 py-20">در حال بارگذاری...</div>
        ) : lists.length === 0 ? (
          <div className="text-center py-20">
            <List className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">لیستی یافت نشد</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {lists.map((list) => (
                <Link
                  key={list._id}
                  to={`/public-lists/${list._id}`}
                  className="bg-gray-800/50 hover:bg-gray-700/50 rounded-lg p-6 transition-all duration-300 transform hover:scale-105"
                >
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-bold text-white flex-1 line-clamp-2">{list.name}</h3>
                    <List className="w-6 h-6 text-red-500 flex-shrink-0" />
                  </div>
                  {list.description && (
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">{list.description}</p>
                  )}
                  <div className="flex items-center gap-4 text-sm text-gray-300">
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>{list.owner_name}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      <span>{list.follower_count || 0}</span>
                    </div>
                    <div>
                      {list.movie_count || 0} فیلم
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center gap-2">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-600 text-white px-4 py-2 rounded-lg transition"
                >
                  قبلی
                </button>
                <span className="text-white px-4 py-2">
                  صفحه {page} از {totalPages}
                </span>
                <button
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                  disabled={page === totalPages}
                  className="bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-600 text-white px-4 py-2 rounded-lg transition"
                >
                  بعدی
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default PublicLists;