import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { User, Calendar, MapPin, Film } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';
const TMDB_IMAGE_BASE = process.env.REACT_APP_TMDB_IMAGE_BASE || 'https://image.tmdb.org/t/p';

const ActorDetail = () => {
  const { actorId } = useParams();
  const [actor, setActor] = useState(null);
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [moviesPage, setMoviesPage] = useState(1);
  const [totalMovies, setTotalMovies] = useState(0);

  useEffect(() => {
    fetchActorInfo();
    fetchActorMovies();
  }, [actorId, moviesPage]);

  const fetchActorInfo = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/actor/${actorId}`);
      setActor(response.data);
    } catch (error) {
      console.error('خطا در دریافت اطلاعات بازیگر:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchActorMovies = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/actor/${actorId}/movies?page=${moviesPage}`);
      setMovies(response.data.movies || []);
      setTotalMovies(response.data.total || 0);
    } catch (error) {
      console.error('خطا در دریافت فیلم‌های بازیگر:', error);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'نامشخص';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
        <div className="text-center text-gray-400 py-20">در حال بارگذاری...</div>
      </div>
    );
  }

  if (!actor) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
        <div className="text-center py-20">
          <User className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">بازیگر یافت نشد</p>
        </div>
      </div>
    );
  }

  const totalPages = Math.ceil(totalMovies / 20);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24">
      {/* Header با عکس بازیگر */}
      <div className="relative h-96 mb-8">
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent z-10"></div>
        {actor.profile_path && (
          <img
            src={`${TMDB_IMAGE_BASE}/w1280${actor.profile_path}`}
            alt={actor.name}
            className="w-full h-full object-cover object-top blur-sm opacity-30"
          />
        )}
        
        <div className="absolute bottom-0 left-0 right-0 z-20 px-4 pb-8">
          <div className="max-w-6xl mx-auto flex gap-6 items-end">
            {actor.profile_path && (
              <img
                src={`${TMDB_IMAGE_BASE}/w500${actor.profile_path}`}
                alt={actor.name}
                className="w-48 h-48 object-cover rounded-lg shadow-2xl border-4 border-white/10"
              />
            )}
            <div className="flex-1">
              <h1 className="text-4xl font-bold text-white mb-2">{actor.name}</h1>
              {actor.known_for_department && (
                <p className="text-xl text-red-400 mb-4">{actor.known_for_department}</p>
              )}
              <div className="flex flex-wrap gap-4 text-gray-300">
                {actor.birthday && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{formatDate(actor.birthday)}</span>
                  </div>
                )}
                {actor.place_of_birth && (
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span>{actor.place_of_birth}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4">
        {/* بیوگرافی */}
        {actor.biography && (
          <div className="mb-12 bg-gray-800/50 rounded-lg p-6">
            <h2 className="text-2xl font-bold text-white mb-4">بیوگرافی</h2>
            <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">{actor.biography}</p>
          </div>
        )}

        {/* فیلم‌ها */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Film className="w-6 h-6 text-red-500" />
            فیلم‌های {actor.name}
            {totalMovies > 0 && <span className="text-gray-400 text-lg">({totalMovies})</span>}
          </h2>

          {movies.length === 0 ? (
            <div className="text-center py-20">
              <Film className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400 text-lg">فیلمی در دیتابیس یافت نشد</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mb-8">
                {movies.map((movie) => (
                  <MovieCard key={movie._id} movie={movie} />
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-center gap-2">
                  <button
                    onClick={() => setMoviesPage(p => Math.max(1, p - 1))}
                    disabled={moviesPage === 1}
                    className="bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-600 text-white px-4 py-2 rounded-lg transition"
                  >
                    قبلی
                  </button>
                  <span className="text-white px-4 py-2">
                    صفحه {moviesPage} از {totalPages}
                  </span>
                  <button
                    onClick={() => setMoviesPage(p => Math.min(totalPages, p + 1))}
                    disabled={moviesPage === totalPages}
                    className="bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-600 text-white px-4 py-2 rounded-lg transition"
                  >
                    بعدی
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        {/* فیلم‌های معروف از TMDB */}
        {actor.movie_credits && actor.movie_credits.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold text-white mb-6">فیلم‌های معروف</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
              {actor.movie_credits.slice(0, 12).map((credit) => (
                <div key={credit.tmdb_id} className="bg-gray-800 rounded-lg overflow-hidden">
                  {credit.poster_path && (
                    <img
                      src={`${TMDB_IMAGE_BASE}/w300${credit.poster_path}`}
                      alt={credit.title}
                      className="w-full h-auto"
                    />
                  )}
                  <div className="p-3">
                    <h3 className="text-white text-sm font-bold line-clamp-2">{credit.title}</h3>
                    {credit.character && (
                      <p className="text-gray-400 text-xs mt-1 line-clamp-1">{credit.character}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ActorDetail;
