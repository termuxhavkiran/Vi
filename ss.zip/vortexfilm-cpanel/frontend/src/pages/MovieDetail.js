import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { moviesAPI, aiAPI, reviewsAPI, userAPI } from '../utils/api';
import { getBackdropUrl, getPosterUrl, getProfileUrl } from '../utils/tmdb';
import { Star, Clock, Calendar, Sparkles, Users, HelpCircle, Eye, MessageSquare, Heart, Bookmark, Loader2, Play, Download } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import SEO from '../components/SEO';
import MovieSchema from '../components/MovieSchema';

const MovieDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [movie, setMovie] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [aiLoading, setAiLoading] = useState({});
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewText, setReviewText] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [activeTab, setActiveTab] = useState('overview');
  const [downloadLinks, setDownloadLinks] = useState([]);
  const [selectedVideoUrl, setSelectedVideoUrl] = useState(null);
  const [showPlayer, setShowPlayer] = useState(false);

  useEffect(() => {
    loadMovie();
    loadReviews();
    loadDownloadLinks();
  }, [id]);

  const loadMovie = async () => {
    try {
      setLoading(true);
      const response = await moviesAPI.getMovie(id);
      setMovie(response.data);
    } catch (error) {
      console.error('خطا در بارگذاری فیلم:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadReviews = async () => {
    try {
      const response = await reviewsAPI.getReviews(id);
      setReviews(response.data.reviews || []);
    } catch (error) {
      console.error('خطا در بارگذاری نظرات:', error);
    }
  };

  const loadDownloadLinks = async () => {
    try {
      const response = await moviesAPI.getDownloadLinks(id);
      setDownloadLinks(response.data.download_links || []);
    } catch (error) {
      console.error('خطا در بارگذاری لینک‌های دانلود:', error);
    }
  };

  const analyzeAI = async (type) => {
    setAiLoading({ ...aiLoading, [type]: true });
    try {
      let response;
      switch (type) {
        case 'mood':
          response = await aiAPI.analyzeMood(id);
          break;
        case 'characters':
          response = await aiAPI.analyzeCharacters(id);
          break;
        case 'ending':
          response = await aiAPI.predictEnding(id);
          break;
        case 'hidden':
          response = await aiAPI.findHidden(id);
          break;
        case 'review-analysis':
          response = await aiAPI.analyzeReviews(id);
          break;
        default:
          return;
      }
      
      setMovie({
        ...movie,
        ai_analysis: {
          ...movie.ai_analysis,
          [type === 'review-analysis' ? 'reviews' : type]: response.data,
        },
      });
    } catch (error) {
      console.error(`خطا در تحلیل ${type}:`, error);
    } finally {
      setAiLoading({ ...aiLoading, [type]: false });
    }
  };

  const submitReview = async (e) => {
    e.preventDefault();
    try {
      await reviewsAPI.createReview({
        movie_id: id,
        rating: reviewRating,
        comment: reviewText,
      });
      setReviewText('');
      setReviewRating(5);
      setShowReviewForm(false);
      loadReviews();
    } catch (error) {
      console.error('خطا در ثبت نظر:', error);
    }
  };

  const toggleWatchLater = async () => {
    try {
      if (movie.in_watch_later) {
        await userAPI.removeWatchLater(id);
      } else {
        await userAPI.addWatchLater(id);
      }
      setMovie({ ...movie, in_watch_later: !movie.in_watch_later });
    } catch (error) {
      console.error('خطا:', error);
    }
  };

  const toggleFavorite = async () => {
    try {
      if (movie.in_favorites) {
        await userAPI.removeFavorite(id);
      } else {
        await userAPI.addFavorite(id);
      }
      setMovie({ ...movie, in_favorites: !movie.in_favorites });
    } catch (error) {
      console.error('خطا:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-xl text-gray-400">فیلم یافت نشد</p>
      </div>
    );
  }

  const backdropUrl = movie.backdrop_path ? getBackdropUrl(movie.backdrop_path) : 'https://images.unsplash.com/photo-1746470320754-e0f1b261007e?w=1200';
  const posterUrl = movie.poster_path ? getPosterUrl(movie.poster_path) : '';
  const movieUrl = typeof window !== 'undefined' ? window.location.href : '';

  return (
    <>
      <SEO
        title={movie.title || movie.original_title}
        description={movie.overview || `تماشای آنلاین ${movie.title}`}
        keywords={`${movie.title}, ${movie.genres?.join(', ')}, فیلم, تماشای آنلاین, دانلود فیلم`}
        image={posterUrl}
        type="video.movie"
        url={movieUrl}
      />
      <MovieSchema movie={movie} />
      <div className="pb-24 pt-16" data-testid="movie-detail-page">
      {showPlayer && selectedVideoUrl && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-6xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold">{movie?.title}</h2>
              <button
                onClick={() => setShowPlayer(false)}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-full"
              >
                <Play className="w-6 h-6 rotate-90" />
              </button>
            </div>
            <div className="aspect-video bg-black rounded-xl overflow-hidden">
              <video
                controls
                autoPlay
                className="w-full h-full"
                src={selectedVideoUrl}
                data-testid="video-player"
              >
                مرورگر شما از پخش ویدئو پشتیبانی نمی‌کند.
              </video>
            </div>
            {downloadLinks.filter(link => link.type === 'upload').length > 1 && (
              <div className="mt-4 flex gap-2">
                <span className="text-gray-400">کیفیت:</span>
                {downloadLinks.filter(link => link.type === 'upload').map((link, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedVideoUrl(`${process.env.REACT_APP_BACKEND_URL}/api/stream/${id}/${link.filename}`)}
                    className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg"
                  >
                    {link.quality}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      <div
        className="relative h-[500px] -mt-16"
        style={{
          backgroundImage: `url(${backdropUrl})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-slate-950/20" />
        
        <div className="absolute bottom-0 right-0 left-0 px-4 pb-8 max-w-7xl mx-auto">
          <div className="flex gap-6">
            <img
              src={movie.poster_path ? getPosterUrl(movie.poster_path) : 'https://images.unsplash.com/photo-1683926574610-099f6da5f49c?w=500'}
              alt={movie.title}
              className="w-48 h-72 object-cover rounded-xl shadow-2xl hidden md:block"
            />
            
            <div className="flex-1">
              <h1 className="text-4xl md:text-5xl font-black mb-3">{movie.title}</h1>
              {movie.original_title !== movie.title && (
                <p className="text-xl text-gray-400 mb-4">{movie.original_title}</p>
              )}
              
              <div className="flex flex-wrap gap-2 mb-4">
                {movie.genres?.map((genre, i) => (
                  <span key={i} className="px-3 py-1 bg-fuchsia-500/20 border border-fuchsia-500/30 rounded-full text-sm">
                    {genre}
                  </span>
                ))}
              </div>

              <div className="flex flex-wrap gap-4 text-sm mb-4">
                {movie.vote_average > 0 && (
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                    <span className="font-bold text-lg">{movie.vote_average.toFixed(1)}</span>
                    <span className="text-gray-400">IMDB</span>
                  </div>
                )}
                {movie.runtime > 0 && (
                  <div className="flex items-center gap-2 text-gray-300">
                    <Clock className="w-5 h-5" />
                    <span>{movie.runtime} دقیقه</span>
                  </div>
                )}
                {movie.release_date && (
                  <div className="flex items-center gap-2 text-gray-300">
                    <Calendar className="w-5 h-5" />
                    <span>{new Date(movie.release_date).getFullYear()}</span>
                  </div>
                )}
              </div>

              {user && (
                <div className="flex gap-3 flex-wrap">
                  <button
                    onClick={toggleFavorite}
                    className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 rounded-full flex items-center gap-2 border border-red-500/30"
                    data-testid="favorite-button"
                  >
                    <Heart className={`w-5 h-5 ${movie.in_favorites ? 'fill-red-500 text-red-500' : ''}`} />
                    <span>علاقه‌مندی</span>
                  </button>
                  <button
                    onClick={toggleWatchLater}
                    className="px-4 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-full flex items-center gap-2 border border-cyan-500/30"
                    data-testid="watch-later-button"
                  >
                    <Bookmark className={`w-5 h-5 ${movie.in_watch_later ? 'fill-cyan-500 text-cyan-500' : ''}`} />
                    <span>بعداً تماشا می‌کنم</span>
                  </button>
                  {user.role === 'admin' && (
                    <button
                      onClick={() => window.location.href = `/admin/downloads/${id}`}
                      className="px-4 py-2 bg-fuchsia-500/20 hover:bg-fuchsia-500/30 rounded-full flex items-center gap-2 border border-fuchsia-500/30"
                    >
                      <Download className="w-5 h-5" />
                      <span>مدیریت دانلود</span>
                    </button>
                  )}
                </div>
              )}
              
              {downloadLinks.some(link => link.type === 'upload') && (
                <button
                  onClick={() => {
                    const uploadedLink = downloadLinks.find(link => link.type === 'upload');
                    if (uploadedLink) {
                      setSelectedVideoUrl(`${process.env.REACT_APP_BACKEND_URL}/api/stream/${id}/${uploadedLink.filename}`);
                      setShowPlayer(true);
                    }
                  }}
                  className="mt-3 px-6 py-3 bg-gradient-to-l from-fuchsia-600 to-cyan-600 hover:from-fuchsia-500 hover:to-cyan-500 rounded-full flex items-center justify-center gap-2 font-bold text-lg"
                  data-testid="watch-online-button"
                >
                  <Play className="w-6 h-6" />
                  <span>تماشای آنلاین</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 max-w-7xl mx-auto mt-8">
        <div className="flex gap-4 mb-6 overflow-x-auto scrollbar-hide pb-2">
          {['overview', 'cast', 'download', 'ai', 'reviews'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-2 rounded-full whitespace-nowrap ${
                activeTab === tab
                  ? 'bg-fuchsia-600 text-white'
                  : 'bg-slate-900/50 text-gray-400 hover:bg-slate-900'
              }`}
              data-testid={`tab-${tab}`}
            >
              {tab === 'overview' && 'اطلاعات'}
              {tab === 'cast' && 'بازیگران'}
              {tab === 'download' && 'دانلود'}
              {tab === 'ai' && 'تحلیل AI'}
              {tab === 'reviews' && 'نظرات'}
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-6" data-testid="overview-tab">
            <div className="glass-effect rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-4">خلاصه داستان</h2>
              <p className="text-gray-300 leading-relaxed">{movie.overview || 'خلاصه‌ای در دسترس نیست'}</p>
            </div>

            {movie.videos && movie.videos.length > 0 && (
              <div className="glass-effect rounded-2xl p-6">
                <h2 className="text-2xl font-bold mb-4">تریلر</h2>
                <div className="aspect-video bg-slate-900 rounded-lg overflow-hidden">
                  <iframe
                    src={`https://www.youtube.com/embed/${movie.videos[0].key}`}
                    title="Trailer"
                    className="w-full h-full"
                    allowFullScreen
                  />
                </div>
              </div>
            )}

            {movie.images && movie.images.length > 0 && (
              <div className="glass-effect rounded-2xl p-6">
                <h2 className="text-2xl font-bold mb-4">گالری تصاویر</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {movie.images.slice(0, 6).map((img, i) => (
                    <img
                      key={i}
                      src={getBackdropUrl(img)}
                      alt={`Screenshot ${i + 1}`}
                      className="w-full h-40 object-cover rounded-lg"
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'download' && (
          <div className="glass-effect rounded-2xl p-6" data-testid="download-tab">
            <div className="flex items-center gap-3 mb-6">
              <Download className="w-6 h-6 text-fuchsia-500" />
              <h2 className="text-2xl font-bold">لینک‌های دانلود</h2>
            </div>

            {downloadLinks.length > 0 ? (
              <div className="space-y-3">
                {downloadLinks.map((link, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-slate-900/50 rounded-xl border border-white/10 hover:border-fuchsia-500/30 transition-all">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-fuchsia-500/20 rounded-lg flex items-center justify-center">
                        <Download className="w-6 h-6 text-fuchsia-500" />
                      </div>
                      <div>
                        <p className="font-bold text-lg">{link.quality}</p>
                        <p className="text-sm text-gray-400">{link.size}</p>
                      </div>
                    </div>
                    <a
                      href={link.type === 'upload' 
                        ? `${process.env.REACT_APP_BACKEND_URL}/api/stream/${id}/${link.filename}` 
                        : link.url
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      download
                      className="px-6 py-2 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full font-bold flex items-center gap-2"
                    >
                      <Download className="w-5 h-5" />
                      دانلود
                    </a>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Download className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-xl text-gray-400">لینک دانلود موجود نیست</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'cast' && (
          <div className="glass-effect rounded-2xl p-6" data-testid="cast-tab">
            <h2 className="text-2xl font-bold mb-6">بازیگران و عوامل</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {movie.cast?.map((member, i) => (
                <div key={i} className="text-center">
                  <div className="w-full aspect-square rounded-lg overflow-hidden mb-2 bg-slate-900">
                    <img
                      src={member.profile_path ? getProfileUrl(member.profile_path) : 'https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=200'}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="font-semibold text-sm">{member.name}</p>
                  <p className="text-xs text-gray-400">{member.character}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'ai' && (
          <div className="space-y-6" data-testid="ai-tab">
            <div className="ai-card">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Sparkles className="w-6 h-6 text-cyan-400" />
                  <h3 className="text-xl font-bold">حس و هوای فیلم</h3>
                </div>
                {!movie.ai_analysis?.mood && (
                  <button
                    onClick={() => analyzeAI('mood')}
                    disabled={aiLoading.mood}
                    className="px-4 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-full text-sm border border-cyan-500/30 flex items-center gap-2"
                    data-testid="analyze-mood-button"
                  >
                    {aiLoading.mood ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تحلیل'}
                  </button>
                )}
              </div>
              {movie.ai_analysis?.mood ? (
                <p className="text-gray-300">{movie.ai_analysis.mood.keywords}</p>
              ) : (
                <p className="text-gray-500">برای مشاهده تحلیل، روی دکمه تحلیل کلیک کنید</p>
              )}
            </div>

            <div className="ai-card" style={{ borderColor: 'rgba(217, 70, 239, 0.2)' }}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Users className="w-6 h-6 text-purple-400" />
                  <h3 className="text-xl font-bold">تحلیل شخصیت‌ها</h3>
                </div>
                {!movie.ai_analysis?.characters && (
                  <button
                    onClick={() => analyzeAI('characters')}
                    disabled={aiLoading.characters}
                    className="px-4 py-2 bg-purple-500/20 hover:bg-purple-500/30 rounded-full text-sm border border-purple-500/30 flex items-center gap-2"
                    data-testid="analyze-characters-button"
                  >
                    {aiLoading.characters ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تحلیل'}
                  </button>
                )}
              </div>
              {movie.ai_analysis?.characters ? (
                <p className="text-gray-300 whitespace-pre-line">{movie.ai_analysis.characters.analysis}</p>
              ) : (
                <p className="text-gray-500">برای مشاهده تحلیل، روی دکمه تحلیل کلیک کنید</p>
              )}
            </div>

            <div className="ai-card" style={{ borderColor: 'rgba(244, 63, 94, 0.2)' }}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <HelpCircle className="w-6 h-6 text-rose-400" />
                  <h3 className="text-xl font-bold">حدس پایان</h3>
                </div>
                {!movie.ai_analysis?.ending && (
                  <button
                    onClick={() => analyzeAI('ending')}
                    disabled={aiLoading.ending}
                    className="px-4 py-2 bg-rose-500/20 hover:bg-rose-500/30 rounded-full text-sm border border-rose-500/30 flex items-center gap-2"
                    data-testid="analyze-ending-button"
                  >
                    {aiLoading.ending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تحلیل'}
                  </button>
                )}
              </div>
              {movie.ai_analysis?.ending ? (
                <p className="text-gray-300 whitespace-pre-line">{movie.ai_analysis.ending.predictions}</p>
              ) : (
                <p className="text-gray-500">برای مشاهده پیش‌بینی‌های پایان، روی دکمه تحلیل کلیک کنید</p>
              )}
            </div>

            <div className="ai-card">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Eye className="w-6 h-6 text-cyan-400" />
                  <h3 className="text-xl font-bold">جزئیات پنهان</h3>
                </div>
                {!movie.ai_analysis?.hidden && (
                  <button
                    onClick={() => analyzeAI('hidden')}
                    disabled={aiLoading.hidden}
                    className="px-4 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-full text-sm border border-cyan-500/30 flex items-center gap-2"
                    data-testid="analyze-hidden-button"
                  >
                    {aiLoading.hidden ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تحلیل'}
                  </button>
                )}
              </div>
              {movie.ai_analysis?.hidden ? (
                <p className="text-gray-300 whitespace-pre-line">{movie.ai_analysis.hidden.details}</p>
              ) : (
                <p className="text-gray-500">برای کشف جزئیات پنهان، روی دکمه تحلیل کلیک کنید</p>
              )}
            </div>

            {reviews.length > 0 && (
              <div className="ai-card">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <MessageSquare className="w-6 h-6 text-cyan-400" />
                    <h3 className="text-xl font-bold">تحلیل نظرات</h3>
                  </div>
                  {!movie.ai_analysis?.reviews && (
                    <button
                      onClick={() => analyzeAI('review-analysis')}
                      disabled={aiLoading['review-analysis']}
                      className="px-4 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-full text-sm border border-cyan-500/30 flex items-center gap-2"
                      data-testid="analyze-reviews-button"
                    >
                      {aiLoading['review-analysis'] ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تحلیل'}
                    </button>
                  )}
                </div>
                {movie.ai_analysis?.reviews ? (
                  <p className="text-gray-300 whitespace-pre-line">{movie.ai_analysis.reviews.analysis}</p>
                ) : (
                  <p className="text-gray-500">برای مشاهده تحلیل نظرات، روی دکمه تحلیل کلیک کنید</p>
                )}
              </div>
            )}
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-6" data-testid="reviews-tab">
            {user && (
              <div className="glass-effect rounded-2xl p-6">
                {!showReviewForm ? (
                  <button
                    onClick={() => setShowReviewForm(true)}
                    className="w-full py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full font-bold"
                    data-testid="add-review-button"
                  >
                    افزودن نظر
                  </button>
                ) : (
                  <form onSubmit={submitReview} className="space-y-4">
                    <div>
                      <label className="block mb-2">امتیاز: {reviewRating}/10</label>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        value={reviewRating}
                        onChange={(e) => setReviewRating(parseInt(e.target.value))}
                        className="w-full"
                        data-testid="rating-input"
                      />
                    </div>
                    <textarea
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      placeholder="نظر خود را بنویسید..."
                      className="w-full px-4 py-3 bg-slate-900/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500 min-h-[120px]"
                      required
                      data-testid="review-text-input"
                    />
                    <div className="flex gap-3">
                      <button
                        type="submit"
                        className="flex-1 py-2 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full font-bold"
                        data-testid="submit-review-button"
                      >
                        ثبت نظر
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowReviewForm(false)}
                        className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 rounded-full font-bold"
                      >
                        انصراف
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

            <div className="space-y-4">
              {reviews.length > 0 ? (
                reviews.map((review) => (
                  <div key={review._id} className="glass-effect rounded-2xl p-6" data-testid="review-item">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="font-bold">{review.user_name}</p>
                        <p className="text-sm text-gray-400">
                          {new Date(review.created_at).toLocaleDateString('fa-IR')}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                        <span className="font-bold">{review.rating}/10</span>
                      </div>
                    </div>
                    <p className="text-gray-300">{review.comment}</p>
                  </div>
                ))
              ) : (
                <div className="glass-effect rounded-2xl p-12 text-center">
                  <p className="text-gray-400">هنوز نظری ثبت نشده است</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      </div>
    </>
  );
};

export default MovieDetail;
