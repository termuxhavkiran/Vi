import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { adminAPI } from '../utils/api';
import { useNavigate } from 'react-router-dom';
import { Settings as SettingsIcon, Save, Loader2, Key, Globe } from 'lucide-react';

const Settings = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState({
    site_title: '',
    site_description: '',
    site_logo: '',
    tmdb_api_key: '',
    groq_api_key: ''
  });
  const [currentKeys, setCurrentKeys] = useState({
    tmdb_api_key_exists: false,
    groq_api_key_exists: false
  });

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    loadSettings();
  }, [user, navigate]);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getSettings();
      const data = response.data;
      setSettings({
        site_title: data.site_title || '',
        site_description: data.site_description || '',
        site_logo: data.site_logo || '',
        tmdb_api_key: '',
        groq_api_key: ''
      });
      setCurrentKeys({
        tmdb_api_key_exists: data.tmdb_api_key_exists,
        groq_api_key_exists: data.groq_api_key_exists
      });
    } catch (error) {
      console.error('خطا:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const dataToSend = {};
      
      if (settings.site_title) dataToSend.site_title = settings.site_title;
      if (settings.site_description) dataToSend.site_description = settings.site_description;
      if (settings.site_logo) dataToSend.site_logo = settings.site_logo;
      if (settings.tmdb_api_key) dataToSend.tmdb_api_key = settings.tmdb_api_key;
      if (settings.groq_api_key) dataToSend.groq_api_key = settings.groq_api_key;

      await adminAPI.updateSettings(dataToSend);
      alert('تنظیمات با موفقیت ذخیره شد');
      loadSettings();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در ذخیره تنظیمات');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="px-4 pb-24 pt-20 max-w-4xl mx-auto" data-testid="settings-page">
      <div className="mb-8">
        <h1 className="text-4xl font-black mb-2">تنظیمات سایت</h1>
        <p className="text-gray-400">مدیریت تنظیمات عمومی و کلیدهای API</p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* تنظیمات ظاهری */}
        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <Globe className="w-6 h-6 text-cyan-500" />
            <h2 className="text-2xl font-bold">تنظیمات ظاهری سایت</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block mb-2 text-sm font-semibold">عنوان سایت</label>
              <input
                type="text"
                value={settings.site_title}
                onChange={(e) => setSettings({...settings, site_title: e.target.value})}
                placeholder="VortexFilm"
                className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block mb-2 text-sm font-semibold">توضیحات سایت</label>
              <textarea
                value={settings.site_description}
                onChange={(e) => setSettings({...settings, site_description: e.target.value})}
                placeholder="پلتفرم تماشای آنلاین فیلم و سریال با تحلیل‌های هوش مصنوعی"
                rows="3"
                className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block mb-2 text-sm font-semibold">URL لوگوی سایت</label>
              <input
                type="url"
                value={settings.site_logo}
                onChange={(e) => setSettings({...settings, site_logo: e.target.value})}
                placeholder="https://example.com/logo.png"
                className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
              <p className="text-xs text-gray-500 mt-1">آدرس کامل لوگوی سایت را وارد کنید</p>
            </div>
          </div>
        </div>

        {/* کلیدهای API */}
        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <Key className="w-6 h-6 text-fuchsia-500" />
            <h2 className="text-2xl font-bold">کلیدهای دسترسی API</h2>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold">TMDB API Key</label>
                {currentKeys.tmdb_api_key_exists && (
                  <span className="text-xs text-green-400">✓ کلید موجود است</span>
                )}
              </div>
              <input
                type="password"
                value={settings.tmdb_api_key}
                onChange={(e) => setSettings({...settings, tmdb_api_key: e.target.value})}
                placeholder={currentKeys.tmdb_api_key_exists ? "برای تغییر کلید جدید وارد کنید" : "کلید TMDB را وارد کنید"}
                className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                برای دریافت کلید به{' '}
                <a href="https://www.themoviedb.org/settings/api" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline">
                  TMDB.org
                </a>
                {' '}مراجعه کنید
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold">Groq API Key</label>
                {currentKeys.groq_api_key_exists && (
                  <span className="text-xs text-green-400">✓ کلید موجود است</span>
                )}
              </div>
              <input
                type="password"
                value={settings.groq_api_key}
                onChange={(e) => setSettings({...settings, groq_api_key: e.target.value})}
                placeholder={currentKeys.groq_api_key_exists ? "برای تغییر کلید جدید وارد کنید" : "کلید Groq را وارد کنید"}
                className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                برای دریافت کلید به{' '}
                <a href="https://console.groq.com/" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline">
                  Groq Console
                </a>
                {' '}مراجعه کنید
              </p>
            </div>
          </div>
        </div>

        {/* دکمه ذخیره */}
        <button
          type="submit"
          disabled={saving}
          className="w-full py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-full font-bold text-lg flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {saving ? (
            <>
              <Loader2 className="w-6 h-6 animate-spin" />
              <span>در حال ذخیره...</span>
            </>
          ) : (
            <>
              <Save className="w-6 h-6" />
              <span>ذخیره تنظیمات</span>
            </>
          )}
        </button>
      </form>

      {/* اطلاعات مهم */}
      <div className="mt-6 glass-effect rounded-2xl p-6">
        <h3 className="font-bold mb-3">⚠️ نکات مهم:</h3>
        <ul className="text-sm text-gray-400 space-y-2 list-disc list-inside">
          <li>کلیدهای API به صورت امن در سرور ذخیره می‌شوند</li>
          <li>تغییر کلیدها ممکن است نیاز به ری‌استارت سرور داشته باشد</li>
          <li>کلید TMDB برای وارد کردن فیلم‌ها و سریال‌ها ضروری است</li>
          <li>کلید Groq برای ترجمه خودکار و تحلیل‌های هوش مصنوعی استفاده می‌شود</li>
        </ul>
      </div>
    </div>
  );
};

export default Settings;
