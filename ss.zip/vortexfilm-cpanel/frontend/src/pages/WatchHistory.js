import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import { Clock, Trash2, X } from 'lucide-react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';
const TMDB_IMAGE_BASE = process.env.REACT_APP_TMDB_IMAGE_BASE || 'https://image.tmdb.org/t/p';

const WatchHistory = () => {
  const { user } = useAuth();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchWatchHistory();
    }
  }, [user]);

  const fetchWatchHistory = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/api/watch-history`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setHistory(response.data.watch_history || []);
    } catch (error) {
      console.error('خطا در دریافت تاریخچه:', error);
    } finally {
      setLoading(false);
    }
  };

  const clearHistory = async () => {
    if (!window.confirm('آیا مطمئن هستید که می‌خواهید تاریخچه تماشا را پاک کنید؟')) return;
    
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_URL}/api/watch-history`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setHistory([]);
      alert('تاریخچه تماشا پاک شد');
    } catch (error) {
      console.error('خطا در پاک کردن تاریخچه:', error);
      alert('خطا در پاک کردن تاریخچه');
    }
  };

  const removeItem = async (movieId) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_URL}/api/watch-history/${movieId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setHistory(history.filter(item => item._id !== movieId));
    } catch (error) {
      console.error('خطا در حذف:', error);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-white mb-4">لطفاً وارد شوید</h2>
          <Link to="/login" className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg">
            ورود به حساب کاربری
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Clock className="w-8 h-8 text-red-500" />
            تاریخچه تماشا
          </h1>
          {history.length > 0 && (
            <button
              onClick={clearHistory}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition"
            >
              <Trash2 className="w-4 h-4" />
              پاک کردن همه
            </button>
          )}
        </div>

        {loading ? (
          <div className="text-center text-gray-400 py-20">در حال بارگذاری...</div>
        ) : history.length === 0 ? (
          <div className="text-center py-20">
            <Clock className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">تاریخچه تماشای شما خالی است</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {history.map((movie) => (
              <div key={movie._id} className="group relative">
                <Link to={`/movie/${movie._id}`} className="block">
                  <div className="relative overflow-hidden rounded-lg shadow-lg transition-transform duration-300 group-hover:scale-105">
                    <img
                      src={movie.poster_path ? `${TMDB_IMAGE_BASE}/w500${movie.poster_path}` : '/placeholder.jpg'}
                      alt={movie.title}
                      className="w-full h-auto"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="absolute bottom-0 left-0 right-0 p-3">
                        <h3 className="text-white font-bold text-sm line-clamp-2">{movie.title}</h3>
                        <p className="text-gray-300 text-xs mt-1">
                          {formatDate(movie.last_watched)}
                        </p>
                      </div>
                    </div>
                  </div>
                </Link>
                <button
                  onClick={() => removeItem(movie._id)}
                  className="absolute top-2 right-2 bg-red-600 hover:bg-red-700 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  title="حذف از تاریخچه"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default WatchHistory;
