import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2 } from 'lucide-react';

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let result;
      if (isLogin) {
        result = await login(email, password);
      } else {
        result = await register(email, password, fullName);
      }

      if (result.success) {
        navigate('/');
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('خطای غیرمنتظره رخ داد');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4 pb-20"
      style={{
        backgroundImage: 'url(https://images.unsplash.com/photo-1653939613212-51d2e4a1288b?w=1200)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
      data-testid="login-page"
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm"></div>
      
      <div className="relative w-full max-w-md glass-effect rounded-2xl p-8 shadow-2xl" data-testid="auth-form">
        <div className="text-center mb-8">
          <Link to="/">
            <h1 className="text-4xl font-black mb-2 bg-gradient-to-l from-fuchsia-500 to-cyan-400 bg-clip-text text-transparent">
              VortexFilm
            </h1>
          </Link>
          <p className="text-gray-400">{isLogin ? 'ورود به حساب کاربری' : 'ایجاد حساب جدید'}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-sm font-medium mb-2">نام کامل</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-4 py-3 bg-slate-900/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                required
                data-testid="fullname-input"
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium mb-2">ایمیل</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 bg-slate-900/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
              required
              data-testid="email-input"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">رمز عبور</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-slate-900/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
              required
              minLength={6}
              data-testid="password-input"
            />
          </div>

          {error && (
            <div className="bg-red-500/20 border border-red-500/50 text-red-400 px-4 py-3 rounded-lg text-sm" data-testid="error-message">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-fuchsia-600 hover:bg-fuchsia-500 text-white py-3 rounded-full font-bold neon-glow-pink disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            data-testid="submit-button"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>در حال پردازش...</span>
              </>
            ) : (
              <span>{isLogin ? 'ورود' : 'ثبت‌نام'}</span>
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setError('');
            }}
            className="text-fuchsia-400 hover:text-fuchsia-300"
            data-testid="toggle-auth-mode"
          >
            {isLogin ? 'حساب ندارید؟ ثبت‌نام کنید' : 'قبلاً ثبت‌نام کرده‌اید؟ ورود'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
