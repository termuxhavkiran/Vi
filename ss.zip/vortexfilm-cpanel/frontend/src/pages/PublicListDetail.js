import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { List, Users, Heart, ArrowLeft, Edit, Trash2 } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const PublicListDetail = () => {
  const { listId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [list, setList] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isFollowing, setIsFollowing] = useState(false);

  useEffect(() => {
    fetchListDetail();
  }, [listId]);

  const fetchListDetail = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/public-lists/${listId}`);
      setList(response.data);
      if (user) {
        setIsFollowing(response.data.followers?.includes(user.id) || false);
      }
    } catch (error) {
      console.error('خطا در دریافت لیست:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFollow = async () => {
    if (!user) {
      alert('لطفاً ابتدا وارد شوید');
      navigate('/login');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${API_URL}/api/public-lists/${listId}/follow`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setIsFollowing(response.data.action === 'follow');
      fetchListDetail();
    } catch (error) {
      console.error('خطا در دنبال کردن:', error);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('آیا مطمئن هستید که می‌خواهید این لیست را حذف کنید؟')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_URL}/api/public-lists/${listId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('لیست حذف شد');
      navigate('/my-lists');
    } catch (error) {
      console.error('خطا در حذف لیست:', error);
      alert('خطا در حذف لیست');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
        <div className="text-center text-gray-400 py-20">در حال بارگذاری...</div>
      </div>
    );
  }

  if (!list) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
        <div className="text-center py-20">
          <List className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">لیست یافت نشد</p>
        </div>
      </div>
    );
  }

  const isOwner = user && user.id === list.owner_id;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
      <div className="max-w-6xl mx-auto">
        <Link
          to="/public-lists"
          className="text-red-500 hover:text-red-400 flex items-center gap-2 mb-6 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          بازگشت به لیست‌ها
        </Link>

        <div className="bg-gray-800/50 rounded-lg p-8 mb-8">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-white mb-2">{list.name}</h1>
              {list.description && (
                <p className="text-gray-400 mb-4">{list.description}</p>
              )}
              <div className="flex items-center gap-4 text-gray-300">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span>{list.owner_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4" />
                  <span>{list.follower_count || 0} دنبال‌کننده</span>
                </div>
                <div>{list.movies?.length || 0} فیلم</div>
              </div>
            </div>

            <div className="flex gap-2">
              {!isOwner && user && (
                <button
                  onClick={handleFollow}
                  className={`${
                    isFollowing
                      ? 'bg-gray-600 hover:bg-gray-700'
                      : 'bg-red-600 hover:bg-red-700'
                  } text-white px-4 py-2 rounded-lg flex items-center gap-2 transition`}
                >
                  <Heart className={`w-4 h-4 ${isFollowing ? 'fill-current' : ''}`} />
                  {isFollowing ? 'دنبال می‌کنید' : 'دنبال کردن'}
                </button>
              )}

              {isOwner && (
                <>
                  <button
                    onClick={() => navigate(`/edit-list/${listId}`)}
                    className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-lg transition"
                    title="ویرایش"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleDelete}
                    className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-lg transition"
                    title="حذف"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* فیلم‌ها */}
        {list.movies && list.movies.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {list.movies.map((movie) => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <List className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">این لیست خالی است</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PublicListDetail;