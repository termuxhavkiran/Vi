import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { adminAPI } from '../utils/api';
import { useNavigate } from 'react-router-dom';
import { Users, Search, Shield, UserX, Loader2 } from 'lucide-react';

const ManageUsers = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    loadUsers();
  }, [user, navigate, page, search, roleFilter]);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getAllUsers(page, search, roleFilter);
      setUsers(response.data.users);
      setTotal(response.data.total);
    } catch (error) {
      console.error('خطا:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId, currentRole) => {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    if (!window.confirm(`آیا می‌خواهید نقش این کاربر را به ${newRole === 'admin' ? 'ادمین' : 'کاربر عادی'} تغییر دهید؟`)) return;
    
    try {
      await adminAPI.updateUserRole(userId, newRole);
      alert('نقش کاربر با موفقیت تغییر یافت');
      loadUsers();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در تغییر نقش کاربر');
    }
  };

  const handleDelete = async (userId, userName) => {
    if (!window.confirm(`آیا از حذف کاربر "${userName}" مطمئن هستید؟ این عمل قابل بازگشت نیست.`)) return;
    
    try {
      await adminAPI.deleteUser(userId);
      alert('کاربر با موفقیت حذف شد');
      loadUsers();
    } catch (error) {
      console.error('خطا:', error);
      alert(error.response?.data?.detail || 'خطا در حذف کاربر');
    }
  };

  const totalPages = Math.ceil(total / 20);

  if (loading && page === 1) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="manage-users-page">
      <div className="mb-8">
        <h1 className="text-4xl font-black mb-2">مدیریت کاربران</h1>
        <p className="text-gray-400">مشاهده و مدیریت کاربران سایت</p>
      </div>

      {/* فیلترها */}
      <div className="glass-effect rounded-2xl p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center gap-3">
            <Search className="w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="جستجوی نام یا ایمیل..."
              className="flex-1 bg-transparent border-none outline-none"
            />
          </div>
          <div>
            <select
              value={roleFilter}
              onChange={(e) => {
                setRoleFilter(e.target.value);
                setPage(1);
              }}
              className="w-full px-4 py-3 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
            >
              <option value="">همه کاربران</option>
              <option value="admin">فقط ادمین‌ها</option>
              <option value="user">فقط کاربران عادی</option>
            </select>
          </div>
        </div>
      </div>

      {/* لیست کاربران */}
      <div className="glass-effect rounded-2xl p-6 mb-6">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-right py-4 px-4">نام</th>
                <th className="text-right py-4 px-4">ایمیل</th>
                <th className="text-right py-4 px-4">نقش</th>
                <th className="text-right py-4 px-4">تاریخ ثبت‌نام</th>
                <th className="text-right py-4 px-4">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {users.map((usr) => (
                <tr key={usr._id} className="border-b border-white/5 hover:bg-white/5">
                  <td className="py-4 px-4 font-bold">{usr.full_name}</td>
                  <td className="py-4 px-4 text-gray-400 text-sm">{usr.email}</td>
                  <td className="py-4 px-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      usr.role === 'admin' ? 'bg-fuchsia-500/20 text-fuchsia-400' : 'bg-gray-500/20 text-gray-400'
                    }`}>
                      {usr.role === 'admin' ? 'ادمین' : 'کاربر'}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-gray-400 text-sm">
                    {new Date(usr.created_at).toLocaleDateString('fa-IR')}
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleRoleChange(usr._id, usr.role)}
                        className="p-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-lg text-cyan-400"
                        title="تغییر نقش"
                      >
                        <Shield className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(usr._id, usr.full_name)}
                        className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg text-red-400"
                        title="حذف کاربر"
                        disabled={usr._id === user._id}
                      >
                        <UserX className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* صفحه‌بندی */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-6">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="px-4 py-2 bg-slate-900 rounded-lg disabled:opacity-50"
            >
              قبلی
            </button>
            <span className="text-gray-400">
              صفحه {page} از {totalPages}
            </span>
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="px-4 py-2 bg-slate-900 rounded-lg disabled:opacity-50"
            >
              بعدی
            </button>
          </div>
        )}
      </div>

      {/* آمار کلی */}
      <div className="glass-effect rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Users className="w-6 h-6 text-fuchsia-500" />
          <h2 className="text-xl font-bold">آمار کاربران</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-1">تعداد کل</p>
            <p className="text-2xl font-black">{total}</p>
          </div>
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-1">ادمین‌ها</p>
            <p className="text-2xl font-black">{users.filter(u => u.role === 'admin').length}</p>
          </div>
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-1">کاربران عادی</p>
            <p className="text-2xl font-black">{users.filter(u => u.role === 'user').length}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageUsers;