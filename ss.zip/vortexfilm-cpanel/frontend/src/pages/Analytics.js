import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { 
  TrendingUp, 
  Users, 
  Eye, 
  Film, 
  Calendar,
  ArrowRight,
  BarChart3,
  Activity
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const Analytics = () => {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [analytics, setAnalytics] = useState(null);
  const [days, setDays] = useState(7);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    fetchAnalytics();
  }, [user, navigate, days]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${API_URL}/api/admin/analytics/overview?days=${days}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      setAnalytics(response.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 p-6 pt-24">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <BarChart3 className="w-8 h-8 text-purple-400" />
            <h1 className="text-3xl font-bold text-white">آمار و تحلیل</h1>
          </div>
          
          <select
            value={days}
            onChange={(e) => setDays(Number(e.target.value))}
            className="bg-gray-800 text-white px-4 py-2 rounded-lg border border-purple-500/30 focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value={7}>۷ روز اخیر</option>
            <option value={14}>۱۴ روز اخیر</option>
            <option value={30}>۳۰ روز اخیر</option>
            <option value={90}>۹۰ روز اخیر</option>
          </select>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Total Views */}
          <div className="bg-gradient-to-br from-purple-600 to-indigo-600 rounded-2xl p-6 shadow-xl border border-purple-400/20">
            <div className="flex items-center justify-between mb-4">
              <Eye className="w-8 h-8 text-white" />
              <Activity className="w-6 h-6 text-purple-200" />
            </div>
            <h3 className="text-white text-lg mb-2">مجموع بازدیدها</h3>
            <p className="text-4xl font-bold text-white">
              {analytics?.total_views?.toLocaleString('fa-IR') || '0'}
            </p>
          </div>

          {/* Active Users */}
          <div className="bg-gradient-to-br from-blue-600 to-cyan-600 rounded-2xl p-6 shadow-xl border border-blue-400/20">
            <div className="flex items-center justify-between mb-4">
              <Users className="w-8 h-8 text-white" />
              <TrendingUp className="w-6 h-6 text-blue-200" />
            </div>
            <h3 className="text-white text-lg mb-2">کاربران فعال</h3>
            <p className="text-4xl font-bold text-white">
              {analytics?.active_users?.toLocaleString('fa-IR') || '0'}
            </p>
          </div>

          {/* Period */}
          <div className="bg-gradient-to-br from-pink-600 to-rose-600 rounded-2xl p-6 shadow-xl border border-pink-400/20">
            <div className="flex items-center justify-between mb-4">
              <Calendar className="w-8 h-8 text-white" />
              <BarChart3 className="w-6 h-6 text-pink-200" />
            </div>
            <h3 className="text-white text-lg mb-2">دوره زمانی</h3>
            <p className="text-4xl font-bold text-white">
              {days} روز
            </p>
          </div>
        </div>

        {/* Top Movies */}
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <Film className="w-6 h-6 text-purple-400" />
            <h2 className="text-2xl font-bold text-white">فیلم‌های پربازدید</h2>
          </div>

          <div className="space-y-4">
            {analytics?.top_movies?.map((movie, index) => (
              <div
                key={movie._id}
                className="bg-gray-700/50 rounded-xl p-4 flex items-center gap-4 hover:bg-gray-700 transition-all cursor-pointer"
                onClick={() => navigate(`/movie/${movie._id}`)}
              >
                <div className="flex items-center justify-center w-12 h-12 bg-purple-600 rounded-full text-white font-bold text-xl">
                  {index + 1}
                </div>
                
                {movie.poster_path && (
                  <img
                    src={`https://image.tmdb.org/t/p/w200${movie.poster_path}`}
                    alt={movie.title}
                    className="w-16 h-24 object-cover rounded-lg"
                  />
                )}
                
                <div className="flex-1">
                  <h3 className="text-white font-bold text-lg mb-1">{movie.title}</h3>
                  <p className="text-gray-400 text-sm">{movie.release_date?.split('-')[0] || 'نامشخص'}</p>
                </div>
                
                <div className="text-left">
                  <p className="text-purple-400 font-bold text-lg">
                    {movie.view_count?.toLocaleString('fa-IR') || '0'}
                  </p>
                  <p className="text-gray-400 text-sm">بازدید</p>
                </div>
                
                <ArrowRight className="w-6 h-6 text-gray-500" />
              </div>
            ))}
          </div>
        </div>

        {/* Daily Stats Chart */}
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-6 h-6 text-purple-400" />
            <h2 className="text-2xl font-bold text-white">آمار روزانه</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="py-3 px-4 text-purple-400 font-semibold">تاریخ</th>
                  <th className="py-3 px-4 text-purple-400 font-semibold">کاربران جدید</th>
                  <th className="py-3 px-4 text-purple-400 font-semibold">فیلم‌های جدید</th>
                </tr>
              </thead>
              <tbody>
                {analytics?.daily_stats?.map((stat, index) => (
                  <tr 
                    key={index}
                    className="border-b border-gray-700/50 hover:bg-gray-700/30 transition-colors"
                  >
                    <td className="py-3 px-4 text-white">{stat.date}</td>
                    <td className="py-3 px-4 text-green-400 font-semibold">
                      {stat.new_users.toLocaleString('fa-IR')}
                    </td>
                    <td className="py-3 px-4 text-blue-400 font-semibold">
                      {stat.new_movies.toLocaleString('fa-IR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
