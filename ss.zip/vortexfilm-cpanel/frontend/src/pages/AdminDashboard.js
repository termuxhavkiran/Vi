import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { adminAPI } from '../utils/api';
import { useNavigate } from 'react-router-dom';
import { BarChart3, Film, Users, MessageSquare, TrendingUp, Loader2, Tv } from 'lucide-react';

const AdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    loadStats();
  }, [user, navigate]);

  const loadStats = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getStats();
      setStats(response.data);
    } catch (error) {
      console.error('خطا در دریافت آمار:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="admin-dashboard">
      <div className="mb-8">
        <h1 className="text-4xl font-black mb-2">داشبورد مدیریت</h1>
        <p className="text-gray-400">آمار و مدیریت کلی سایت VortexFilm</p>
      </div>

      {/* آمار کلی */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-fuchsia-500/20 rounded-lg flex items-center justify-center">
              <Film className="w-6 h-6 text-fuchsia-500" />
            </div>
            <div>
              <p className="text-sm text-gray-400">تعداد فیلم‌ها</p>
              <p className="text-2xl font-black">{stats?.totals.movies || 0}</p>
            </div>
          </div>
        </div>

        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center">
              <Tv className="w-6 h-6 text-cyan-500" />
            </div>
            <div>
              <p className="text-sm text-gray-400">تعداد سریال‌ها</p>
              <p className="text-2xl font-black">{stats?.totals.series || 0}</p>
            </div>
          </div>
        </div>

        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-green-500" />
            </div>
            <div>
              <p className="text-sm text-gray-400">تعداد کاربران</p>
              <p className="text-2xl font-black">{stats?.totals.users || 0}</p>
            </div>
          </div>
        </div>

        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-yellow-500" />
            </div>
            <div>
              <p className="text-sm text-gray-400">تعداد نظرات</p>
              <p className="text-2xl font-black">{stats?.totals.reviews || 0}</p>
            </div>
          </div>
        </div>
      </div>

      {/* نمودارها و لیست‌ها */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* نمودار فعالیت کاربران */}
        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-6 h-6 text-cyan-500" />
            <h2 className="text-xl font-bold">فعالیت کاربران (هفته اخیر)</h2>
          </div>
          <div className="space-y-3">
            {stats?.weekly_users?.map((day, index) => (
              <div key={index}>
                <div className="flex items-center justify-between mb-1 text-sm">
                  <span className="text-gray-400">{new Date(day.date).toLocaleDateString('fa-IR')}</span>
                  <span className="font-bold">{day.count} کاربر</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 h-2 rounded-full"
                    style={{ width: `${Math.min((day.count / Math.max(...stats.weekly_users.map(d => d.count), 1)) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* فیلم‌های پربازدید */}
        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <BarChart3 className="w-6 h-6 text-fuchsia-500" />
            <h2 className="text-xl font-bold">فیلم‌های برتر</h2>
          </div>
          <div className="space-y-3">
            {stats?.popular_movies?.slice(0, 5).map((movie) => (
              <div
                key={movie._id}
                className="flex items-center gap-3 p-3 bg-slate-900/50 rounded-lg hover:bg-slate-900 cursor-pointer transition-colors"
                onClick={() => navigate(`/movie/${movie._id}`)}
              >
                {movie.poster_path ? (
                  <img
                    src={`https://image.tmdb.org/t/p/w92${movie.poster_path}`}
                    alt={movie.title}
                    className="w-12 h-16 object-cover rounded"
                  />
                ) : (
                  <div className="w-12 h-16 bg-slate-800 rounded flex items-center justify-center">
                    <Film className="w-6 h-6 text-gray-600" />
                  </div>
                )}
                <div className="flex-1">
                  <p className="font-bold text-sm">{movie.title}</p>
                  <p className="text-xs text-gray-400">امتیاز: {movie.vote_average?.toFixed(1)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* آخرین فیلم‌ها */}
      <div className="glass-effect rounded-2xl p-6 mb-8">
        <h2 className="text-xl font-bold mb-6">آخرین فیلم‌های اضافه شده</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {stats?.recent_movies?.map((movie) => (
            <div
              key={movie._id}
              className="flex items-start gap-3 p-4 bg-slate-900/50 rounded-lg hover:bg-slate-900 cursor-pointer transition-colors"
              onClick={() => navigate(`/movie/${movie._id}`)}
            >
              {movie.poster_path ? (
                <img
                  src={`https://image.tmdb.org/t/p/w92${movie.poster_path}`}
                  alt={movie.title}
                  className="w-16 h-24 object-cover rounded"
                />
              ) : (
                <div className="w-16 h-24 bg-slate-800 rounded flex items-center justify-center">
                  <Film className="w-8 h-8 text-gray-600" />
                </div>
              )}
              <div className="flex-1">
                <p className="font-bold text-sm mb-1">{movie.title}</p>
                <p className="text-xs text-gray-400 line-clamp-2">{movie.overview}</p>
                <p className="text-xs text-gray-500 mt-2">
                  {new Date(movie.created_at).toLocaleDateString('fa-IR')}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* آخرین کاربران */}
      <div className="glass-effect rounded-2xl p-6">
        <h2 className="text-xl font-bold mb-6">آخرین کاربران ثبت‌نام شده</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-right py-3 px-4">نام</th>
                <th className="text-right py-3 px-4">ایمیل</th>
                <th className="text-right py-3 px-4">نقش</th>
                <th className="text-right py-3 px-4">تاریخ ثبت‌نام</th>
              </tr>
            </thead>
            <tbody>
              {stats?.recent_users?.map((user) => (
                <tr key={user._id} className="border-b border-white/5 hover:bg-white/5">
                  <td className="py-3 px-4">{user.full_name}</td>
                  <td className="py-3 px-4 text-gray-400 text-sm">{user.email}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      user.role === 'admin' ? 'bg-fuchsia-500/20 text-fuchsia-400' : 'bg-gray-500/20 text-gray-400'
                    }`}>
                      {user.role === 'admin' ? 'ادمین' : 'کاربر'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-400 text-sm">
                    {new Date(user.created_at).toLocaleDateString('fa-IR')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
