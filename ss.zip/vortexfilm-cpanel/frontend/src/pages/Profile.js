import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { userAPI } from '../utils/api';
import MovieCard from '../components/MovieCard';
import { Bookmark, Heart, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [lists, setLists] = useState({ watch_later: [], favorites: [] });
  const [loading, setLoading] = useState(true);
  const [activeList, setActiveList] = useState('watch_later');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadLists();
  }, [user, navigate]);

  const loadLists = async () => {
    try {
      setLoading(true);
      const response = await userAPI.getLists();
      setLists(response.data);
    } catch (error) {
      console.error('خطا در بارگذاری لیست‌ها:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="profile-page">
      <div className="glass-effect rounded-2xl p-8 mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black mb-2">{user?.full_name}</h1>
            <p className="text-gray-400">{user?.email}</p>
          </div>
          <button
            onClick={logout}
            className="px-6 py-2 bg-red-500/20 hover:bg-red-500/30 rounded-full border border-red-500/30 text-red-400"
            data-testid="logout-button"
          >
            خروج
          </button>
        </div>
      </div>

      <div className="flex gap-4 mb-8">
        <button
          onClick={() => setActiveList('watch_later')}
          className={`flex-1 py-3 rounded-full font-bold flex items-center justify-center gap-2 ${
            activeList === 'watch_later'
              ? 'bg-cyan-600 text-white'
              : 'bg-slate-900/50 text-gray-400 hover:bg-slate-900'
          }`}
          data-testid="watch-later-tab"
        >
          <Bookmark className="w-5 h-5" />
          <span>بعداً تماشا می‌کنم ({lists.watch_later.length})</span>
        </button>
        <button
          onClick={() => setActiveList('favorites')}
          className={`flex-1 py-3 rounded-full font-bold flex items-center justify-center gap-2 ${
            activeList === 'favorites'
              ? 'bg-red-600 text-white'
              : 'bg-slate-900/50 text-gray-400 hover:bg-slate-900'
          }`}
          data-testid="favorites-tab"
        >
          <Heart className="w-5 h-5" />
          <span>علاقه‌مندی‌ها ({lists.favorites.length})</span>
        </button>
      </div>

      <div>
        {lists[activeList].length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4" data-testid="movies-grid">
            {lists[activeList].map((movie) => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 glass-effect rounded-2xl">
            <p className="text-xl text-gray-400">
              {activeList === 'watch_later'
                ? 'هنوز فیلمی به لیست "بعداً تماشا می‌کنم" اضافه نکرده‌اید'
                : 'هنوز فیلمی به علاقه‌مندی‌ها اضافه نکرده‌اید'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
