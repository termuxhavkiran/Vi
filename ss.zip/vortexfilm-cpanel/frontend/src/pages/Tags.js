import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Tag, TrendingUp } from 'lucide-react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const Tags = () => {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTags();
  }, []);

  const fetchTags = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/tags?limit=100`);
      setTags(response.data.tags || []);
    } catch (error) {
      console.error('خطا در دریافت برچسب‌ها:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTagSize = (count) => {
    if (count >= 10) return 'text-2xl';
    if (count >= 5) return 'text-xl';
    return 'text-base';
  };

  const getTagColor = (count) => {
    if (count >= 10) return 'bg-red-600 hover:bg-red-700';
    if (count >= 5) return 'bg-orange-600 hover:bg-orange-700';
    return 'bg-blue-600 hover:bg-blue-700';
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black pt-24 pb-24 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white flex items-center gap-3 mb-2">
            <Tag className="w-8 h-8 text-red-500" />
            برچسب‌ها
          </h1>
          <p className="text-gray-400">کشف فیلم‌ها بر اساس برچسب‌های مختلف</p>
        </div>

        {loading ? (
          <div className="text-center text-gray-400 py-20">در حال بارگذاری...</div>
        ) : tags.length === 0 ? (
          <div className="text-center py-20">
            <Tag className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">هنوز برچسبی اضافه نشده است</p>
          </div>
        ) : (
          <>
            {/* برچسب‌های پرطرفدار */}
            <div className="mb-12">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-red-500" />
                برچسب‌های پرطرفدار
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {tags.slice(0, 6).map((tag) => (
                  <Link
                    key={tag._id}
                    to={`/tags/${tag.name}`}
                    className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white p-6 rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xl font-bold mb-1">{tag.name}</h3>
                        <p className="text-sm text-red-100">{tag.count} فیلم</p>
                      </div>
                      <Tag className="w-8 h-8 text-red-200" />
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* ابر برچسب‌ها */}
            <div>
              <h2 className="text-xl font-bold text-white mb-6">همه برچسب‌ها</h2>
              <div className="bg-gray-800/50 rounded-lg p-8">
                <div className="flex flex-wrap gap-3 justify-center">
                  {tags.map((tag) => (
                    <Link
                      key={tag._id}
                      to={`/tags/${tag.name}`}
                      className={`${getTagColor(tag.count)} text-white px-4 py-2 rounded-full ${getTagSize(tag.count)} font-medium transition-all duration-300 transform hover:scale-110 shadow-lg`}
                    >
                      {tag.name} ({tag.count})
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Tags;
