import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { adminAPI } from '../utils/api';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Trash2, Loader2, Film } from 'lucide-react';

const ManageReviews = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    loadReviews();
  }, [user, navigate, page]);

  const loadReviews = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getAllReviews(page);
      setReviews(response.data.reviews);
      setTotal(response.data.total);
    } catch (error) {
      console.error('خطا:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (reviewId) => {
    if (!window.confirm('آیا از حذف این نظر مطمئن هستید؟')) return;
    
    try {
      await adminAPI.deleteReview(reviewId);
      alert('نظر با موفقیت حذف شد');
      loadReviews();
    } catch (error) {
      console.error('خطا:', error);
      alert('خطا در حذف نظر');
    }
  };

  const totalPages = Math.ceil(total / 20);

  if (loading && page === 1) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="px-4 pb-24 pt-20 max-w-7xl mx-auto" data-testid="manage-reviews-page">
      <div className="mb-8">
        <h1 className="text-4xl font-black mb-2">مدیریت نظرات</h1>
        <p className="text-gray-400">مشاهده و مدیریت نظرات کاربران</p>
      </div>

      {/* لیست نظرات */}
      <div className="glass-effect rounded-2xl p-6 mb-6">
        <div className="space-y-4">
          {reviews.map((review) => (
            <div key={review._id} className="p-4 bg-slate-900/50 rounded-xl border border-white/10">
              <div className="flex items-start gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-bold">{review.user_name}</span>
                    <span className="text-xs text-gray-500">•</span>
                    <span className="text-sm text-gray-400">
                      {new Date(review.created_at).toLocaleDateString('fa-IR')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <Film className="w-4 h-4 text-fuchsia-500" />
                    <span className="text-sm text-gray-400">{review.movie_title}</span>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex">
                      {[...Array(10)].map((_, i) => (
                        <span key={i} className={`text-lg ${
                          i < review.rating ? 'text-yellow-500' : 'text-gray-700'
                        }`}>
                          ★
                        </span>
                      ))}
                    </div>
                    <span className="text-sm font-bold">{review.rating}/10</span>
                  </div>
                  <p className="text-gray-300">{review.comment}</p>
                </div>
                <button
                  onClick={() => handleDelete(review._id)}
                  className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg text-red-400"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {reviews.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <MessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-600" />
            <p>نظری موجود نیست</p>
          </div>
        )}

        {/* صفحه‌بندی */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-6">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="px-4 py-2 bg-slate-900 rounded-lg disabled:opacity-50"
            >
              قبلی
            </button>
            <span className="text-gray-400">
              صفحه {page} از {totalPages}
            </span>
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="px-4 py-2 bg-slate-900 rounded-lg disabled:opacity-50"
            >
              بعدی
            </button>
          </div>
        )}
      </div>

      {/* آمار */}
      <div className="glass-effect rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <MessageSquare className="w-6 h-6 text-fuchsia-500" />
          <h2 className="text-xl font-bold">آمار نظرات</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-1">تعداد کل نظرات</p>
            <p className="text-2xl font-black">{total}</p>
          </div>
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <p className="text-sm text-gray-400 mb-1">نظرات این صفحه</p>
            <p className="text-2xl font-black">{reviews.length}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageReviews;