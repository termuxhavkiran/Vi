import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Login from './pages/Login';
import MovieDetail from './pages/MovieDetail';
import Search from './pages/Search';
import Profile from './pages/Profile';
import AdminPanel from './pages/AdminPanel';
import Genres from './pages/Genres';
import Notifications from './pages/Notifications';
import ManageDownloads from './pages/ManageDownloads';
import Series from './pages/Series';
import SeriesDetail from './pages/SeriesDetail';
import ImportContent from './pages/ImportContent';
import AdminDashboard from './pages/AdminDashboard';
import ManageMovies from './pages/ManageMovies';
import ManageUsers from './pages/ManageUsers';
import ManageReviews from './pages/ManageReviews';
import AIDashboard from './pages/AIDashboard';
import Settings from './pages/Settings';
import ManageEpisodeDownloads from './pages/ManageEpisodeDownloads';
import WatchHistory from './pages/WatchHistory';
import Tags from './pages/Tags';
import TagMovies from './pages/TagMovies';
import ActorDetail from './pages/ActorDetail';
import PublicLists from './pages/PublicLists';
import PublicListDetail from './pages/PublicListDetail';
import MyLists from './pages/MyLists';
import FollowingLists from './pages/FollowingLists';
import Analytics from './pages/Analytics';
import NewsletterManagement from './pages/NewsletterManagement';
import Unsubscribe from './pages/Unsubscribe';
import { initGA, trackPageView } from './utils/analytics';
import './App.css';

// Google Analytics Tracker Component
function GATracker() {
  const location = useLocation();

  useEffect(() => {
    // Initialize GA on mount
    const gaId = process.env.REACT_APP_GA_TRACKING_ID;
    if (gaId) {
      initGA(gaId);
    }
  }, []);

  useEffect(() => {
    // Track page views on route change
    trackPageView(location.pathname + location.search);
  }, [location]);

  return null;
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <GATracker />
        <div className="App min-h-screen">
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/movie/:id" element={<MovieDetail />} />
            <Route path="/series" element={<Series />} />
            <Route path="/series/:id" element={<SeriesDetail />} />
            <Route path="/search" element={<Search />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/genres" element={<Genres />} />
            <Route path="/notifications" element={<Notifications />} />
            
            {/* Admin Routes */}
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/admin/import" element={<ImportContent />} />
            <Route path="/admin/movies" element={<ManageMovies />} />
            <Route path="/admin/users" element={<ManageUsers />} />
            <Route path="/admin/reviews" element={<ManageReviews />} />
            <Route path="/admin/ai" element={<AIDashboard />} />
            <Route path="/admin/settings" element={<Settings />} />
            <Route path="/admin/downloads/:id" element={<ManageDownloads />} />
            <Route path="/admin/episode-downloads/:episodeId" element={<ManageEpisodeDownloads />} />
            <Route path="/admin/analytics" element={<Analytics />} />
            <Route path="/admin/newsletter" element={<NewsletterManagement />} />
            
            {/* New Routes */}
            <Route path="/watch-history" element={<WatchHistory />} />
            <Route path="/tags" element={<Tags />} />
            <Route path="/tags/:tagName" element={<TagMovies />} />
            <Route path="/actor/:actorId" element={<ActorDetail />} />
            <Route path="/public-lists" element={<PublicLists />} />
            <Route path="/public-lists/:listId" element={<PublicListDetail />} />
            <Route path="/my-lists" element={<MyLists />} />
            <Route path="/following-lists" element={<FollowingLists />} />
            <Route path="/unsubscribe" element={<Unsubscribe />} />
          </Routes>
          <BottomNav />
          <ScrollToTop />
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
