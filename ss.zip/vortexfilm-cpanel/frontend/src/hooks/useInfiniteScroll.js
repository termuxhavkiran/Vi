import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * Custom Hook for Infinite Scroll
 * اسکرول بی‌نهایت با بارگذاری خودکار
 */
const useInfiniteScroll = (fetchFunction, options = {}) => {
  const {
    initialPage = 1,
    threshold = 0.8, // بارگذاری زمانی که 80% صفحه اسکرول شده
  } = options;

  const [data, setData] = useState([]);
  const [page, setPage] = useState(initialPage);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState(null);
  const observerRef = useRef();
  const loadingRef = useRef(false);

  // Load data
  const loadMore = useCallback(async () => {
    if (loadingRef.current || !hasMore) return;

    try {
      loadingRef.current = true;
      setLoading(true);
      setError(null);

      const result = await fetchFunction(page);
      
      if (result && result.length > 0) {
        setData((prev) => [...prev, ...result]);
        setPage((prev) => prev + 1);
        setHasMore(result.length >= 20); // فرض بر این که هر صفحه 20 آیتم دارد
      } else {
        setHasMore(false);
      }
    } catch (err) {
      setError(err.message);
      console.error('Error loading more data:', err);
    } finally {
      setLoading(false);
      loadingRef.current = false;
    }
  }, [page, hasMore, fetchFunction]);

  // Intersection Observer for scroll detection
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight;
      const clientHeight = document.documentElement.clientHeight;
      
      const scrollPercentage = (scrollTop + clientHeight) / scrollHeight;

      if (scrollPercentage >= threshold && !loading && hasMore) {
        loadMore();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [loading, hasMore, threshold, loadMore]);

  // Initial load
  useEffect(() => {
    if (data.length === 0 && !loading) {
      loadMore();
    }
  }, []);

  const reset = useCallback(() => {
    setData([]);
    setPage(initialPage);
    setHasMore(true);
    setError(null);
    loadingRef.current = false;
  }, [initialPage]);

  return {
    data,
    loading,
    hasMore,
    error,
    loadMore,
    reset,
    setData,
  };
};

export default useInfiniteScroll;
