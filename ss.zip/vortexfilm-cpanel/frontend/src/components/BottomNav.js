import React from 'react';
import { Home, Search, Layers, User, LogIn, Tv } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const BottomNav = () => {
  const location = useLocation();
  const { user } = useAuth();

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 bg-slate-950/80 backdrop-blur-xl border-t border-white/10 flex justify-around items-center z-50" data-testid="bottom-nav">
      <Link
        to="/"
        className={`flex flex-col items-center justify-center flex-1 h-full ${
          isActive('/') ? 'text-fuchsia-500' : 'text-gray-400'
        }`}
        data-testid="nav-home"
      >
        <Home className="w-6 h-6" />
      </Link>

      <Link
        to="/series"
        className={`flex flex-col items-center justify-center flex-1 h-full ${
          isActive('/series') || location.pathname.startsWith('/series/') ? 'text-fuchsia-500' : 'text-gray-400'
        }`}
        data-testid="nav-series"
      >
        <Tv className="w-6 h-6" />
      </Link>

      <Link
        to="/search"
        className={`flex flex-col items-center justify-center flex-1 h-full ${
          isActive('/search') ? 'text-fuchsia-500' : 'text-gray-400'
        }`}
        data-testid="nav-search"
      >
        <Search className="w-6 h-6" />
      </Link>

      <Link
        to="/genres"
        className={`flex flex-col items-center justify-center flex-1 h-full ${
          isActive('/genres') ? 'text-fuchsia-500' : 'text-gray-400'
        }`}
        data-testid="nav-genres"
      >
        <Layers className="w-6 h-6" />
      </Link>

      <Link
        to={user ? '/profile' : '/login'}
        className={`flex flex-col items-center justify-center flex-1 h-full ${
          isActive('/profile') || isActive('/login') ? 'text-fuchsia-500' : 'text-gray-400'
        }`}
        data-testid="nav-profile"
      >
        {user ? <User className="w-6 h-6" /> : <LogIn className="w-6 h-6" />}
      </Link>
    </nav>
  );
};

export default BottomNav;
