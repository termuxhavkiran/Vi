import React, { useState, useEffect } from 'react';
import { Menu, Bell, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';

const Header = () => {
  const [showMenu, setShowMenu] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      loadUnreadCount();
      const interval = setInterval(loadUnreadCount, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const loadUnreadCount = async () => {
    try {
      const response = await api.get('/api/notifications?limit=1');
      setUnreadCount(response.data.unread_count || 0);
    } catch (error) {
      console.error('خطا در بارگذاری تعداد اعلان‌ها:', error);
    }
  };

  return (
    <>
      <header className="fixed top-0 right-0 left-0 h-16 bg-gradient-to-b from-slate-950 to-transparent z-40 flex items-center justify-between px-4">
        <button
          onClick={() => setShowMenu(!showMenu)}
          className="p-2 hover:bg-white/10 rounded-full"
          data-testid="menu-button"
        >
          <Menu className="w-6 h-6 text-white" />
        </button>

        <Link to="/" className="absolute right-1/2 translate-x-1/2" data-testid="logo-link">
          <h1 className="text-2xl font-black tracking-tighter bg-gradient-to-l from-fuchsia-500 to-cyan-400 bg-clip-text text-transparent">
            VortexFilm
          </h1>
        </Link>

        <button 
          onClick={() => user ? navigate('/notifications') : navigate('/login')}
          className="p-2 hover:bg-white/10 rounded-full relative" 
          data-testid="notifications-button"
        >
          <Bell className="w-6 h-6 text-white" />
          {user && unreadCount > 0 && (
            <span className="absolute -top-1 -left-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center font-bold">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>
      </header>

      {showMenu && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md" onClick={() => setShowMenu(false)} data-testid="menu-overlay">
          <div
            className="absolute top-0 right-0 w-80 h-full bg-slate-900 border-l border-white/10 p-6 overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
            data-testid="menu-content"
          >
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-xl font-bold">منو</h2>
              <button onClick={() => setShowMenu(false)} className="p-2 hover:bg-white/10 rounded-full">
                <X className="w-6 h-6" />
              </button>
            </div>

            <nav className="space-y-4">
              <Link to="/" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                خانه
              </Link>
              <Link to="/series" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                سریال‌ها
              </Link>
              <Link to="/search" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                جستجو
              </Link>
              <Link to="/genres" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                ژانرها
              </Link>
              <Link to="/tags" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                برچسب‌ها
              </Link>
              <Link to="/public-lists" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                لیست‌های عمومی
              </Link>
              {user && (
                <>
                  <Link to="/watch-history" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                    تاریخچه تماشا
                  </Link>
                  <Link to="/my-lists" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                    لیست‌های من
                  </Link>
                </>
              )}
              {user ? (
                <>
                  <Link to="/profile" className="block py-3 px-4 rounded-lg hover:bg-white/10" onClick={() => setShowMenu(false)}>
                    پروفایل
                  </Link>
                  {user.role === 'admin' && (
                    <Link to="/admin" className="block py-3 px-4 rounded-lg hover:bg-white/10 text-fuchsia-400" onClick={() => setShowMenu(false)}>
                      پنل مدیریت
                    </Link>
                  )}
                  <button
                    onClick={() => {
                      logout();
                      setShowMenu(false);
                    }}
                    className="w-full text-right py-3 px-4 rounded-lg hover:bg-red-500/20 text-red-400"
                  >
                    خروج
                  </button>
                </>
              ) : (
                <Link to="/login" className="block py-3 px-4 rounded-lg hover:bg-white/10 text-fuchsia-400" onClick={() => setShowMenu(false)}>
                  ورود / ثبت‌نام
                </Link>
              )}
            </nav>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;
