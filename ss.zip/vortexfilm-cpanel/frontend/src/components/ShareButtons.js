import React from 'react';
import { Share2, Twitter, Facebook, Send, MessageCircle, Link as LinkIcon } from 'lucide-react';

const ShareButtons = ({ movie, isOpen, onClose }) => {
  if (!isOpen) return null;

  const shareUrl = `${window.location.origin}/movie/${movie._id}`;
  const shareText = `${movie.title} - تماشای آنلاین در VortexFilm`;

  const shareToTwitter = () => {
    const url = `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank', 'width=600,height=400');
  };

  const shareToFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
    window.open(url, '_blank', 'width=600,height=400');
  };

  const shareToTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank', 'width=600,height=400');
  };

  const shareToWhatsApp = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
    window.open(url, '_blank', 'width=600,height=400');
  };

  const copyLink = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      alert('لینک کپی شد!');
      onClose();
    });
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-gray-900 rounded-lg p-6 max-w-md w-full mx-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            اشتراک‌گذاری فیلم
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white">✕</button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={shareToTwitter}
            className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-3 rounded-lg transition"
          >
            <Twitter className="w-5 h-5" />
            توییتر
          </button>

          <button
            onClick={shareToFacebook}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-lg transition"
          >
            <Facebook className="w-5 h-5" />
            فیسبوک
          </button>

          <button
            onClick={shareToTelegram}
            className="flex items-center gap-2 bg-blue-400 hover:bg-blue-500 text-white px-4 py-3 rounded-lg transition"
          >
            <Send className="w-5 h-5" />
            تلگرام
          </button>

          <button
            onClick={shareToWhatsApp}
            className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-3 rounded-lg transition"
          >
            <MessageCircle className="w-5 h-5" />
            واتساپ
          </button>

          <button
            onClick={copyLink}
            className="col-span-2 flex items-center justify-center gap-2 bg-gray-700 hover:bg-gray-600 text-white px-4 py-3 rounded-lg transition"
          >
            <LinkIcon className="w-5 h-5" />
            کپی لینک
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShareButtons;
