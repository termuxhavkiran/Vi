import React from 'react';
import { Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getPosterUrl } from '../utils/tmdb';
import LazyImage from './LazyImage';

const MovieCard = ({ movie }) => {
  const posterUrl = movie.poster_path ? getPosterUrl(movie.poster_path) : 'https://images.unsplash.com/photo-1683926574610-099f6da5f49c?w=500';
  const year = movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A';

  return (
    <Link
      to={`/movie/${movie._id || movie.id}`}
      className="movie-card block aspect-[2/3] rounded-xl overflow-hidden relative group cursor-pointer shadow-2xl hover:ring-2 hover:ring-fuchsia-500/50"
      data-testid="movie-card"
    >
      <LazyImage
        src={posterUrl}
        alt={movie.title}
        className="w-full h-full object-cover"
        placeholder="https://via.placeholder.com/500x750/1a1a1a/666666?text=Loading..."
      />
      
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="absolute bottom-0 right-0 left-0 p-4">
          <h3 className="text-lg font-bold mb-1 line-clamp-2">{movie.title}</h3>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-300">{year}</span>
            {movie.vote_average > 0 && (
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span className="text-yellow-400 font-semibold">{movie.vote_average.toFixed(1)}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {movie.vote_average > 0 && (
        <div className="absolute top-2 left-2 flex items-center gap-1 bg-black/70 px-2 py-1 rounded-full backdrop-blur-sm">
          <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
          <span className="text-white text-sm font-semibold">{movie.vote_average.toFixed(1)}</span>
        </div>
      )}
    </Link>
  );
};

export default MovieCard;
