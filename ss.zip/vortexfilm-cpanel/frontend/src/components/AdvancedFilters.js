import React, { useState, useEffect } from 'react';
import { Filter, X, Calendar, Star, Clock, Globe, Grid } from 'lucide-react';
import { genresAPI } from '../utils/api';

const AdvancedFilters = ({ onFilterChange, onClose }) => {
  const [filters, setFilters] = useState({
    year_from: '',
    year_to: '',
    rating_from: '',
    rating_to: '',
    runtime_from: '',
    runtime_to: '',
    genre: '',
    language_filter: '',
    sort_by: 'created_at'
  });

  const [genres, setGenres] = useState([]);

  useEffect(() => {
    loadGenres();
  }, []);

  const loadGenres = async () => {
    try {
      const response = await genresAPI.getGenres('en');
      setGenres(response.data.genres || []);
    } catch (error) {
      console.error('خطا در دریافت ژانرها:', error);
    }
  };

  const handleChange = (field, value) => {
    setFilters({ ...filters, [field]: value });
  };

  const handleApply = () => {
    onFilterChange(filters);
    onClose();
  };

  const handleReset = () => {
    const emptyFilters = {
      year_from: '',
      year_to: '',
      rating_from: '',
      rating_to: '',
      runtime_from: '',
      runtime_to: '',
      genre: '',
      language_filter: '',
      sort_by: 'created_at'
    };
    setFilters(emptyFilters);
    onFilterChange(emptyFilters);
  };

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 100 }, (_, i) => currentYear - i);

  const languages = [
    { code: 'en', name: 'انگلیسی' },
    { code: 'fa', name: 'فارسی' },
    { code: 'fr', name: 'فرانسوی' },
    { code: 'de', name: 'آلمانی' },
    { code: 'es', name: 'اسپانیایی' },
    { code: 'it', name: 'ایتالیایی' },
    { code: 'ja', name: 'ژاپنی' },
    { code: 'ko', name: 'کره‌ای' },
    { code: 'zh', name: 'چینی' }
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-gray-900 rounded-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Filter className="w-6 h-6 text-fuchsia-500" />
            فیلترهای پیشرفته
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="space-y-6">
          {/* مرتب‌سازی */}
          <div>
            <label className="block text-white font-semibold mb-2 flex items-center gap-2">
              <Grid className="w-5 h-5 text-cyan-400" />
              مرتب‌سازی بر اساس
            </label>
            <select
              value={filters.sort_by}
              onChange={(e) => handleChange('sort_by', e.target.value)}
              className="w-full bg-gray-800 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
            >
              <option value="created_at">جدیدترین</option>
              <option value="vote_average">بالاترین امتیاز</option>
              <option value="views">پربازدیدترین</option>
              <option value="title">الفبایی (الف - ی)</option>
              <option value="release_date">سال انتشار</option>
              <option value="runtime">مدت زمان</option>
            </select>
          </div>

          {/* سال انتشار */}
          <div>
            <label className="block text-white font-semibold mb-2 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              سال انتشار
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">از سال</label>
                <select
                  value={filters.year_from}
                  onChange={(e) => handleChange('year_from', e.target.value)}
                  className="w-full bg-gray-800 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                >
                  <option value="">همه</option>
                  {years.map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">تا سال</label>
                <select
                  value={filters.year_to}
                  onChange={(e) => handleChange('year_to', e.target.value)}
                  className="w-full bg-gray-800 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                >
                  <option value="">همه</option>
                  {years.map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* امتیاز */}
          <div>
            <label className="block text-white font-semibold mb-2 flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-400" />
              امتیاز IMDB
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">حداقل امتیاز</label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  step="0.1"
                  value={filters.rating_from}
                  onChange={(e) => handleChange('rating_from', e.target.value)}
                  placeholder="0.0"
                  className="w-full bg-gray-800 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">حداکثر امتیاز</label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  step="0.1"
                  value={filters.rating_to}
                  onChange={(e) => handleChange('rating_to', e.target.value)}
                  placeholder="10.0"
                  className="w-full bg-gray-800 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
            </div>
          </div>

          {/* مدت زمان */}
          <div>
            <label className="block text-white font-semibold mb-2 flex items-center gap-2">
              <Clock className="w-5 h-5 text-green-400" />
              مدت زمان (دقیقه)
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">حداقل</label>
                <input
                  type="number"
                  min="0"
                  value={filters.runtime_from}
                  onChange={(e) => handleChange('runtime_from', e.target.value)}
                  placeholder="0"
                  className="w-full bg-gray-800 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">حداکثر</label>
                <input
                  type="number"
                  min="0"
                  value={filters.runtime_to}
                  onChange={(e) => handleChange('runtime_to', e.target.value)}
                  placeholder="300"
                  className="w-full bg-gray-800 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
                />
              </div>
            </div>
          </div>

          {/* ژانر */}
          <div>
            <label className="block text-white font-semibold mb-2 flex items-center gap-2">
              <Filter className="w-5 h-5 text-purple-400" />
              ژانر
            </label>
            <select
              value={filters.genre}
              onChange={(e) => handleChange('genre', e.target.value)}
              className="w-full bg-gray-800 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
            >
              <option value="">همه ژانرها</option>
              {genres.map((genre) => (
                <option key={genre.id} value={genre.name}>{genre.name}</option>
              ))}
            </select>
          </div>

          {/* زبان */}
          <div>
            <label className="block text-white font-semibold mb-2 flex items-center gap-2">
              <Globe className="w-5 h-5 text-orange-400" />
              زبان اصلی
            </label>
            <select
              value={filters.language_filter}
              onChange={(e) => handleChange('language_filter', e.target.value)}
              className="w-full bg-gray-800 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-fuchsia-500"
            >
              <option value="">همه زبان‌ها</option>
              {languages.map((lang) => (
                <option key={lang.code} value={lang.code}>{lang.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* دکمه‌ها */}
        <div className="flex gap-3 mt-6">
          <button
            onClick={handleApply}
            className="flex-1 bg-fuchsia-600 hover:bg-fuchsia-500 text-white py-3 rounded-lg font-bold transition"
          >
            اعمال فیلترها
          </button>
          <button
            onClick={handleReset}
            className="px-6 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg font-bold transition"
          >
            پاک کردن
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdvancedFilters;
