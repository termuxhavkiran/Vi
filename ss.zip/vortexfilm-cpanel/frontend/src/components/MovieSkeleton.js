import React from 'react';

/**
 * Loading Skeleton for Movie Cards
 * اسکلتون لودینگ برای نمایش در حین بارگذاری
 */
const MovieSkeleton = ({ count = 10 }) => {
  return (
    <>
      {Array.from({ length: count }).map((_, index) => (
        <div
          key={index}
          className="aspect-[2/3] rounded-xl overflow-hidden bg-gray-800 animate-pulse"
        >
          <div className="w-full h-full bg-gradient-to-b from-gray-700 to-gray-800" />
        </div>
      ))}
    </>
  );
};

export default MovieSkeleton;
