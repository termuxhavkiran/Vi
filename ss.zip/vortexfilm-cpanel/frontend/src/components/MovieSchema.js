import React from 'react';
import { Helmet } from 'react-helmet';

const MovieSchema = ({ movie }) => {
  if (!movie) return null;

  const schema = {
    "@context": "https://schema.org",
    "@type": "Movie",
    "name": movie.title || movie.name,
    "alternateName": movie.original_title || movie.original_name,
    "description": movie.overview,
    "image": movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : null,
    "datePublished": movie.release_date || movie.first_air_date,
    "genre": movie.genres || [],
    "aggregateRating": movie.vote_average ? {
      "@type": "AggregateRating",
      "ratingValue": movie.vote_average,
      "ratingCount": movie.vote_count || 0,
      "bestRating": 10,
      "worstRating": 0
    } : null,
    "duration": movie.runtime ? `PT${movie.runtime}M` : null,
    "actor": movie.cast ? movie.cast.slice(0, 5).map(actor => ({
      "@type": "Person",
      "name": actor.name
    })) : [],
    "director": movie.crew ? movie.crew
      .filter(c => c.job === "Director")
      .map(director => ({
        "@type": "Person",
        "name": director.name
      })) : []
  };

  // Remove null values
  Object.keys(schema).forEach(key => {
    if (schema[key] === null || schema[key] === undefined) {
      delete schema[key];
    }
  });

  return (
    <Helmet>
      <script type="application/ld+json">
        {JSON.stringify(schema)}
      </script>
    </Helmet>
  );
};

export default MovieSchema;
