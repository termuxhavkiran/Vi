import React, { useState } from 'react';
import axios from 'axios';
import { Bell, Mail, CheckCircle, AlertCircle } from 'lucide-react';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const Newsletter = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [messageType, setMessageType] = useState('success'); // success or error

  const handleSubscribe = async (e) => {
    e.preventDefault();
    
    if (!email || !email.includes('@')) {
      setMessage('لطفاً یک ایمیل معتبر وارد کنید');
      setMessageType('error');
      return;
    }

    setLoading(true);
    setMessage(null);

    try {
      const response = await axios.post(`${API_URL}/api/newsletter/subscribe`, {
        email: email
      });
      
      setMessage(response.data.message);
      setMessageType('success');
      setEmail('');
    } catch (error) {
      setMessage(error.response?.data?.detail || 'خطا در عضویت. لطفاً دوباره تلاش کنید.');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-blue-900 rounded-2xl p-8 shadow-2xl border border-purple-500/20">
      <div className="flex items-center justify-center mb-6">
        <div className="bg-purple-500/20 p-4 rounded-full">
          <Mail className="w-8 h-8 text-purple-300" />
        </div>
      </div>
      
      <h3 className="text-2xl font-bold text-white text-center mb-3">
        عضویت در خبرنامه
      </h3>
      
      <p className="text-purple-200 text-center mb-6">
        از جدیدترین فیلم‌ها و سریال‌ها مطلع شوید
      </p>

      <form onSubmit={handleSubscribe} className="space-y-4">
        <div className="relative">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ایمیل خود را وارد کنید"
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
            disabled={loading}
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              <span>در حال ارسال...</span>
            </>
          ) : (
            <>
              <Bell className="w-5 h-5" />
              <span>عضویت در خبرنامه</span>
            </>
          )}
        </button>
      </form>

      {message && (
        <div className={`mt-4 p-4 rounded-lg flex items-center gap-3 ${
          messageType === 'success' 
            ? 'bg-green-500/20 text-green-200 border border-green-500/30' 
            : 'bg-red-500/20 text-red-200 border border-red-500/30'
        }`}>
          {messageType === 'success' ? (
            <CheckCircle className="w-5 h-5 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
          )}
          <span>{message}</span>
        </div>
      )}

      <p className="text-xs text-purple-300 text-center mt-4">
        با عضویت در خبرنامه، شما با قوانین و مقررات موافقت می‌کنید
      </p>
    </div>
  );
};

export default Newsletter;
