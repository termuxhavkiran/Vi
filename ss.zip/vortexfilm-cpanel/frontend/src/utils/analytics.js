// Google Analytics Helper Functions

// Initialize Google Analytics
export const initGA = (trackingId) => {
  if (!trackingId || typeof window === 'undefined') return;

  // Load gtag.js script
  const script = document.createElement('script');
  script.src = `https://www.googletagmanager.com/gtag/js?id=${trackingId}`;
  script.async = true;
  document.head.appendChild(script);

  // Initialize gtag
  window.dataLayer = window.dataLayer || [];
  function gtag() {
    window.dataLayer.push(arguments);
  }
  window.gtag = gtag;
  gtag('js', new Date());
  gtag('config', trackingId, {
    page_path: window.location.pathname,
  });
};

// Track page views
export const trackPageView = (url) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('config', process.env.REACT_APP_GA_TRACKING_ID, {
      page_path: url,
    });
  }
};

// Track custom events
export const trackEvent = (category, action, label = null, value = null) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
};

// Track movie view
export const trackMovieView = (movieId, movieTitle) => {
  trackEvent('Movie', 'view', `${movieTitle} (${movieId})`);
};

// Track search
export const trackSearch = (searchQuery) => {
  trackEvent('Search', 'search', searchQuery);
};

// Track download click
export const trackDownload = (movieId, quality) => {
  trackEvent('Download', 'click', `Movie: ${movieId}, Quality: ${quality}`);
};

// Track user registration
export const trackRegistration = () => {
  trackEvent('User', 'register', 'New User Registration');
};

// Track user login
export const trackLogin = () => {
  trackEvent('User', 'login', 'User Login');
};

// Track video play
export const trackVideoPlay = (movieId) => {
  trackEvent('Video', 'play', `Movie: ${movieId}`);
};

// Track review submission
export const trackReview = (movieId, rating) => {
  trackEvent('Review', 'submit', `Movie: ${movieId}, Rating: ${rating}`);
};

// Track newsletter subscription
export const trackNewsletterSubscription = () => {
  trackEvent('Newsletter', 'subscribe', 'Newsletter Subscription');
};

export default {
  initGA,
  trackPageView,
  trackEvent,
  trackMovieView,
  trackSearch,
  trackDownload,
  trackRegistration,
  trackLogin,
  trackVideoPlay,
  trackReview,
  trackNewsletterSubscription,
};
