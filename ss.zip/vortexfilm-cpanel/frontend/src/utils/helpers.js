/**
 * Utility Helper Functions
 */

/**
 * Debounce function
 * تاخیر در اجرای تابع برای کاهش تعداد درخواست‌ها
 */
export const debounce = (func, delay = 300) => {
  let timeoutId;
  return (...args) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => {
      func.apply(null, args);
    }, delay);
  };
};

/**
 * Throttle function
 * محدود کردن تعداد اجرای تابع در یک بازه زمانی
 */
export const throttle = (func, limit = 300) => {
  let inThrottle;
  return (...args) => {
    if (!inThrottle) {
      func.apply(null, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
};

/**
 * Format file size
 * فرمت کردن حجم فایل
 */
export const formatFileSize = (bytes) => {
  if (!bytes) return 'نامشخص';
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  if (bytes === 0) return '0 Byte';
  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
  return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
};

/**
 * Format duration
 * فرمت کردن مدت زمان به دقیقه و ساعت
 */
export const formatDuration = (minutes) => {
  if (!minutes) return 'نامشخص';
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours > 0) {
    return `${hours} ساعت و ${mins} دقیقه`;
  }
  return `${mins} دقیقه`;
};

/**
 * Format date to Persian
 * فرمت کردن تاریخ به فارسی
 */
export const formatDate = (dateString) => {
  if (!dateString) return 'نامشخص';
  try {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  } catch {
    return 'نامشخص';
  }
};

/**
 * Scroll to top smoothly
 * اسکرول به بالای صفحه
 */
export const scrollToTop = (smooth = true) => {
  window.scrollTo({
    top: 0,
    behavior: smooth ? 'smooth' : 'auto',
  });
};

/**
 * Check if element is in viewport
 * بررسی اینکه آیا المنت در نمای کاربر است
 */
export const isInViewport = (element) => {
  const rect = element.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
};

/**
 * Get image URL with size
 * دریافت URL تصویر با سایز مشخص
 */
export const getImageUrl = (path, size = 'w500') => {
  if (!path) return null;
  const baseUrl = process.env.REACT_APP_TMDB_IMAGE_BASE || 'https://image.tmdb.org/t/p';
  return `${baseUrl}/${size}${path}`;
};

/**
 * Truncate text
 * کوتاه کردن متن
 */
export const truncateText = (text, maxLength = 100) => {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

/**
 * Generate random ID
 * ساخت شناسه تصادفی
 */
export const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export default {
  debounce,
  throttle,
  formatFileSize,
  formatDuration,
  formatDate,
  scrollToTop,
  isInViewport,
  getImageUrl,
  truncateText,
  generateId,
};
