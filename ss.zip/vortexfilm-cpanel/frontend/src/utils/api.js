import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
};

export const moviesAPI = {
  getMovies: (page = 1, language = 'fa') => api.get(`/movies?page=${page}&language=${language}`),
  getMovie: (id) => api.get(`/movies/${id}`),
  searchMovies: (query, language = 'fa') => api.get(`/movies/search?q=${query}&language=${language}`),
  importMovie: (tmdb_id, language = 'fa') => api.post('/movies/import', { tmdb_id, language }),
  getTrending: (timeWindow = 'week', language = 'fa') => api.get(`/movies/trending/${timeWindow}?language=${language}`),
  getDownloadLinks: (movieId) => api.get(`/movies/${movieId}/downloads`),
  uploadVideo: (movieId, quality, file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post(`/movies/${movieId}/downloads/upload?quality=${quality}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  addDownloadLink: (movieId, data) => api.post(`/movies/${movieId}/downloads/link`, data),
  deleteDownloadLink: (movieId, index) => api.delete(`/movies/${movieId}/downloads/${index}`),
};

export const aiAPI = {
  analyzeMood: (movieId) => api.post(`/movies/${movieId}/ai/mood`),
  analyzeCharacters: (movieId) => api.post(`/movies/${movieId}/ai/characters`),
  predictEnding: (movieId) => api.post(`/movies/${movieId}/ai/ending`),
  findHidden: (movieId) => api.post(`/movies/${movieId}/ai/hidden`),
  analyzeReviews: (movieId) => api.post(`/movies/${movieId}/ai/review-analysis`),
};

export const reviewsAPI = {
  createReview: (data) => api.post('/reviews', data),
  getReviews: (movieId) => api.get(`/movies/${movieId}/reviews`),
};

export const userAPI = {
  addWatchLater: (movieId) => api.post(`/users/watch-later/${movieId}`),
  removeWatchLater: (movieId) => api.delete(`/users/watch-later/${movieId}`),
  addFavorite: (movieId) => api.post(`/users/favorites/${movieId}`),
  removeFavorite: (movieId) => api.delete(`/users/favorites/${movieId}`),
  getLists: () => api.get('/users/lists'),
};

export const genresAPI = {
  getGenres: (language = 'fa') => api.get(`/genres?language=${language}`),
};

export const seriesAPI = {
  getSeries: (page = 1) => api.get(`/series?page=${page}`),
  getSeriesDetail: (id) => api.get(`/series/${id}`),
  getSeasonEpisodes: (seriesId, seasonNumber) => api.get(`/series/${seriesId}/season/${seasonNumber}`),
  searchSeries: (query, language = 'fa') => api.get(`/series/search?q=${query}&language=${language}`),
  importSeries: (tmdb_id, language = 'fa') => api.post('/series/import', { tmdb_id, language }),
  getTrendingSeries: (timeWindow = 'week', language = 'fa') => api.get(`/series/trending/${timeWindow}?language=${language}`),
  saveWatchProgress: (data) => api.post('/series/watch-progress', data),
  getWatchProgress: (seriesId) => api.get(`/series/${seriesId}/watch-progress`),
};

export const episodesAPI = {
  uploadVideo: (episodeId, quality, file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post(`/episodes/${episodeId}/downloads/upload?quality=${quality}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  addDownloadLink: (episodeId, data) => api.post(`/episodes/${episodeId}/downloads/link`, data),
  deleteDownloadLink: (episodeId, index) => api.delete(`/episodes/${episodeId}/downloads/${index}`),
};

export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  getAllMovies: (page = 1, search = '') => api.get(`/admin/movies?page=${page}&search=${search}`),
  updateMovie: (movieId, data) => api.put(`/admin/movies/${movieId}`, data),
  deleteMovie: (movieId) => api.delete(`/admin/movies/${movieId}`),
  createMovieManual: (data) => api.post('/admin/movies/manual', data),
  getAllUsers: (page = 1, search = '', roleFilter = '') => 
    api.get(`/admin/users?page=${page}&search=${search}&role_filter=${roleFilter}`),
  updateUserRole: (userId, role) => api.put(`/admin/users/${userId}/role?role=${role}`),
  deleteUser: (userId) => api.delete(`/admin/users/${userId}`),
  getAllReviews: (page = 1, movieId = '') => api.get(`/admin/reviews?page=${page}&movie_id=${movieId}`),
  deleteReview: (reviewId) => api.delete(`/admin/reviews/${reviewId}`),
  getAIStats: () => api.get('/admin/ai-stats'),
  getSettings: () => api.get('/admin/settings'),
  updateSettings: (data) => api.put('/admin/settings', data),
};

export const notificationsAPI = {
  getNotifications: (limit = 20) => api.get(`/notifications?limit=${limit}`),
  markAsRead: (notificationId) => api.post(`/notifications/${notificationId}/read`),
  markAllAsRead: () => api.post('/notifications/read-all'),
};

export const recommendationsAPI = {
  getRecommendations: (limit = 10) => api.get(`/recommendations?limit=${limit}`),
  getSimilarMovies: (movieId, limit = 10) => api.get(`/movies/${movieId}/similar?limit=${limit}`),
};

export const watchHistoryAPI = {
  addToHistory: (movieId) => api.post(`/watch-history/${movieId}`),
  getHistory: (limit = 50) => api.get(`/watch-history?limit=${limit}`),
  clearHistory: () => api.delete('/watch-history'),
  removeFromHistory: (movieId) => api.delete(`/watch-history/${movieId}`),
};

export const tagsAPI = {
  getAllTags: (limit = 50) => api.get(`/tags?limit=${limit}`),
  getMoviesByTag: (tagName, page = 1) => api.get(`/tags/${encodeURIComponent(tagName)}/movies?page=${page}`),
  addTagToMovie: (movieId, tagName) => api.post(`/movies/${movieId}/tags`, { name: tagName }),
  removeTagFromMovie: (movieId, tagName) => api.delete(`/movies/${movieId}/tags/${encodeURIComponent(tagName)}`),
};

export const actorAPI = {
  getActorInfo: (actorId) => api.get(`/actor/${actorId}`),
  getActorMovies: (actorId, page = 1) => api.get(`/actor/${actorId}/movies?page=${page}`),
};

export const publicListsAPI = {
  getAllLists: (page = 1, search = '') => api.get(`/public-lists?page=${page}&search=${search}`),
  getListDetail: (listId) => api.get(`/public-lists/${listId}`),
  getMyLists: () => api.get('/my-lists'),
  getFollowingLists: () => api.get('/public-lists/following'),
  createList: (data) => api.post('/public-lists', data),
  updateList: (listId, data) => api.put(`/public-lists/${listId}`, data),
  deleteList: (listId) => api.delete(`/public-lists/${listId}`),
  addMovieToList: (listId, movieId) => api.post(`/public-lists/${listId}/movies/${movieId}`),
  removeMovieFromList: (listId, movieId) => api.delete(`/public-lists/${listId}/movies/${movieId}`),
  followList: (listId) => api.post(`/public-lists/${listId}/follow`),
};

export const reviewInteractionAPI = {
  likeReview: (reviewId) => api.post(`/reviews/${reviewId}/like`),
  dislikeReview: (reviewId) => api.post(`/reviews/${reviewId}/dislike`),
};

export const advancedSearchAPI = {
  searchMovies: (params) => {
    const queryParams = new URLSearchParams();
    Object.keys(params).forEach(key => {
      if (params[key] !== null && params[key] !== undefined && params[key] !== '') {
        queryParams.append(key, params[key]);
      }
    });
    return api.get(`/movies/advanced-search?${queryParams.toString()}`);
  },
};

export default api;
