# ✅ چک‌لیست نصب VortexFilm

استفاده کنید از این چک‌لیست تا مطمئن شوید همه مراحل را به درستی انجام داده‌اید.

## 📝 قبل از شروع

- [ ] دسترسی به cPanel دارم
- [ ] دامنه یا زیردامنه آماده است: `https://http://89.42.199.185`
- [ ] به Terminal در cPanel دسترسی دارم
- [ ] امکان Setup Python App دارم
- [ ] امکان Setup Node.js App دارم

---

## 🗄️ MongoDB

✅ **MongoDB Atlas از پیش تنظیم شده است!**

- [✅] MongoDB Atlas متصل شده
- [✅] Connection String در `backend/.env` تنظیم شده
- [ ] (اختیاری) IP سرور در Network Access Whitelist قرار گرفت

💡 **نکته**: اگر خطای اتصال دریافت کردید، در MongoDB Atlas به **Network Access** بروید و `0.0.0.0/0` را اضافه کنید تا تمام IP ها دسترسی داشته باشند.

---

## 🐍 Backend (Python)

### Setup در cPanel
- [ ] به "Setup Python App" رفتم
- [ ] Application ایجاد شد:
  - [ ] Python version: 3.8+
  - [ ] Application root: `~/vortexfilm-cpanel/backend`
  - [ ] Entry point: `server:app`

### نصب کتابخانه‌ها
- [ ] Terminal باز شد
- [ ] به دایرکتوری backend رفتم: `cd ~/vortexfilm-cpanel/backend`
- [ ] محیط مجازی فعال شد: `source /path/to/virtualenv/bin/activate`
- [ ] کتابخانه‌ها نصب شدند: `pip install -r requirements.txt`

### تنظیمات
- [ ] فایل `backend/.env` بررسی شد
- [ ] کلید TMDB تنظیم شده: `61996de84bacda036b7c37cb27fe39e2`
- [ ] کلید Groq تنظیم شده: `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`
- [ ] دامنه Frontend صحیح است: `https://http://89.42.199.185`

### راه‌اندازی
- [ ] اسکریپت executable شد: `chmod +x start_backend_background.sh`
- [ ] Backend اجرا شد: `./start_backend_background.sh`
- [ ] پورت 8000 در فایروال باز شد

### تست Backend
- [ ] در مرورگر باز شد: `https://http://89.42.199.185:8000/docs`
- [ ] صفحه Swagger UI نمایش داده شد
- [ ] یک API تست شد (مثلاً `/api/health`)

---

## ⚛️ Frontend (React)

### Setup در cPanel
- [ ] به "Setup Node.js App" رفتم
- [ ] Application ایجاد شد:
  - [ ] Node.js version: 18+
  - [ ] Application mode: Production
  - [ ] Application root: `~/vortexfilm-cpanel/frontend`
  - [ ] Application URL: `/`

### نصب کتابخانه‌ها
- [ ] Terminal باز شد
- [ ] به دایرکتوری frontend رفتم: `cd ~/vortexfilm-cpanel/frontend`
- [ ] محیط Node.js فعال شد: `source /path/to/nodevenv/bin/activate`
- [ ] Yarn نصب شد: `npm install -g yarn`
- [ ] کتابخانه‌ها نصب شدند: `yarn install`

### تنظیمات
- [ ] فایل `frontend/.env` بررسی شد
- [ ] آدرس Backend صحیح است: `REACT_APP_BACKEND_URL=https://http://89.42.199.185:8000`

### Build و Deploy
- [ ] Frontend build شد: `yarn build`
- [ ] Build بدون خطا تمام شد
- [ ] فایل‌های build به public_html کپی شدند:
  ```bash
  cp -r ~/vortexfilm-cpanel/frontend/build/* ~/public_html/
  ```

### تنظیم .htaccess
- [ ] فایل `.htaccess` در `~/public_html/` ایجاد شد:
  ```apache
  <IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.html [L]
  </IfModule>
  ```

### تست Frontend
- [ ] در مرورگر باز شد: `https://http://89.42.199.185`
- [ ] صفحه اصلی نمایش داده شد
- [ ] هیچ خطایی در Console نیست (F12)

---

## 🔗 تست اتصال

- [ ] Frontend به Backend متصل است (بدون CORS error)
- [ ] ثبت‌نام کار می‌کند
- [ ] ورود کار می‌کند
- [ ] جستجوی فیلم کار می‌کند
- [ ] نمایش جزئیات فیلم کار می‌کند

---

## 🔧 تنظیمات اضافی (اختیاری)

### SSL/HTTPS
- [ ] SSL برای دامنه فعال شد (Let's Encrypt)
- [ ] سایت با HTTPS باز می‌شود

### ایمیل
- [ ] اطلاعات SMTP در `backend/.env` تنظیم شد
- [ ] App Password از Gmail دریافت شد
- [ ] ایمیل تست ارسال شد

### Cron Job (راه‌اندازی خودکار)
- [ ] در cPanel به "Cron Jobs" رفتم
- [ ] کار زمان‌بندی شده ایجاد شد:
  ```
  */5 * * * * cd /home/yourusername/vortexfilm-cpanel/backend && ./start_backend_background.sh
  ```

### بکاپ
- [ ] برنامه بکاپ منظم تنظیم شد
- [ ] بکاپ اولیه گرفته شد

---

## 🎉 تمام شد!

اگر همه موارد بالا ✅ شدند، تبریک! نصب با موفقیت انجام شد.

### لینک‌های نهایی:

🌐 **Frontend**: https://http://89.42.199.185  
🔧 **Backend API**: https://http://89.42.199.185:8000  
📚 **API Docs**: https://http://89.42.199.185:8000/docs

---

## 🐛 اگر مشکلی پیش آمد:

1. **Backend لاگ‌ها**:
   ```bash
   tail -f ~/vortexfilm-cpanel/backend/nohup.out
   ```

2. **Frontend خطاها**:
   - F12 در مرورگر
   - Console را بررسی کنید

3. **راهنمای کامل**:
   - `CPANEL_INSTALL_GUIDE.md`
   - بخش "عیب‌یابی"

4. **ریستارت Backend**:
   ```bash
   cd ~/vortexfilm-cpanel/backend
   ./stop_backend.sh
   ./start_backend_background.sh
   ```

5. **Rebuild Frontend**:
   ```bash
   cd ~/vortexfilm-cpanel/frontend
   yarn build
   cp -r build/* ~/public_html/
   ```

---

**موفق باشید! 🚀**
