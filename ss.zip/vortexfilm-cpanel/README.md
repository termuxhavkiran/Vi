# 🎬 VortexFilm - پلتفرم مدیریت فیلم و سریال

## 📝 درباره پروژه

VortexFilm یک پلتفرم کامل و پیشرفته برای مدیریت، جستجو و نمایش فیلم‌ها و سریال‌ها است.

## ✨ ویژگی‌ها

- 🔐 سیستم احراز هویت کامل (ثبت‌نام، ورود، 2FA)
- 🎥 مدیریت فیلم‌ها و سریال‌ها
- 🔍 جستجوی پیشرفته با فیلترهای متعدد
- ⭐ سیستم امتیازدهی و نظرات
- 📋 لیست‌های شخصی و عمومی
- 🤖 قابلیت‌های هوش مصنوعی (Groq AI)
- 📊 پنل مدیریت و آنالیتیکس
- 📧 سیستم ایمیل و خبرنامه
- 🎨 رابط کاربری مدرن با Tailwind CSS

## 🛠️ تکنولوژی‌ها

### Backend
- **Framework**: FastAPI (Python)
- **Database**: MongoDB
- **API**: TMDB API
- **AI**: Groq AI
- **Authentication**: JWT + 2FA

### Frontend
- **Framework**: React 19
- **Styling**: Tailwind CSS
- **UI Components**: Radix UI
- **Routing**: React Router
- **Build Tool**: Create React App + CRACO

## 📦 نصب

### نصب روی cPanel

**راهنمای کامل نصب را در فایل `CPANEL_INSTALL_GUIDE.md` مطالعه کنید.**

یا برای شروع سریع: `START_HERE.txt`

### نصب محلی (Development)

#### پیش‌نیازها:
- Python 3.8+
- Node.js 18+
- MongoDB

#### Backend:
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env  # و مقادیر را تنظیم کنید
uvicorn server:app --reload
```

#### Frontend:
```bash
cd frontend
yarn install
yarn start
```

## 🔑 تنظیمات

### Backend (.env)
```env
MONGO_URL="mongodb://localhost:27017"
DB_NAME="vortexfilm_db"
TMDB_API_KEY="your-tmdb-key"
GROQ_API_KEY="your-groq-key"
JWT_SECRET="your-secret-key"
FRONTEND_URL="https://yourdomain.com"
```

### Frontend (.env)
```env
REACT_APP_BACKEND_URL=https://yourdomain.com:8000
```

## 🚀 استفاده

پس از نصب:

- **Frontend**: https://yourdomain.com
- **Backend API**: https://yourdomain.com:8000
- **API Documentation**: https://yourdomain.com:8000/docs

## 📚 ساختار پروژه

```
vortexfilm-cpanel/
├── backend/              # Backend FastAPI
│   ├── server.py        # فایل اصلی سرور
│   ├── email_service.py # سرویس ایمیل
│   ├── cache_manager.py # مدیریت کش
│   └── ...
├── frontend/            # Frontend React
│   ├── src/
│   │   ├── pages/      # صفحات
│   │   ├── components/ # کامپوننت‌ها
│   │   └── utils/      # ابزارها
│   └── public/
├── tests/              # تست‌ها
└── scripts/            # اسکریپت‌های کمکی
```

## 🧪 تست

```bash
# Backend
cd backend
pytest

# Frontend
cd frontend
yarn test
```

## 🐛 عیب‌یابی

### Backend اجرا نمی‌شود
```bash
# چک کردن لاگ‌ها
tail -f backend/nohup.out

# ریستارت
cd backend
./stop_backend.sh
./start_backend_background.sh
```

### Frontend سفید است
1. باز کردن Console مرورگر (F12)
2. بررسی خطاها
3. ریبیلد:
```bash
cd frontend
yarn build
```

## 📝 مجوز

این پروژه برای استفاده شخصی آزاد است.

## 🤝 مشارکت

برای گزارش باگ یا پیشنهاد ویژگی جدید، Issue ایجاد کنید.

## 📞 پشتیبانی

- **Documentation**: CPANEL_INSTALL_GUIDE.md
- **Quick Start**: START_HERE.txt

---

**ساخته شده با ❤️**
