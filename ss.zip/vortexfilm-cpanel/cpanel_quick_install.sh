#!/bin/bash

# رنگ‌ها برای خروجی
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}🎬 VortexFilm - نصب سریع روی cPanel${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# بررسی دایرکتوری
if [ ! -d "backend" ] || [ ! -d "frontend" ]; then
    echo -e "${RED}❌ خطا: لطفاً این اسکریپت را در دایرکتوری vortexfilm-cpanel اجرا کنید${NC}"
    exit 1
fi

echo -e "${YELLOW}📋 این اسکریپت مراحل زیر را انجام می‌دهد:${NC}"
echo "  1. بررسی پیش‌نیازها"
echo "  2. نصب کتابخانه‌های Backend"
echo "  3. نصب کتابخانه‌های Frontend"
echo "  4. ساخت فایل‌های تولیدی Frontend"
echo "  5. راه‌اندازی Backend"
echo ""
read -p "آیا مایل به ادامه هستید؟ (y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 0
fi

echo ""
echo -e "${BLUE}[1/5]${NC} بررسی پیش‌نیازها..."

# بررسی Python
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo -e "${GREEN}✓${NC} Python: $PYTHON_VERSION"
else
    echo -e "${RED}✗${NC} Python 3 یافت نشد!"
    exit 1
fi

# بررسی Node.js
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo -e "${GREEN}✓${NC} Node.js: $NODE_VERSION"
else
    echo -e "${RED}✗${NC} Node.js یافت نشد!"
    exit 1
fi

# بررسی Yarn
if ! command -v yarn &> /dev/null; then
    echo -e "${YELLOW}⚠${NC} Yarn یافت نشد. نصب..."
    npm install -g yarn
fi

echo ""
echo -e "${BLUE}[2/5]${NC} نصب کتابخانه‌های Backend..."
cd backend
pip3 install -r requirements.txt --user
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓${NC} Backend dependencies نصب شد"
else
    echo -e "${RED}✗${NC} خطا در نصب Backend dependencies"
    exit 1
fi

echo ""
echo -e "${BLUE}[3/5]${NC} نصب کتابخانه‌های Frontend..."
cd ../frontend
yarn install
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓${NC} Frontend dependencies نصب شد"
else
    echo -e "${RED}✗${NC} خطا در نصب Frontend dependencies"
    exit 1
fi

echo ""
echo -e "${BLUE}[4/5]${NC} ساخت فایل‌های تولیدی Frontend..."
yarn build
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓${NC} Frontend build شد"
else
    echo -e "${RED}✗${NC} خطا در build کردن Frontend"
    exit 1
fi

echo ""
echo -e "${BLUE}[5/5]${NC} راه‌اندازی Backend..."
cd ../backend
chmod +x start_backend_background.sh
./start_backend_background.sh
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓${NC} Backend راه‌اندازی شد"
else
    echo -e "${RED}✗${NC} خطا در راه‌اندازی Backend"
fi

echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}🎉 نصب با موفقیت انجام شد!${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${YELLOW}مراحل نهایی:${NC}"
echo ""
echo "1. کپی فایل‌های Frontend به public_html:"
echo -e "   ${GREEN}cp -r frontend/build/* ~/public_html/${NC}"
echo ""
echo "2. ایجاد فایل .htaccess:"
echo -e "   ${GREEN}cat > ~/public_html/.htaccess << 'EOF'"
echo "   <IfModule mod_rewrite.c>"
echo "     RewriteEngine On"
echo "     RewriteBase /"
echo "     RewriteCond %{REQUEST_FILENAME} !-f"
echo "     RewriteCond %{REQUEST_FILENAME} !-d"
echo "     RewriteRule . /index.html [L]"
echo "   </IfModule>"
echo -e "   EOF${NC}"
echo ""
echo "3. بررسی که پورت 8000 باز باشد"
echo ""
echo -e "${BLUE}لینک‌ها:${NC}"
echo "  • Frontend: https://http://89.42.199.185"
echo "  • Backend API: https://http://89.42.199.185:8000"
echo "  • API Docs: https://http://89.42.199.185:8000/docs"
echo ""
echo -e "${GREEN}موفق باشید! 🚀${NC}"
