# 🎬 راهنمای نصب VortexFilm روی cPanel

## 📋 فهرست مطالب
1. [پیش‌نیازها](#پیش-نیازها)
2. [مرحله 1: آپلود فایل‌ها](#مرحله-1-آپلود-فایلها)
3. [مرحله 2: راه‌اندازی MongoDB](#مرحله-2-راه-اندازی-mongodb)
4. [مرحله 3: نصب Backend (Python)](#مرحله-3-نصب-backend-python)
5. [مرحله 4: نصب Frontend (React)](#مرحله-4-نصب-frontend-react)
6. [مرحله 5: تنظیمات نهایی](#مرحله-5-تنظیمات-نهایی)
7. [عیب‌یابی](#عیب-یابی)

---

## 🔧 پیش‌نیازها

- ✅ دسترسی به cPanel
- ✅ Python 3.8+ (موجود در Setup Python App)
- ✅ Node.js 18+ (موجود در Setup Node.js App)
- ✅ MongoDB (Atlas یا نصب محلی)
- ✅ دامنه یا زیردامنه: `https://http://89.42.199.185`

---

## 📁 مرحله 1: آپلود فایل‌ها

### روش 1: استفاده از File Manager

1. وارد **cPanel** شوید
2. به **File Manager** بروید
3. فایل `vortexfilm-cpanel.zip` را آپلود کنید
4. فایل را **Extract** کنید
5. پوشه `vortexfilm-cpanel` را به دایرکتوری اصلی منتقل کنید

### روش 2: استفاده از Terminal

```bash
cd ~
# اگر فایل zip آپلود کردید:
unzip vortexfilm-cpanel.zip
cd vortexfilm-cpanel
```

---

## 🗄️ مرحله 2: MongoDB

✅ **MongoDB Atlas از پیش تنظیم شده است!**

دیتابیس شما قبلاً راه‌اندازی و متصل شده است:
```env
MONGO_URL="mongodb+srv://vortexfilm:Mo_13848413@cluster0.wiqkh0q.mongodb.net/"
DB_NAME="vortexfilm_db"
```

**هیچ کاری لازم نیست!** به مرحله بعد بروید.

---

### 📌 نکته مهم (فقط برای اطلاع):

اگر در آینده خواستید دیتابیس را تغییر دهید:
1. وارد [MongoDB Atlas](https://cloud.mongodb.com) شوید
2. در قسمت **Network Access** آی‌پی سرور را در Whitelist قرار دهید (یا `0.0.0.0/0` برای همه)
3. Connection String در فایل `backend/.env` قبلاً تنظیم شده است

---

## 🐍 مرحله 3: نصب Backend (Python)

### قدم 1: راه‌اندازی Python App در cPanel

1. در cPanel به **Setup Python App** بروید
2. روی **Create Application** کلیک کنید
3. تنظیمات زیر را وارد کنید:
   - **Python version**: 3.8 یا بالاتر
   - **Application root**: `/home/yourusername/vortexfilm-cpanel/backend`
   - **Application URL**: بدون انتخاب (برای API)
   - **Application startup file**: `server.py`
   - **Application Entry point**: `app`

4. روی **Create** کلیک کنید

### قدم 2: نصب کتابخانه‌های Python

در Terminal cPanel دستورات زیر را اجرا کنید:

```bash
# رفتن به دایرکتوری backend
cd ~/vortexfilm-cpanel/backend

# فعال‌سازی محیط مجازی Python (نام محیط مجازی از cPanel کپی کنید)
source /home/yourusername/virtualenv/vortexfilm-cpanel/backend/3.x/bin/activate

# نصب پکیج‌ها
pip install -r requirements.txt

# خروج از محیط مجازی
deactivate
```

### قدم 3: راه‌اندازی Backend با uvicorn

در cPanel Terminal:

```bash
cd ~/vortexfilm-cpanel/backend

# اجرای سرور در پس‌زمینه
nohup python3 -m uvicorn server:app --host 0.0.0.0 --port 8000 &

# یا استفاده از اسکریپت آماده
chmod +x start_backend_background.sh
./start_backend_background.sh
```

### قدم 4: باز کردن پورت 8000

⚠️ **مهم**: پورت 8000 باید در فایروال باز باشد!

در cPanel یا با پشتیبانی هاست، پورت 8000 را باز کنید.

**تست Backend:**
```bash
curl http://localhost:8000/api/health
# یا
curl https://http://89.42.199.185:8000/api/health
```

---

## ⚛️ مرحله 4: نصب Frontend (React)

### قدم 1: راه‌اندازی Node.js App در cPanel

1. در cPanel به **Setup Node.js App** بروید
2. روی **Create Application** کلیک کنید
3. تنظیمات زیر را وارد کنید:
   - **Node.js version**: 18.x یا بالاتر
   - **Application mode**: Production
   - **Application root**: `/home/yourusername/vortexfilm-cpanel/frontend`
   - **Application URL**: `/` (یا دامنه خود)
   - **Application startup file**: `node_modules/react-scripts/scripts/start.js`

4. روی **Create** کلیک کنید

### قدم 2: نصب کتابخانه‌های Node.js و Build

در Terminal cPanel:

```bash
# رفتن به دایرکتوری frontend
cd ~/vortexfilm-cpanel/frontend

# فعال‌سازی محیط Node.js (از cPanel کپی کنید)
source /home/yourusername/nodevenv/vortexfilm-cpanel/frontend/18/bin/activate

# نصب Yarn (اگر نصب نیست)
npm install -g yarn

# نصب پکیج‌ها با Yarn
yarn install

# ساخت فایل‌های تولیدی
yarn build

# خروج از محیط
deactivate
```

### قدم 3: کپی فایل‌های Build به public_html

```bash
# حذف فایل‌های قدیمی (احتیاط کنید!)
rm -rf ~/public_html/*

# کپی فایل‌های جدید
cp -r ~/vortexfilm-cpanel/frontend/build/* ~/public_html/

# یا اگر از زیردامنه استفاده می‌کنید:
# cp -r ~/vortexfilm-cpanel/frontend/build/* ~/public_html/subdomain/
```

### قدم 4: تنظیم .htaccess برای React Router

در `~/public_html/` فایل `.htaccess` ایجاد کنید:

```bash
cat > ~/public_html/.htaccess << 'EOF'
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  
  # اگر فایل یا دایرکتوری واقعی نیست، به index.html هدایت کن
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
EOF
```

---

## ⚙️ مرحله 5: تنظیمات نهایی

### 1. تنظیم CORS (اگر مشکل داشتید)

در فایل `backend/server.py` خط 40:

```python
allow_origins=["https://http://89.42.199.185"],
```

### 2. تنظیم SSL/HTTPS

- در cPanel به **SSL/TLS** بروید
- SSL برای دامنه خود فعال کنید (Let's Encrypt رایگان است)

### 3. ایمیل (اختیاری)

اگر می‌خواهید ایمیل کار کند، در `backend/.env`:

```env
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USERNAME="your-email@gmail.com"
SMTP_PASSWORD="your-16-digit-app-password"
SMTP_FROM_EMAIL="noreply@yourdomain.com"
```

برای Gmail، باید [App Password](https://myaccount.google.com/apppasswords) دریافت کنید.

### 4. راه‌اندازی خودکار Backend (Cron Job)

در cPanel به **Cron Jobs** بروید و یک کار زمان‌بندی شده ایجاد کنید:

```bash
*/5 * * * * cd /home/yourusername/vortexfilm-cpanel/backend && ./start_backend_background.sh
```

این هر 5 دقیقه چک می‌کند که Backend در حال اجرا باشد.

---

## 🎉 تست نهایی

### 1. تست Backend API

باز کردن در مرورگر:
```
https://http://89.42.199.185:8000/docs
```

باید صفحه Swagger UI را ببینید.

### 2. تست Frontend

باز کردن در مرورگر:
```
https://http://89.42.199.185
```

باید صفحه اصلی VortexFilm را ببینید.

### 3. تست اتصال Frontend به Backend

1. در سایت ثبت‌نام کنید
2. لاگین کنید
3. فیلم‌ها را جستجو کنید

---

## 🐛 عیب‌یابی

### مشکل 1: Backend اجرا نمی‌شود

**راه حل:**
```bash
# چک کردن لاگ‌ها
cd ~/vortexfilm-cpanel/backend
tail -f nohup.out

# یا
ps aux | grep uvicorn

# کشتن پروسه قدیمی
pkill -f uvicorn

# شروع مجدد
./start_backend_background.sh
```

### مشکل 2: پورت 8000 باز نیست

**راه حل:**
- با پشتیبانی هاست تماس بگیرید
- یا از پورت دیگری استفاده کنید (در backend/server.py و frontend/.env)

### مشکل 3: Frontend سفید است (White Screen)

**راه حل:**
1. باز کردن Console در مرورگر (F12)
2. بررسی خطاها
3. چک کردن که `.htaccess` درست تنظیم شده
4. Build مجدد:
   ```bash
   cd ~/vortexfilm-cpanel/frontend
   yarn build
   cp -r build/* ~/public_html/
   ```

### مشکل 4: CORS Error

**راه حل:**
در `backend/server.py`:
```python
allow_origins=["https://http://89.42.199.185"],
allow_credentials=True,
```

سپس Backend را ریستارت کنید.

### مشکل 5: MongoDB اتصال ندارد

**راه حل:**
1. چک کردن Connection String در `backend/.env`
2. در MongoDB Atlas، IP Address سرور را در Whitelist قرار دهید (یا 0.0.0.0/0)
3. Username و Password را بررسی کنید

---

## 📞 پشتیبانی

اگر مشکلی پیش آمد:

1. **لاگ Backend**: `~/vortexfilm-cpanel/backend/nohup.out`
2. **لاگ Browser Console**: F12 در مرورگر
3. **تست API**: https://http://89.42.199.185:8000/docs

---

## 🎯 لینک‌های مفید

- Frontend: https://http://89.42.199.185
- Backend API: https://http://89.42.199.185:8000
- API Docs: https://http://89.42.199.185:8000/docs
- MongoDB Atlas: https://www.mongodb.com/cloud/atlas

---

**موفق باشید! 🚀**

اگر سوالی داشتید، در فایل `START_HERE.txt` راهنمای کوتاه‌تری هم موجود است.
