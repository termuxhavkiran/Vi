#!/bin/bash
# راه‌اندازی Backend برای cPanel

echo "🚀 Starting VortexFilm Backend..."

# رفتن به پوشه backend
cd /home/YOUR_CPANEL_USERNAME/vortexfilm/backend

# کپی کردن فایل .env.production به .env
cp .env.production .env

# نصب dependencies (در اولین بار)
echo "📦 Installing Python dependencies..."
pip3 install -r requirements.txt --user

# راه‌اندازی سرور با uvicorn
echo "✅ Starting FastAPI server on port 8000..."
uvicorn server:app --host 0.0.0.0 --port 8000 --reload
