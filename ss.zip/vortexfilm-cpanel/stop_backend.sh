#!/bin/bash
# متوقف کردن Backend

echo "🛑 Stopping VortexFilm Backend..."

pkill -f "uvicorn server:app"

echo "✅ Backend stopped!"
