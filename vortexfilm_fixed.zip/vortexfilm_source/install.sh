#!/bin/bash

# ╔═══════════════════════════════════════════════════════════════╗
# ║     🚀 اسکریپت نصب خودکار VortexFilm - نسخه اصلاح شده        ║
# ╚═══════════════════════════════════════════════════════════════╝

echo ""
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║       🎬 نصب خودکار VortexFilm - React 18.3.1 ✅             ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

# رنگ‌ها
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# پوشه اصلی پروژه
PROJECT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo -e "${YELLOW}📁 پوشه پروژه: $PROJECT_DIR${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════
# مرحله 1: بررسی نیازمندی‌ها
# ═══════════════════════════════════════════════════════════════

echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${YELLOW}مرحله 1: بررسی نیازمندی‌ها${NC}"
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# بررسی Node.js
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo -e "${GREEN}✅ Node.js: $NODE_VERSION${NC}"
else
    echo -e "${RED}❌ Node.js یافت نشد! لطفاً Node.js 20+ را نصب کنید.${NC}"
    exit 1
fi

# بررسی Yarn
if command -v yarn &> /dev/null; then
    YARN_VERSION=$(yarn --version)
    echo -e "${GREEN}✅ Yarn: v$YARN_VERSION${NC}"
else
    echo -e "${YELLOW}⚠️  Yarn یافت نشد. در حال نصب...${NC}"
    npm install -g yarn
fi

# بررسی Python
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo -e "${GREEN}✅ Python: $PYTHON_VERSION${NC}"
else
    echo -e "${RED}❌ Python3 یافت نشد! لطفاً Python 3.8+ را نصب کنید.${NC}"
    exit 1
fi

echo ""
sleep 2

# ═══════════════════════════════════════════════════════════════
# مرحله 2: Build Frontend
# ═══════════════════════════════════════════════════════════════

echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${YELLOW}مرحله 2: Build Frontend (React 18.3.1)${NC}"
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

cd "$PROJECT_DIR/frontend"

# پاک کردن کش‌های قدیمی
echo -e "${YELLOW}🧹 پاک کردن کش‌ها...${NC}"
rm -rf node_modules yarn.lock build node_modules/.cache
yarn cache clean

echo ""

# تنظیم حافظه
export NODE_OPTIONS="--max-old-space-size=4096"

# نصب dependencies
echo -e "${YELLOW}📦 نصب کتابخانه‌ها...${NC}"
yarn install

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ نصب کتابخانه‌ها موفق بود${NC}"
else
    echo -e "${RED}❌ خطا در نصب کتابخانه‌ها${NC}"
    exit 1
fi

echo ""

# Build
echo -e "${YELLOW}🔨 Build پروژه... (ممکن است چند دقیقه طول بکشد)${NC}"
yarn build

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅✅✅ Build موفقیت‌آمیز بود! ✅✅✅${NC}"
else
    echo -e "${RED}❌ خطا در Build${NC}"
    exit 1
fi

echo ""
sleep 2

# ═══════════════════════════════════════════════════════════════
# مرحله 3: نصب Backend
# ═══════════════════════════════════════════════════════════════

echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${YELLOW}مرحله 3: نصب Backend Dependencies${NC}"
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

cd "$PROJECT_DIR/backend"

echo -e "${YELLOW}📦 نصب کتابخانه‌های Python...${NC}"
pip install -r requirements.txt

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ نصب Backend موفق بود${NC}"
else
    echo -e "${RED}❌ خطا در نصب Backend${NC}"
    exit 1
fi

echo ""
sleep 2

# ═══════════════════════════════════════════════════════════════
# مرحله 4: راهنمای Deploy
# ═══════════════════════════════════════════════════════════════

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}🎉 نصب با موفقیت تکمیل شد!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

echo -e "${YELLOW}📁 فایل‌های Build در:${NC}"
echo "   $PROJECT_DIR/frontend/build/"
echo ""

echo -e "${YELLOW}🚀 مراحل بعدی:${NC}"
echo ""
echo -e "${GREEN}1️⃣  Deploy Frontend:${NC}"
echo "   cp -r $PROJECT_DIR/frontend/build/* ~/public_html/"
echo ""
echo -e "${GREEN}2️⃣  راه‌اندازی Backend:${NC}"
echo "   cd $PROJECT_DIR/backend"
echo "   nohup python3 -m uvicorn server:app --host 0.0.0.0 --port 8000 &"
echo ""
echo -e "${GREEN}3️⃣  تنظیم .htaccess:${NC}"
echo "   cat > ~/public_html/.htaccess << 'EOF'"
echo "   <IfModule mod_rewrite.c>"
echo "     RewriteEngine On"
echo "     RewriteBase /"
echo "     RewriteCond %{REQUEST_FILENAME} !-f"
echo "     RewriteCond %{REQUEST_FILENAME} !-d"
echo "     RewriteRule . /index.html [L]"
echo "   </IfModule>"
echo "   EOF"
echo ""

echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${GREEN}✅ React نسخه 18.3.1 - سازگار با Node.js 20${NC}"
echo -e "${GREEN}✅ بدون خطای webpack/compiler${NC}"
echo -e "${GREEN}✅ آماده برای Deploy روی cPanel${NC}"
echo ""
echo -e "${YELLOW}برای راهنمای کامل: cat راهنمای_اصلاح_شده.txt${NC}"
echo ""
echo -e "${GREEN}موفق باشید! 🚀${NC}"
echo ""
